
<!-- Om ngapain om?:( -->

<html>



<head>



<title>Hacked By Tegal6etar1337</title>

<link rel="icon" type="image/jpg" href="https://i.ibb.co/2kVcrzX/IMG-20201024-013306.png"> 



<link rel="icon" type="image/x-icon" href="https://i.ibb.co/2kVcrzX/IMG-20201024-013306.png">



<meta name="title" content="Hacked by Tegal6etar">



<meta name="description" content="You Own3d!!!">



<meta name="keywords" content="You Own3d!!!">



<meta name="googlebot" content="index,follow">



<meta name="robots" content="all">



<meta name="robots schedule" content="auto">



<meta name="distribution" content="global">



<meta contact="#">



<!-- Styles -->



<style>



            html, body {



                background-color: #000



               ;



                height: 100vh;



                margin: 0;



            }



            .full-height {



                height: 100vh;



            }



            .flex-center {



                align-items: center;



                display: flex;



                justify-content: center;



            }



            .position-ref {



                position: relative;



            }



            .content {



                text-align: center;



            }



            .title {



                font-size: 36px;



                padding: 20px;



            }



</style>



</head>



<body align="center" oncontextmenu="return false">


<script type="text/javascript">



</script>



<div class="flex-center position-ref full-height">



	<div class="content">



		<div class="text">



			<center>



			



			</div>



			<center><img src="https://i.ibb.co/2kVcrzX/IMG-20201024-013306.png" height="350" width="350">



			</iframe>



			<br>



			<br>



			<code>



			<br>



			<font color="white" size="5">



			<b><font size="5">Hacked By</font> <font color="red">Tegal6etar1337</font>



			<br>
				
				<br>
				<font size="5">be secure, your security get down!</font>
<br>


			<br>



			



			<br>



			<br>



			




<font color="white"><font size="4">Thanks To <font color="red">:</font> Bandung6etar <font color="red">~</font> 99syndicate <font color="red">~</font> Sorong6etar <font color="red">~</font> Dr. Cruzz : and All indonesian Defacerz </font></font>
			

			<br><br> 

			</font>
			
			<br>
			
		
			<br>
				
			<br>

			</body>



			</html>