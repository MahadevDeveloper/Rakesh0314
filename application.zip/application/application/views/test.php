<!DOCTYPE html><html lang="en">
    <?php 
$res= $this->db->limit(1)->get("setting")->row();

 $mobile=$res->contact_no;


?>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <title>Sattamatka | Matka | Kalyan Matka | Fix Matka</title>
    
    <meta name="description" content="Matka, Satta Matka, Boss Matka, Kalyan Matka Tips, Satta Matka, Matka, Sattamatka, Matka Satta, Matka Charts, Matka Satta Result, Fix Matka"/>
    <link rel="canonical" href="<?= base_url();?>" />
    <link rel="alternate" hreflang="x-default" href="<?= base_url();?>assets/matka/index.html" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
    <link rel="icon" href="<?= base_url();?>assets/matka/fevii.png" type="image/gif" sizes="16x16">

    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="icon" href="<?= base_url();?>assets/matka/images/matka.jpg"/ >
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="yes" name="apple-touch-fullscreen" />
    <meta name="author" content="MatkaSattamatkaWiki" />
    <meta name="copyright" content="matka satta matka" />
    <meta property="og:url" content="index.html" />
    <meta property="og:image" content="images/logo2.jpg" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Matka Satta Matka" />
    <meta property="og:description" content="Matka Sattamatka" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@MatkaSattamatkaWiki?lang=en" /><meta name="twitter:title" content="" /><meta name="twitter:description" content="" /><meta name="twitter:image" content="images/logo.jpg"><meta name="twitter:image:alt" content="MatkaSattamatkaWiki"><meta name="theme-color" content="#F00000"><style>@media print{... CSS for print goes here} </style><style type="text/css">@viewport{width: device-width; zoom: 1.0;}html{box-sizing:border-box}*,:after,:before{box-sizing:inherit;}html{box-sizing:border-box}*,*:before,*:after{box-sizing:inherit;}html{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;}body{margin:0}article,aside,details,figcaption,figure,footer,header,main,menu,nav,section,summary{display:block}audio,canvas,progress,video{display:inline-block}progress{vertical-align:baseline}audio:not([controls]){display:none;height:0}[hidden],template{display:none}html{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;overflow-x: hidden;}body{font-family: Tahoma, Geneva, sans-serif;background:#000;margin:0;text-align:center;width:100%; height:100%;}.white_space{white-space:pre-line;padding:0px 10px;margin:0px;}p,ul li,ol li{margin:0;}ol.text-left li{text-align:left;}ol.text-justify li{text-align:justify;}h1,h2,h3,h4,h5,h6{margin:0px;padding:0px;}.header{background:#000;padding:5px;margin:5px 0px;border:solid 3px #88511F;}.keyword_top{background:#120633;color:#fff;padding:10px;margin:5px 0px;border:solid 3px #3F7AE9;}.header_txt{background:#fff;color:#3B5998;padding:5px;margin:5px 0px;border:solid 3px #3B5998;font-weight:bold;}a{color:#4872CB;text-decoration:none;font-weight:bold;}a:hover{color:#DC3535;}.td_font_size th{font-size:1.2em;padding:8px 5px;margin:0px;text-align:center;}.td_font_size td{font-size:1.2em;padding:8px 3px;margin:0px;text-align:center;}.milan_starline_td{color:#000;font-weight:bold;text-align:center;}.milan_starline_td2{color:#0000FF;font-weight:bold;text-align:center;}.live_update_wiki_com{background:#1c3aac;color:#000;padding:5px;margin:5px 0px;border:solid 3px #825F0A;}.live_update_heading{color:#000;font-size:2em;font-weight:bold;border-top:solid 1px #3B5998;border-bottom:solid 1px #3B5998;}.line_top_bottom{border-top:solid 1px #3E5B99;border-bottom:solid 1px #3E5B99;padding:5px;color: white;}.live_update_title_wiki_com{font-size:1.5em;color:#60F;font-weight:bold;padding:5px;margin:0px;}.live_update_result{font-size:1.5em;color:#F00;font-weight:bold;padding:5px;margin:0px;}.refresh_btn{background:#AF2525;color:#fff;font-size:1.5em;font-weight:bold;padding:5px 10px;}.aug15{font-size:0.8em;}.right{ text-align:right;}.margin_bottom{margin-bottom:20px;}.free{right:5px;position:absolute;background:#FF0000;color:#ffffff;display:block; padding:5px 10px;border-radius:50%;}.header_bottom{color:#fff;background:#481111;border:solid 3px #FF0000;padding:5px;margin:5px 0px;}.kalyan_no{font-size:1.5em; font-weight:bold;color:#fff;background:#481111;border:solid 3px #FF0000;padding:5px;margin:5px 0px;}.heading_title2{color:#fff;background:#235E83;border:solid 3px #062C44;padding:10px 5px;font-size:1.2em;font-weight:bold;}.result_bg_wiki{color:#3B5998;background:#fff;border:solid 3px #BDC6D2;padding:10px 5px;font-size:1.2em;font-weight:bold;}.yellow_bg{background:#F1F15F;color:#000;padding:0px;}.white_bg{background:#fff;}.black_bg{background:#000;}.title_head_wiki{font-size:1em;font-weight:bold;color:#1B2A49;text-shadow:1px 2px #F59191;padding:10px 0px 0px 0px;margin:0px;text-transform:uppercase;}.live_result_number_wiki{color:#F00;text-shadow:1px 2px #9BE075;font-size:1em;font-weight:bold;}.timing_result{color:#000;font-size:0.8em;padding:10px 0px;}.result_timing{font-size:0.6em;color:#000;padding:3px 2px;display:inline-block;float:left;margin-top:-20px;}.result_daily{color:#00F;font-size:1em;font-weight:bold;padding:13px 5px 10px 5px;display:inline-block;}.result_timing_right{font-size:0.6em;color:#000;padding:3px 2px;display:inline-block;float:right;margin-top:-20px;}.kalyan_noti{font-weight:bold;white-space:pre-line;}.hr{padding:0px;margin:0px;border-bottom:solid 1px #3B5998;}.strong{font-weight:bold;}.italic{font-style:italic;}.clear{clear:both;}.text-center{text-align: center;}.text-right{text-align: right;}.block_dis{display:block;}.center{text-align:center;}.padding10{padding:10px 5px;}.link_bg{background:#000;color:#fff;padding:10px;margin:5px 0px;border:solid 3px #333;}.link_bg a{color:#fff;}.call_txt{font-size:1.3em;font-weight:bold;padding:10px;}.links_txt{font-size:100%;font-weight:bold;padding:10px;}.whatsapp_bg{background:#E9EBEE;color:#3B5998;padding:0px 0px;margin:5px 0px;border:solid 3px #3B5998;}.whatsapp_title{background:#19356E;color:#fff;border:dashed 1px #fff;font-size:1.5em;font-weight:bold;padding:10px;}.login_bg{background:#fff;color:#000;border:solid 3px #B62727;margin:5px 0px;}.login_title{background:#481111;color:#fff;border:dashed 1px #fff;font-size:1.5em;font-weight:bold;padding:10px;}.milan_title{background:#6C1D00;color:#fff;border:dashed 1px #fff;font-size:1.5em;font-weight:bold;padding:10px;}.milan_th th{background:#AA6360;}a.btn_link{background:#AA3F3F;color:#FFFF00;padding:10px;font-size:1.2em;display: inline-block;width:150px;border-radius:5px;}a.btn_link:hover{background:#FF0049;color:#fff;border-radius:20px;}.daily_game_bg{background:#fff;color:#000;border:solid 3px #3B5998;margin:5px 0px;}.heading_title3{background:#BD496A;color:#fff;border: dashed 1px #fff;padding:10px 5px;font-size:100%;font-weight:bold;}.daily_game_bg a{display: inline-block;margin:10px 0px;text-align:center;width:90%;}a.game_zone_btn{background:#fff;color:#000;border:solid 2px #E70042;box-shadow:1px 2px 5px #333;padding:10px;font-size:1em; border-radius:5px;}a.game_zone_btn:hover{background:#E70042;color:#fff;border-radius:20px;}a.game_zone_btn.active{background:#E70042;color:#fff;border-radius:20px;}.jodi_chart_bg{background:#D8F0ED;color:#000;border:solid 3px #9E9E9E;margin:5px 0px;}.heading_title5{background:#000;color:#E28645;padding:10px 5px;font-size:1.3em;font-weight:bold;}.jodi_btn{padding:10px;}.jodi_btn a{display:block;background:#CBD5D9;color:#043E58;border:solid 2px #043E58;box-shadow:1px 2px 5px #333;margin:10px 0px;padding:10px;}.jodi_btn a:hover{background:#043E58;color:#fff;border:solid 2px #3F9AC2;}.panel_chart_bg{background:#EDDBE1;color:#000;border:solid 3px #B26016;margin:5px 0px;}.heading_title6{background:#000;color:#DDDF29;padding:10px 5px;font-size:1.3em;font-weight:bold;}.panel_btn{padding:10px;}.panel_btn a{display:block;background:#ECECEC;color:#810A2E;border:solid 2px #810A2E;box-shadow:1px 2px 5px #333;margin:10px 0px;padding:10px;}.panel_btn a:hover{background:#810A2E;color:#fff;border:solid 2px #CC4E74;}.panel_chart_bg td{color:#000;}.date_fix_bg{background:#000;color:#fff;border:solid 3px #940F24;margin:5px 0px;}.heading_title4{background:#466B1B;color:#fff;padding:10px 5px;font-size:1.3em;font-weight:bold;}.aaj_kya_bg{background:#111111;color:#fff;border:solid 3px #BF167A;margin:5px 0px;}.heading_title7{background:#FD5D8C;color:#fff;padding:10px 5px;font-size:1.3em;font-weight:bold;}.search_bg{background:#ffffff;color:#000;border:solid 3px #3B5998;margin:5px 0px;}.heading_title8{background:#235E83;color:#fff;border: dashed 1px #fff;padding:10px 5px;font-size:1.3em;font-weight:bold;}.samaj_bg{background:#000;color:#fff;border:solid 3px #EB028B;}.heading_title9{background:#1ABC9C;color:#000;padding:10px 5px;font-size:1.3em;font-weight:bold;}.smm_bg{background:#fff;color:#000;border:solid 3px #956F13;}.heading_title10{background:#DCAF42;color:#000;border: dashed 1px #fff;padding:10px 5px;font-size:1.3em;font-weight:bold;}.sm_bg{background:#fff;color:#000;border:solid 3px #3B5998;margin:5px 0px;}.heading_title11{background:#3B5998;color:#fff;border: dashed 1px #fff;padding:10px 5px;font-size:1.3em;font-weight:bold;}.makes_bg{background:#fff;color:#000;border:solid 3px #3B5998;margin:5px 0px;}.heading_title12{background:#B0851E;color:#fff;border: dashed 1px #fff;padding:10px 5px;font-size:1.3em;font-weight:bold;}.useful_bg{background:#1F1B29;color:#fff;border:solid 3px #FF4B9A;margin:5px 0px;}.heading_title13{background:#000;color:#2574D6;padding:10px 5px;font-size:1.3em;font-weight:bold;}.useful_bg a{color:#FF4B9A;padding:3px;line-height:25px; display:block;}.useful_bg a:hover{color:#1A3EF5;padding:3px;line-height:25px;}.heading_title20{background:#FFF9D7;color:#253862;border: dashed 1px #253862;padding:5px 5px;margin:10px 0px;font-size:1em;font-weight:bold;}ul.left{text-align:left;}a.link_hover{color:#FFD700;}.btn_tricks_zone{margin:15px 5px;}.btn_tricks_zone a{padding:10px 20px;background:#000;color:#fff;display:inline-block;border-radius:20px;}.btn_tricks_zone a:hover{background:#639;color:#fff;}.headings h2, .headings h3, .headings h4, .headings h5, .headings h6{font-size:0.1em;position:absolute;margin:0px;padding:0px;color:#000;}.ex1{width:100%;overflow-y:scroll;max-height:150px;font-size:14px;padding:0px;text-align:justify;font-weight:500;line-height:22px;}.refresh_button{background:#AA3F3F;color:#FF0;padding:10px 40px;border-radius:5px;font-weight:bold;margin:10px;}.frm_design input[type=text], input[type=password], input[type=email]{width:80%;background:#CCC;color:#000;border:solid 1px #999;padding:5px;text-align:center;}.bg_color1 td{background:#FF9;}.frm_design textarea{width:80%;background:#CCC;color:#000;border:solid 1px #999;padding:5px;text-align:center;}.samaj_seva{text-align:center;background:#CBD5D9;color:#043E58;border:solid 1px #CF0;border-radius:5px;}.frm_design2 input[type=text]{width:50px;background:#eee;color:#000;font-size:1.2em;font-weight:bold;border:solid 1px #999;padding:10px 2px;text-align:center;}.frm_design3 input[type=text]{background:#eee;color:#000;font-size:0.9em;font-weight:bold;border:solid 1px #999;padding:10px 1px;text-align:center;}td.red{color:#F00;}.padding0{padding:0px;margin:0px;}.red{color:#F00;}.green_f{color:#090;}.blue_f{color:#00F;}.red2{background:#F00;color:#fff;}.blue{background:#00F;color:#fff;}.black{color:#000;}.red_bg{background:#E42626;}.light_gray_bg{background:#eee;}.orange_dark_bg{background:#A24C2E;}.golden_bg{background:#DCAF42;}.blue_dark_bg{background:#235E83;}.red_dark_bg2{background:#481111;}.pink_dark_bg{background:#BD496A;}.pink_dark2_bg{background:#810A2E;}.light_green_bg{background:#89C36F;}.blue_gray_bg{background:#1F4F63;}.border_white{border-radius:5px;border:solid 1px #fff;}.border_orange_dark{border-radius:5px;border:solid 1px #A24C2E;}.border_red{border-radius:5px;border:solid 1px #F00;}.border_dark_red{border-radius:5px;border:solid 1px #481111;}.border_yellow{border-radius:5px;border:solid 1px #FC3;}.border_golden{border-radius:5px;border:solid 1px #E7920D;}.border_dark_pink{border-radius:5px;border:solid 1px #BD496A;}.border_dark_pink2{border-radius:5px;border:solid 1px #810A2E;}.border_green{border-radius:5px;border:solid 1px #0C0;}.border_blue_gray{border-radius:5px;border:solid 1px #1F4F63;}.blue_bg{background:#00F;color:#fff;}.red_bg{background:#F00;color:#fff;}.btn {display: inline-block;border-radius: 4px;border: none;color: #FFFFFF;text-align: center;text-transform: uppercase;font-size: 18px;padding:10px 10px;transition: all 0.4s;cursor: pointer;margin: 5px;}.refresh_button2{background:#D93529;color:#fff;font-weight:bold;font-size:1em;border-radius:5px;position:fixed;bottom:50px;right:5px;padding:5px 10px;}.matka_play_app{background:#D93529;color:#fff;font-weight:bold;font-size:0.8em;border-radius:5px;position:fixed;bottom:5px;left:5px;padding:5px 5px;}.callus_button{background:#2064FE;color:#fff;font-weight:bold;font-size:1em;border-radius:5px;position:fixed;bottom:10px;right:5px;padding:5px 10px;}.padding2_5{padding:2px 5px;}a.btn_jodi{background:#481111;color:#fff;border:solid 2px #FF0000;font-size:1em;font-weight:bold;padding:5px 5px;display:inline-block;}.btn-success{color: #000;background-color: #A5D993;}.btn-warning{color: #000;background-color: #F0E08C;}.btn-purpal{color: #fff;background: linear-gradient(to right, #67b26b, #4ca2cb) !important;}.btn-purpal:hover{color: #000;background: linear-gradient(to left, #67b26b, #4ca2cb) !important;}.kalyan_txt{height: 80px; background-color: red;background-image: radial-gradient(red 5%, #000 15%, #333 60%);border:solid 3px #FF0;margin:3px 0px;}.kalyan_heading{padding:18px 5px;}.kalyan_heading a{color:#fff;font-size:1.5em;font-weight:bold;text-shadow:1px 1px 5px #000;}.grad2 {height: 80px;background-color: red;background-image: radial-gradient(circle, #000, #1ABC9C, #000);border:solid 3px #4BA593;margin:3px 0px;}.search_related2 a{background: linear-gradient(110deg, #ffed4b 50%, #fdcd3b 50%);border:solid 3px #B0851E;color:#000;margin:10px;font-size:1.3em;padding:10px;display:block;}.search_related2{color:#000;background: linear-gradient(110deg, #96BBD2 60%, #C7E9FE 60%);border:solid 3px #FF0;margin:3px 0px;padding:10px;font-size:1.2em;font-weight:300;}.search_related{color:#000;background: linear-gradient(110deg, #B8E2A5 60%, #F3E1B5 60%);border:solid 3px #FF0;margin:3px 0px;padding:10px;font-size:1.2em;font-weight:300;}.search_related a{background: linear-gradient(110deg, #819BD1 50%, #A4BEF4 50%);border:solid 3px #3B5998;color:#000;margin:10px;font-size:1.1em;padding:10px;display:block;}.ap_section a{background:#AD5405;border:solid 3px #CAA431;color:#fff;margin:10px;font-size:1.1em;padding:10px;display:block;border-radius:30px;}.ap_section{color:#fff;background: linear-gradient(110deg, #000 50%, #333 50%);border:solid 3px #979797;margin:3px 0px;padding:10px;font-size:1.3em;font-weight:300;}.play_sm{font-size:1.3em;font-weight:bold;color:#FF0;}
.ap_section2 a{background:#FCB700;border:solid 3px #B36600;color:#8D0F03;margin:10px;font-size:1.1em;padding:10px;display:block;border-radius:30px;}.ap_section2{color:#fff;background-color: #330000;background-image: linear-gradient(315deg, #330000 0%, #660303 74%);;border:solid 3px #979797;margin:3px 0px;padding:10px;font-size:1.3em;font-weight:300;}.play_sm2{font-size:1.3em;font-weight:bold;color:#ffffff;}
.ap_section2 p{color:#ffffff;font-size:0.8em;}.ap_section2 .matka{color:#FDB900; font-size:1.2em; font-weight:bold;}
.card-holder{border:solid 3px #fff;}.card{font-family: -apple-system, BlinkMacSystemFont, 'Open Sans', sans-serif;font-size:1.5em;font-weight: 800;width:100%;padding: 0.5em 0em;border-radius:0em;/*display: table-cell;*/vertical-align: middle;letter-spacing:0px;box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);}.bg-germany{text-shadow:1px 1px 4px #000;color: #fff;background: -webkit-linear-gradient(110deg, #3B5998 50%, rgba(0, 0, 0, 0) 50%), -webkit-linear-gradient(110deg, #3B5998 50%, #89C36F 66%);background: -o-linear-gradient(110deg, #3B5998 50%, rgba(0, 0, 0, 0) 50%), -o-linear-gradient(110deg, #3B5998 50%, #89C36F 66%);background: -moz-linear-gradient(110deg, #3B5998 50%, rgba(0, 0, 0, 0) 50%), -moz-linear-gradient(110deg, #3B5998 50%, #89C36F 66%);background: linear-gradient(110deg, #3B5998 50%, rgba(0, 0, 0, 0) 50%), linear-gradient(110deg, #3B5998 50%, #89C36F 66%);}.menu_margin{margin:10px 0px;}.menu_set{font-size:30px;cursor:pointer;color:#fff;float:right;}.overlay{height: 100%;width: 0;position: fixed;z-index: 1;top: 0;left: 0;background-color: rgb(0,0,0);background-color: rgba(0,0,0, 0.9);overflow-x: hidden;transition: 0.5s;}.overlay-content{position: relative;top: 25%;width: 100%;text-align: center;margin-top: 30px;}.overlay a{padding: 8px;text-decoration: none;font-size:18px;color: #fff;display: block;transition: 0.3s;}.overlay a:hover, .overlay a:focus{color: #f1f1f1;}.overlay .closebtn{position: absolute;top: 20px;right: 45px;font-size: 60px;}p.key_set{font-size:0.2em;padding:0px;margin:0px;color:#666;}table{border:0px solid #8E8E8E;margin:10px 0px;border-collapse: collapse;}table th{padding:5px 10px;text-align:left;background-color:#5B9248;color:white;border-collapse: collapse;}table td{padding:5px 10px;border:0px solid #8E8E8E;border-collapse: collapse;}tr:hover{background-color:#ddd;}tr:nth-child(odd) {background-color: #fff;border-top:1px solid #8E8E8E;}tr:nth-child(even) {background-color: #f2f2f2;border-top:1px solid #8E8E8E;}table td.chart_date{text-align:center;}table .td_center td{text-align:center;}.td_red{color:#ff0000;font-size:1.5em;font-weight:600;}.td_black{color:#000000;font-size:1.5em;font-weight:600;}.chart-bold{color:#000000;font-size:1.5em;font-weight:600;}td.td_red{color:#ff0000;font-size:1.5em;font-weight:600;}td.td_black{color:#000000;font-size:1.5em;font-weight:600;}td.chart-bold{color:#000000;font-size:1.5em;font-weight:600;}.table_set td{border:solid 1px #000;}.ank_big{ font-size:1.6em; font-weight:bold;}
.notice_bg{color:#000;background:#AABDD3;border:solid 3px #F5A623;margin:3px 0px;padding:10px;font-size:1.2em;font-weight:300; font-style:italic; font-size:1em;}.notice_title{ font-size:1.2em; color:#FFFF00;background:#2C496B; font-weight:bold;}.notice_bg div{ border-bottom:dashed 1px #000000; margin:9px 0px;}.notice_bg span{ color:#FF0000; font-weight:600;}.notice_bg span.strong{ color:#000000; font-weight:600;}.notice_title2{ font-size:1.2em; color:#ffffff;background:#FF0000; font-weight:bold;}.notice_bg_rep{color:#000;background:#FFFFFF;border:solid 3px #0000FF;margin:3px 0px;padding:10px;font-size:1.2em;font-weight:300; font-style:italic; font-size:1em;}.notice_title_rep{ font-size:1.2em; color:#ffffff;background:#FF6100; font-weight:bold;}.notice_bg_rep div{ border-bottom:dashed 1px #0000FF; margin:9px 0px;}.notice_bg_rep span{ color:#0000FF; font-weight:600;}.notice_bg_rep span.strong{ color:#000000; font-weight:600;}.notice_title2_rep{ font-size:1.2em; color:#ffffff;background:#008D3F; font-weight:bold;}.padding_tb_30{padding:30px 0px;}
/* ====== cube ==========*/
.cube_border{color:#ffffff;background:#000000;border:solid 3px #7EC5BC;margin:5px 0px;}.scene {  width: 250px;  height: 250px;  margin: 75px auto 85px;  perspective: 1200px;}.cube {  position: relative;  width: 250px;  height: 250px;  transform-style: preserve-3d;  animation: example 10s linear infinite;}.side {  position: absolute;  width: 250px;  height: 250px;  box-sizing: border-box;  border: 5px solid #9aa;  background-color: rgba(32, 170, 151, 0.5);  padding: 100px 0;  font: 50px/1 'Trebuchet MS', sans-serif;  color: #fff;  text-transform: uppercase;  text-align: center;}.back{transform: translateZ(125px);}.top{transform: translateY(-125px) rotateX(90deg);}.bottom{transform: translateY(125px) rotateX(90deg);}.front{transform: translateZ(-125px) ;}.top, .bottom {background-color: rgba(105, 136, 190, 0.5)}@keyframes example {100% { transform: rotateX(360deg);}}
/*===cube 2 ===*/
.element{	top:100px;  display: inline-block;  background-color: #0074d9;  height: 70px;  width: 40px;  font-size: 25px;  color:#ffffff;  line-height:70px;  margin-right: 27px;  margin-left: 5px;  -webkit-animation: roll 3s infinite;          animation: roll 3s infinite;  transform: rotate(30deg);  opacity: 0.9;}@-webkit-keyframes roll{  0% {    transform: rotate(0);  }  100% {    transform: rotate(360deg);  }}@keyframes roll{  0% {    transform: rotate(0);  }  100%{    transform: rotate(360deg);  }}
@media screen and (max-height: 450px){.overlay a {font-size: 20px}.overlay .closebtn{font-size: 40px;top: 15px; right: 35px; }}@media screen and (max-width:1440px){}@media screen and (max-width:1366px){}@media screen and (max-width:1280px){}@media screen and (max-width:1080px){}@media screen and (max-width:1024px){}@media screen and (max-width:991px){}@media screen and (max-width:812px){}@media screen and (max-width:768px){.row{margin-right:0;margin-left:0;}.trapezium{width:100%;left:0%;}}@media screen and (max-width:767px){}@media screen and (max-width:736px){}@media screen and (max-width:667px){}@media screen and (max-width:640px){}@media screen and (max-width:600px){.app img{width:100%; height:100%;}}@media screen and (max-width:568px){.app img{width:100%; height:100%;}}@media screen and (max-width:480px){.mob_block{display:block;}.trapezium{width:100%;left:0%;}.mob_font_size_1_6{font-size:1.6em;}table{width:100%;}.panel_chart_bg table th{padding:5px 0px;text-align:left;background-color:#4CAF50;color:white;font-size:0.8em;border-collapse: collapse;}.panel_chart_bg table td{padding:5px 2px;font-size:0.55em;border:0px solid #fff;border-collapse: collapse;}table tr td:second{border-left:1px solid #fff;}tr:nth-child(odd) {background-color: #fff;border-top:1px solid #8E8E8E;}tr:nth-child(even) {background-color: #f2f2f2;border-top:1px solid #8E8E8E;}table td.chart_date{text-align:center;font-size:0.55em;}.td_red{font-size:1.6em;font-weight:bold}.td_black{font-size:1.6em;font-weight:bold;}.chart-bold{font-size:1.6em;font-weight:bold;}.panel_chart_bg table td.td_red{font-size:0.8em;font-weight:bold;}.panel_chart_bg table td.td_black{font-size:0.8em;font-weight:bold;}.td_font_size th{font-size:1.1em;}.td_font_size td{font-size:1.1em;}table.mobile2 th{text-alien:center; font-size:1em;}.mobile2 .milan_starline_td{font-size:1.2em;}.mobile2 .milan_starline_td2{font-size:1.2em;}.center td{ text-align:center;}}@media screen and (max-width:414px){.app img{width:100%; height:100%;}.app img{width:100%; height:100%;}}@media screen and (max-width:384px){.app img{width:100%; height:100%;}}@media screen and (max-width:375px){.app img{width:100%; height:100%;}}@media screen and max-width:320px){.app img{width:100%; height:100%;}}@media screen and (max-width:240px){img.img-responsive{width:80%; height:100%;}.app img{width:100%; height:100%;}}</style><script async src="<?= base_url();?>assets/matka/https://www.googletagmanager.com/gtag/js?id=UA-113909704-1" ></script><script>  window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'UA-113909704-1');</script><script type="application/ld+json">{  "@context": "https://schema.org", "@type": "Blog", "url": "https://Matka/blog" }</script><script type="application/ld+json">{ "@context": "https://schema.org", "@type": "Organization", "name": "MATKA SATTA MATKA WIKI", "url": "https://Matka/", "address": "Mumbai",  "sameAs": [  "https://www.facebook.com/1Sattamatka.WIKI", "https://twitter.com/Sattamatkawiki?lang=en"  ]  }</script><meta name="google-site-verification" content="GWUjxOsZbyawYa-o7_6ryb1SwSU67qSqS_UJ77KIc_8"/><script type="application/ld+json">{"@context": "https://schema.org","@type": "Blog","url": "https://Matka/blog"}</script><script type="application/ld+json">{"@context": "https://schema.org/","@type": "Website","name": "Matka Satta Matka","url": "https://Matka"}</script>
<!-- right click disable  start -->

<style>
    .header {
    background: black;
    padding: 5px;
    margin: 5px 0px;
    border: solid 3px #88511F;
}

.result_bg_wiki {
    color: #3B5998;
    background: #fff;
    border: none;
    padding: 0px !important; 
    font-size: 1.2em;
    font-weight: bold;
}

.header_txt {
    background: #080707;
    color: #3B5998;
     padding: 0px ; 
     margin: 0px ; 
    border: solid 3px #3B5998;
 font-weight: bold;
}


.live_update_wiki_com {
    background: #ffffff;
    color: #000;
     padding: 0px !important; 
    margin: 5px 0px;
    border: solid 3px #0932ff;
}



.header_bottom {
    color: #fff;
    background: #8e8e8ed1;
    border: solid 3px #cbd5d9;
    padding: 5px;
    margin: 5px 0px;
}

.live_update_heading {
    color: #ffffff;
    font-size: 2em;
    font-weight: bold;
    border-top: solid 1px #2c4d93;
    border-bottom: solid 1px #3B5998;
    background-color: blue;
}

.live_update_title_wiki_com {
    font-size: 1.5em;
    color: #000000;
    font-weight: bold;
    padding: 5px;
    margin: 0px;
}

.live_update_result {
   font-size: 1.5em;
    color: #d31e1e;
    font-weight: bold;
    padding: 5px;
    margin: 0px;
    background-color: #fff;
   
}

.live_update_title_wiki_com{
        background-color: #fff;
}

.refresh_btn {
    background: #810a2e;
    color: #fff;
    font-size: 1.5em;
    font-weight: bold;
    padding: 10px 16px;
    border-radius: 10px;
    box-shadow: 1px 3px 10px 3px #6c6262cf;
     margin-top: 5px;
         margin-bottom: 10px;
}

.header_bottom {
    color: #fff;
    background: #aa3f3f;
    border: solid 3px #cbd5d9;
    padding: 5px;
    margin: 5px 0px;
}

.ap_section {
    color: #fff;
    background: linear-gradient(
110deg, #e1a7a7 50%, #e1a7a7 50%);
    border: solid 3px #fdfdfd;
    margin: 3px 0px;
    padding: 10px;
    font-size: 1.3em;
    font-weight: 300;
}

.ap_section a {
    background: #878787;
    border: solid 3px #CAA431;
    color: #fff;
    margin: 10px;
    font-size: 1.1em;
    padding: 10px;
    display: block;
    border-radius: 30px;
}

.search_related2 {
    color: #000;
    background: linear-gradient(
110deg, #999 60%, #999999 60%);
    border: solid 3px #aa3f3f;
    margin: 3px 0px;
    padding: 10px;
    font-size: 1.2em;
    font-weight: 300;
}

.search_related2 a {
    background: linear-gradient(
110deg, #eee 50%, #eeeeee 50%);
    border: solid 3px #B0851E;
    color: #000;
    margin: 10px;
    font-size: 1.3em;
    padding: 10px;
    display: block;
}

.yellow_bg {
    background: #c1c19a;
    color: #000;
    padding: 0px;
}

.element{
        border-radius: 50%;
        background-color: #d90000;
        box-shadow: 0px 0px 12px 10px #eeeeee94;
}

.heading_title9 {
    background: purple;
    color: #000;
    padding: 10px 5px;
    font-size: 1.3em;
    font-weight: bold;
}

#chart_hov:hover {
  background-color: #c10000;
  color: white;
  border: solid 2px #c10000;
}

#chart_hove:hover {
  background-color: #c10000;
  color: white;
  border: solid 2px #c10000;
}

#panrl_hove:hover {
  background-color: #c10000;
  color: white;
  border: solid 2px #c10000;
}

#regbut:hover {
    background-color: #c10000;
  color: white;
  border: solid 2px #c10000;
}

a.btn_jodi {
    background: #481111;
    color: #fff;
    border: solid 2px #481111;
    font-size: 1em;
    font-weight: bold;
    padding: 8px 15px;
    display: inline-block;
    border-radius: 10px;
    box-shadow: 1px 3px 10px 3px #6c6262cf;
}

.cube_border {
    color: #ffffff;
    background: #000000;
    border: solid 3px purple;
    margin: 5px 0px;
}

.disclam{
        text-align: center;
    margin-bottom: 15 px !important;
    background-color: rgb(3 107 155)!important;
    color: #fff;
    padding: 10 px;
    text-transform: uppercase;
    font-size: 24px;
    font-family: sans-serif;
    font-weight: 700;
    padding: 11px;
}

.pap {
        font-family: serif;
    font-size: 15px;
    color: #ffffff;
    line-height: 1.75;
    background-color: black;
    text-transform: capitalize!important;
    font-size: 20px!important;
    font-style: italic!important;
    padding: 10px 10px !important;
}

.foot {
    padding: 10px 0;
    margin-top: 5px;
    border: 1px solid rgb(3 107 155);
}
.bg-light {
    background-color: #fff;
}

.btncss {
    margin: 8px;
    font-weight: 700;
    font-family: sans-serif;
    color: #fff;
    background-color: rgb(6 49 151);
    padding: 8px 25px;
    border: 5px;
    font-size: 22px;
    border-radius: 8px;
}
.bg-green {
    background-color: rgb(44 151 6);
}

.list-inline {
    list-style: none;
    margin-right: 45px;
}

.alink{
    color: white;
}

.text-danger {
    color: red;
}

.passing-head {
    background: rgb(118 11 155);
    color: #fff;
    font-size: 22px;
    font-weight: 600;
    padding: 10px;
}

.leakgame {
    text-transform: uppercase;
    text-align: center;
    background-color: rgb(0 0 0);
    margin-top: 5px;
    color: #fff;
    border: 1px solid rgb(214 11 11);
}

.leakhead, .searchhead, .searchrelated {
    text-align: center;
    text-transform: uppercase;
    font-size: 18px;
    background: #bc9f0a;
    padding: 15px;
    font-weight: 700;
    font-family: sans-serif;
}

.content {
    padding: 10px;
    font-style: normal;
}

.line_top_bottom {
    border-top: solid 1px #3E5B99;
    border-bottom: solid 1px #3E5B99;
    padding: 5px;
    color: black;
    background-color: white;
}

.paass{
        border: solid 3px #760b9b;
}

.chatt{
    border: 2px solid #f1f15f;
}

</style>

</head>

<?php 
$res= $this->db->limit(1)->get("setting")->row();

 $mobile=$res->contact_no;
 
?>

<body id="btned" oncontextmenu="return false"><div class="header"><a href="<?= base_url();?>" title="Matka Sattamatka Matka">

<img loading=lazy border="0" src="<?php echo base_url($res->logo); ?>" alt="Satta Matka Sattamatka Matka Satta" title="Matka Sattamatka Matka" style="width: 100%;
    height: 100px; border-radius: 10px;" class="img-responsive" />


</a></div><div class="menu_margin"><div id="myNav" class="overlay"><a href="<?= base_url();?>assets/matka/javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a><div class="overlay-content"><a href="<?= base_url();?>assets/matka/index.html">HOME</a><a href="<?= base_url();?>assets/matka/kalyan-chart/index.html">SATTA MATKA CHART ZONE</a><a href="<?= base_url();?>assets/matka/kalyan-chart/index.html">SATTA MATKA PANEL CHART ZONE</a><a href="<?= base_url();?>assets/matka/kalyan-satta-result/index.html">SPECIAL GAME ZONE</a><a href="<?= base_url();?>assets/matka/matka-guessing/index.html">EXTRA GAME ZONE</a><a href="<?= base_url();?>assets/matka/dmca/index.html">DMCA</a></div></div></div><div class="header_bottom">Satta Matka, Satta, Matka, Kalyan Chart Kalyan Open, Matka, Matka Results, Kalyan Matka, Fastest Matka Results, Live Results, Kalyan Open Jodi, Kalyan Tips, Fix Matka, Matka Guessing, Matka Game, Matka Number, Mumbai Fix Game, Satta Batta, Satta Market, Matka Boss, Sattaking 143 Guessing, Matka 420, Kalyan Panel Chart, Sattamatka143, Tara Matka, Golden Matka, Matka Guessing 143, Satta Tips, Satta King, Time Bazar, Jodi and Panel Chart, Indian Matka, Satta Night.</div><div class="live_update_wiki_com">

<div class="live_update_heading">LIVE ZONE RESULTS</div>
<!-- <div> -->

<?php foreach($get_data as $row) { ?>

<?php 

$a = date_default_timezone_set('Asia/Kolkata');

 $present_time = date('H:i ', time()); 


$time  = 25*60;

 $new_start_time=date('H:i ',strtotime($row['starttime'])-$time); 

  $new_end_time=  date('H:i ',strtotime($row['endtime'])+$time); 

?>


<?php if($present_time>=$new_start_time && $present_time<=$new_end_time){?>
<p class="live_update_title_wiki_com"><?= $row['gamename'];?></p>


<p class="live_update_result"><?php $aa= $row['game_number'];
                     
                     $km="";$j=0;
                     
                      for($i=0; $i<10;$i++)
                      {
                         
                          if($aa[$i] == '*'){ 
                              if($aa[4] != '*'){
                                  echo $aa; break;
                                  }
                            ?>
                               <?php echo $aa; $km=""; ?>
                               <p> <img  class="" src="<?php echo base_url('assets/matka/unnamed.gif'); ?>"  /> </p>
                     <?php  break; }else{
                         $j++;
                    }
                }
          ?>
          <?php if($j==10){
              echo $aa;
           ?>
           <p> <img  class="" src="<?php echo base_url('assets/matka/unnamed.gif'); ?>"  /> </p> <?php }  ?>
</p> 

<?php }else{ ?> 
<?php } } ?>


<div class="clear margin10"></div><p class="line_top_bottom">Sabse Tej Live Results Ke Liye Yahi Bane Rahe</p><input class="refresh_btn" type="button" id="regbut" onclick="window.location.reload()" value="Refresh"><div class="clear"></div></div>
<div class="keyword_top- header_bottom"><strong>Matkareport.com Website</strong> provides you Satta Matka, Sattamatka, Matka, Satta, Kalyan Matka Jodi open to close panel for everyday. <strong>Satta Matka</strong> gameplays and wins all people through Matkareport.com site. We always gives you satta matka kalyan, Milan  Day Night, Rajdhani Day Main Ratan, and time Satta Bazar perfect game. Online matka industry opening results, Quickly publish all satta market results on Sattamatka.wiki. Games update on our website, top guesser team suggest you best satta bazar tips and trick with best evergreen games. Public need fastest result and daily game, admin all-time full fill his work on <strong>Satta Matka</strong>. Matka is World No.1 Best Matka Website. This Website is extremely Good Service Provider Matka Site May I Help the other Poor People. Satta Matka, Matka, Satta, Indian Matka, Matka Result, Boss Matka, Matka Jodi Fix, Satta Matka 143, Sattamatka, Fix Satta Matka Jodi, Kalyan Matka Jodi, Kalyan Matka Tips, Kalyan hospitable Close, Mumbai hospitable Close, Satta Batta, Indian Satta, Satta Matka Office. This is often often often a All Keywords World Best Matka Single Ank Game Leaker.</div>

   <div class="search_related2">Play Daily Earn Daily <br>Download Now<br><a href="<?= base_url();?>">SATTAMATKA BULL</a>This App is 100% Trusted</div><p class="heading_title2">SABSE FAST SATTA MATKA RESULT</p>

<div class="result_bg_wiki chatt">
    
    <?php foreach($get_data as $row) { ?>
    
<?php $res = $this->db->get_where('add_game', array('id'=> $row['game_id']))->row_array(); ?>
<?php $resa = $this->db->get_where('description_data', array('game_id'=> $res['id'], 'status'=> '1'))->row_array(); ?>    
    
    <?php if(!empty($resa['description'])) { ?>
    
<div class="" style="background-color: #f1f15f; border: 2px solid #68685e;"><!-- <div> --><div class="title_head_wiki"><?= $row['gamename'];?></div><!-- </div> -->

<div class="live_result_number_wiki"><?= $row['game_number'];?></div> 

<div class="result_timing"><?= $row['starttime'];?><br /><br />

<a href="<?= base_url();?>welcome/matka/<?= $row['game_id'];?>" class="btn_jodi" id="chart_hov">Jodi Chart</a>

</div><div class="result_daily"> <?php if($row['run_week'] == 7){
                                    echo "Daily";
                                }elseif($row['run_week'] == 6){
                                    echo "Mon To Sat";
                                }else{
                                    echo "Mon To Fri";
                                } ?>
</div><div class="result_timing_right"><?= $row['endtime'];?><br /><br />

<a href="<?= base_url();?>welcome/panel_chart/<?= $row['game_id'];?>" class="btn_jodi" id="panrl_hove">Panel Chart</a></div><br />

<hr>

</div>

<?php } else { ?>

<div class=""><!-- <div> --><div class="title_head_wiki"><?= $row['gamename'];?></div><!-- </div> -->

<div class="live_result_number_wiki"><?= $row['game_number'];?></div> 

<div class="result_timing"><?= $row['starttime'];?><br /><br />

<a href="<?= base_url();?>welcome/matka/<?= $row['game_id'];?>" class="btn_jodi" id="chart_hove">Jodi Chart</a>

</div><div class="result_daily"> <?php if($row['run_week'] == 7){
                                    echo "Daily";
                                }elseif($row['run_week'] == 6){
                                    echo "Mon To Sat";
                                }else{
                                    echo "Mon To Fri";
                                } ?>
</div><div class="result_timing_right"><?= $row['endtime'];?><br /><br />

<a href="<?= base_url();?>welcome/panel_chart/<?= $row['game_id'];?>" class="btn_jodi" id="panrl_hove">Panel Chart</a></div><br />

<hr>

</div>

<?php } ?>

<?php $res = $this->db->group_by('id')->get_where('add_game', array('id'=> $row['game_id']))->row_array(); ?>
<?php $resa = $this->db->get_where('description_data', array('game_id'=> $res['id'], 'status'=> '1'))->row_array(); ?>
      
<?php if(!empty($resa['description'])) { ?>
      
<div class="" style="background-color: #f1f15f; border: 2px solid #68685e;">
    <div class="">
        <p style="font-size: 17px;
    color: black;">
            <?= $resa['description'];?>
        </p>
    </div>    
</div>

<hr>

<?php } else { ?>

<?php } ?>

<?php }

?>

</div>

<div class="result_bg_wiki">

<?php foreach($get_page_data as $row) { ?>

<?php $a = date('d-m-Y'); 
      $b = date('D');
?>

<div class="clear"></div>
<div class="cube_border">
<div class="heading_title6"><?= $row['gamename'];?></div>
<div class="heading_title9">तारीख <?= $a; ?> <?= $b;?></div>
<div class="padding_tb_30">
    
    <?php $mun = $row['game_number']; 
         // echo $mun[0];
    ?>
    
<div class="element"><?php echo $mun[0];?></div>
<div class="element"><?php echo $mun[1];?></div>
<div class="element"><?php echo $mun[2];?></div>
<div class="element"><?php echo $mun[3];?></div>
</div>
</div>

<?php } ?>

</div>

<div class="result_bg_wiki paass">

<div class="passing-record">
<div class="passing-head"> Daily Passing Record
</div>
<?php $mackk = $this->db->get_where('passing_record',array('id'=> '1'))->row_array(); ?>
<br>
<div style="text-align:center;font-style: normal;">
<h2 style="white-space: nowrap; line-height: 35px; text-align: center; font-family: "><span style="font-weight: bold;">&nbsp;</span>Date :  <?= $a; ?></h2>
<hr style="width:50%;border-top:1.5px solid black">

<?= $mackk['description'];?>

<p style="font-family: " open="" sans";"=""><br></p>

</div>




<div style="padding: 0px;text-align:center;font-family:Montserrat;font-style:italic;font-weight:bold;font-size:20px;color:rgba(255, 255, 255, 1);text-transform:uppercase;background:rgba(34, 85, 161, 1)">vip membership charges</div>

<h2 style="font-family: Open Sans;"><span style="font-family: " open="" sans";="" font-size:="" 1.5rem;"=""><br></span></h2>

<?php $membership_charges = $this->db->get_where('membership_charges',array('id'=> '1'))->row_array(); ?>

<?= $membership_charges['description'];?>

<!--<h4 style="font-family: " open="" sans";"="">Vip (1 Day :- Rs.3100)</h4>
<h4 style="font-family: Open Sans;"><br>Vip (1 Week :- Rs.5100)</h4>
<h4 style="font-family: Open Sans;"><br>Vip (15 Days :- Rs.8100)</h4>
<h4 style="font-family: Open Sans;"><br>Vip (1 Month :- Rs.10500)</h4>-->

<p style="font-family: " open="" sans";"=""><br></p>
<div style="padding: 0px;text-align:center;font-family:Montserrat;font-style:italic;font-weight:bold;font-size:20px;color:rgba(255, 255, 255, 1);text-transform:uppercase;background:rgba(34, 85, 161, 1)">call for booking vip game</div>

</div>



<p style="font-family: " open="" sans";"=""><br></p>



<h3 style="font-family: Open Sans;"><b>Call Matka</b></h3><h2 style="font-family: "><font color="#ff0000"><b><?=$mobile;?></b></font></h2>

</div>

<?php $leak_game = $this->db->get_where('leak_game',array('id'=> '1'))->row_array(); ?>

<div class="leakgame">
<div class="leakhead">
Matka MATKA LEAK GAME </div>
<div class="content">
    
    <?= $leak_game['description'];?>
    
<br>
<h2 class="bg-light py-5 text-danger">Jiska Advance Charge Rs. 3100/- Hoga</h2>
<br>
<h2 class="text-light">Call Matka</h2>
<h2 class="text-warning my-2"><?=$mobile;?></h2>
<br>
</div>
</div>


<div class="search_bg">
<div class="heading_title8">MATKA RELATED SEARCHES</div>
<div class="white_space">

  Satta Matka , Fastest Matka Result , Kalyan Matka , Matka Guessing 143 , Boss Matka , Matka Open Close , Satta Matka Jodi Number , Matka Boss Live Result , Satta Boss , Satta Matka Mumbai , Satta Matka Tips , Satta Matka , Fastest Matka Result , Kalyan Matka , Matka Guessing 143 , Satta Matka Free Game , Fix Matka Game Fix Matka Game , Fix Fix Satta Number , Tara Matka , Sure Matka , Tara Matka Result , Kalyan Matka Office , Kalyan Matka Jodi Chart Panna Chart , Lucky Number Of Kalyan Close Matka , Indian Matka Guessing Forum , Satta Matka , Fastest Matka Result , Kalyan Matka , Matka Guessing 143 , Kalyan Patti Fix Fix Patti , Satta Batta Trick , Indian Satta , Madhur Satta , Matka Guessing , Wapka Site , Satta Matka,
Dpboss ,  Kalyan Matka Report ,  Satta ,  Matka ,  Fix Satta ,  Fix Matka , Kalyan Satta , Satta king , Indian Satta , Matka Satta , Satta 143 , Fix fix fix Satta nambar , 
Kalyan Open , Matka 420 , Satta live , Matka Boss , Golden Matka , Kalyan Result , Satta result , New Matka , Matka result , Matka Satta , Dpboss Matka , Tara Matka , Matka guessing , Satta guessing , Simple Matka Guessing , Kalyan night , Satta Matta Matka 143 , Sattaking143 Guessing , Satta batta , Satta chart , Satta history ,  

</div></div>

</div>

<div class="clear">
</div>
<div class="smm_bg"><h1 class="heading_title10">SATTA MATKA</h1>

<div class="padding10"><div class="ex1">
    <a href="<?= base_url();?>"><strong>Matkareport.com</strong></a> has emerged because the only website wherever you'll be able to have many fun beside earning an outsized chunk of cash . Here, you'll be able to have a spread of choices in conjunction with Matka Boss, SattaMatka Result, Matka Charts, SattaMatka,Indian Matka Free KalyanMatka Tips and metropolis Matka tips beside 100% fix matka range from Asian country SattaMatka. Moreover, it's enough to form you go crazy. the sole factor is that this web site can cause you to urge filled with unimaginable fun and excitement. And you're doing not got to be compelled to worry regarding loss since you'll be able to act with the choice of city Day then on.<br /><br />Here, you'll be able to simply recover all kinds of loss from city Day, city Night, <strong>Rajdhani Day, Rajdhani Night, KalyanMatka, Matka Indian</strong> by <strong>Matka</strong>. We've a bent to face measure here to form your life with filled with fun and happiness. you'll be able to have all quite <strong>Satta Market's</strong> live results on things. You're doing not got to be compelled to worry or run from here to there. You'll be able to check the results simply just by going with a click. These results square measure offered at the official website which we impart <strong>Fix SattaMatka Numbers</strong>.<br /><br />You can even have live updates. Have quickest <strong>SattaMatka</strong> Results simply on your mobile. You'll be able to even have updates for Madhur Matka, City Matka, RajdhaniMatka, Time Bazar, metropolis Mail simply while not effort any quite hassles. This acknowledged platform is here to form you've got the sole expertise. We've graven out an outstanding image at the forefront. You'll be able to have here the foremost fashionable further because the foremost trustworthy on-line <strong>SattaMatka</strong> web site developing with the quickest and nice SattaMatka results and SattaMatka range. You'll really have many fun and excitement in conjunction with your family, friends and colleague to possess all quite updates, you merely got to be compelled to remain in-tuned with our web site so as that you'd not miss any quite updates ever. We've a bent to conjointly introduce you the quickest <strong>Kalyan Matka</strong> or <strong>SattaMatka Tips</strong>. you'll get pleasure from them tons too. Locution wouldn't wrong that this website is taken under consideration theworld's most far-famed <strong>Matka Web Site</strong>.<br /><br />Legion of individuals also are enjoying metropolis Matka in Satta Bazar. We've a bent to feel nice introducing your <strong>Matka</strong> equipped to bring the fast and wonderful results to you. Do I wish to ascertain out the results then escort the choice of finding out the official website? you'll be able to check here the quicker results than the other Matka site with free SattaMatka lucky numbers. All you'd wish to is simply act to marker Our Link <strong>https://Matka</strong> to stay having our daily updates visiting US simply.</div></div></div><div class="sm_bg"><div class="heading_title11">WHAT IS SATTAMATKA</div><div class="padding10"><div class="ex1">There would be several of you wanting forward to understand concerning <strong>SattaMatka</strong>. Here, we tend to face measure going to share it during a elaborated manner to place in easy words, SattaMatka or Indian Matka is taken under consideration a kind of gambling. It's obtaining quite fashionable and other people area unit enjoying it on an oversized scale. This extremely fashionable game was started in <strong>Bombay in India</strong>. inside a fast span of a while, it's grabbed many success at the forefront. Inside stipulated time, the recognition of this game has reached to next level.<br /><br />The best issue is that this game is being vie during a sort of totally different elements of the country or abroad. And it's enough to inform however this game is obtaining fashionable on an oversized scale. Talking concerning the inspiration of this game, it absolutely was started by a personal specifically <strong>Kalyanji Bhagat</strong>. He was the primary person brought this game into light-weight. And this game mentioned as <strong>Indian Matka Game</strong> has received Brobdingnagian quality on this forefront. When the 19 Sixties, this game was introduced within the 19 Seventies by the name of <strong>KalyanMatka</strong>.<br /><br />The best issue is that <strong>Sattamatka</strong> or <strong>Indian Matka</strong> has grabbed an enormous quality at the forefront. Additionally, within the year 1990, it becomes one among the foremost effective and really fashionable sports. Folks love this game since they'll strive their luck. once a year, many people are making an attempt this game and luxuriate in this game. The foremost effective issue is that we tend to all or any or any apprehend that Matka could even be a extremely fashionable game of gambling. And it's wide fashionable game revolving round the selection of luck and you have got got spoken.</div></div></div><div class="makes_bg"><div class="heading_title12">WHAT MAKES IT POPULAR</div><div class="padding10"><div class="ex1">There are numerous games available to undertake. But <strong>Kalyan Matka</strong> has emerged because the simplest one. India's hottest game of chance is here to make you go crazy. Uou'll truly love it thanks to its key factors. If you'd wish to form money fast and speed then you would like to settle on it. You'll really have plenty of fun in conjunction with making money fast.<br /><br /><strong>Kalyan Matka</strong> is taken into account India's hottest game of chance. It's quite popular and famous for creating money through speculation in <strong>Indian Matka</strong>. <strong>Kalyan Matka</strong> was started in <strong>Mumbai</strong> and it's received plenty of recognition within a quick span of some time. This game was started by <strong>Mr. Kalyanji Bhagat</strong> and his wife <strong>Jaya Bhagatji</strong>. That's why this game is known as Kalyan Matka. And again within the year of 1965, this game was started giving a replacement name called <strong>Mumbai Matka</strong>. Indian Kalyan Satta Matka comes up with accurate open and shut time. Moreover, its information is additionally keep updated whenever at our website Matka.<br /><br />Talking about the results of <strong>Kalyan Matta</strong>, it comes twice during each day. This result's regarded with two names, it's considered as Open and shut. The time of the <strong>Kalyan Open</strong> starts from 4.15 pm and thus the time of welfare closure involves 6.15. It means you will have a superb time along side your family and friends.</div></div></div><div class="smm_bg"><div class="heading_title10">THE PROMINENT TYPES</div><div class="padding10"><div class="ex1"><p><strong>Here, the prominent types are being explained during an in depth manner. Allow us to see it out everything and grab more information.</strong></p><ul><li><strong>Matka:</strong> you'll wonder why it's called Matka. This word also derives from Hindi and it means earthen pot within the past, Such pots were used to draw numbers and make it about easy to count. You will find this word slightly weird. But now people got to get used to this name and enjoying this name.</li><li><strong>Single:</strong> you'll accompany any digit between 0 and 9 which involves betting. Choose your lucky number and play your game to possess plenty of fun and excitement.</li><li><strong>Jodi/ Pair:</strong> Jodi could also be a Hindi word and it means pair. You'll choose any pair of digits between 00 and 99 involving in Matka. You will have a Jodi pair to enjoy tons.</li><li><strong>Patti/ Panna:</strong> there's another type on the list called Patti and Panna. It is a few three digit result which comes as betting result and thus the smartest thing is that every one three-digit numbers are Patti/Panna but you'll accompany only limited three digit numbers are used and this enhances the extent of the game.</li><li><strong>Open Result / Close Result:</strong> And this one is crammed with excitement. You'll not know but the results of Matka betting is split into two parts.</li><li>Moreover, the first part is taken into account the open result and thus the second part is known as an thorough result. This is often often why it's called two parts of close results. You will have a superb experience while playing it.</li></ul></div></div></div><div class="sm_bg"><div class="heading_title11">WHY PEOPLE ARE LOVING ONLINE SATTAMATKA GAME</div><div class="padding10"><div class="ex1">You might be wondering what makes this game high in demand. The only thing is that you simply simply will have anotherlevel of experience that you haven't had. Tou would be able to have plenty of great experience. You will find it slightly bizarre but people are loving this game which whole world is busy in playing this game with plenty of interest. You will find here a legion of players much into this game. The only thing is that the whole world is playing <strong>Satta Matka Today</strong> with enjoying tons and thus the prominent reason is that online websites have made possible to enjoy these games so easily. You're doing not need to take a chance from your work or put your work on hold. You'll easily enjoy the game whenever you'd like.<br /><br />You can make an honest chunk of money easily and thus the prominent reason is that people are enjoying this game tons. With a quick span of some time, the popularity of this game has increased to a superb level. The important main reason why online websites for <strong>Matka Game</strong> is getting popular on an outsized scale is that you simply simply will have a superb experience in conjunction with making an honest chunk of money.<br /><br />It is up to you ways much you'd wish to bet. It is a trustworthy site and you will have great results. You're doing not need to get confused since everything is transparency here. We believe making you cheerful and satisfied all the time. The popularity of this game is increasing day by day. The ration of players in increasing on a superb level. You will have here the outstanding facilities which is why people always choose this over other options. You'll never feel bored once you select us for this game.<br /><br />This website has been designed during an honest way so as that you're going to have an incredible experience. It isn't tough to play even you're new this game. You'll easily play this game and make an honest chunk of money. The interface of the online site is kind of easy to understand. The popularity of this game is increasing on an outsized scale. These websites made the game quite easy and comfy. You'll not face any hassles while playing. you'll go ahead to choose the type you're comfortable with. You'll truly have a superb experience while enjoying it. The only thing is that you simply simply will have an incredible experience. You're doing not need to go anywhere else to possess the only experience. All you'd wish to attempt to to is choose the type you'd wish to enjoy. Moreover, you will have an incredible experience. You're doing not need to go anywhere else if want to enjoy this game. Choosing the right website to play <strong>Matka game</strong> is not easy. But we are here to make everything so easier for you. Choosing us means you'll not have any hassle. However, we are here to make the entire procedure easier and simpler. Choosing us means you will have a superb experience. You're doing not worry once you've chosen us. We put the only efforts to bring the only results out.<br /><br />Before playing the <strong>Matka</strong> game online, you'd wish to form sure that you simply simply have skilled the terms & conditions. You need to read them carefully so as that you're going to not have any issues afterward. Internet is brimmed with numerous options to travel ahead but we've emerged because the simplest one. There are many forums available online which are genuine and amazing. But we are ruling over many hearts. We aren't leaving any stone unturned to make you cheerful and satisfied. To grab more information, you simply need to visit our site and accumulate the knowledge.<br /><br />The reputed Some <strong>Satta Matka Websites</strong> are here to provide this gambling especially country so as that you're going to have plenty of fun and accuracy. You're doing not need to get into tricky things to seek out out it. So, what are you waiting for? it is time to travel ahead and luxuriate within the sport easily.</div></div></div>


  <div class="header_txt"> <p class="disclam">-:DISCLAIMER:-</p> <p class="pap">Viewing This Web Site Is On Your Own Risk. All The Knowledge Shown On Web Site Relies On Discipline And Pseudoscience For Data Functions. All Information Collected For Web. We Tend To Don't Seem To Be Related To Any Extralegal Matka Business Or Gamblers. We Tend To Warn You That Matka Gambling In Your Country Is Additionally Illegal Or Extralegal. We Tend To Don't Seem To Be Liable For Any Problems Or Scam. We Tend To Respect All Country Rules/Laws. If You Not Believe Our Web Site Disclaimer. Please Quit Our Web Site Directly. Copying/Promoting/Publishing Any Of Our Content In Any Quite Media Or Different Supply Is Unlawful And Against Law.<br><br></p>

<!--   <a href="<?= base_url();?>assets/matka/tel:<?=$mobile;?>" title="Satta Matka">☎ <?=$mobile;?></a>-->
   
   <br /></div>
   
   <div class="bg-light text-center foot">
<div class=" padding10">
<a href="#btned" id="cvbn" class="btn btn-purpal">Go To Top</a>
</div>
<ul class="list-inline m-0 p-0" style="line-height: 1.5;">
<li> <strong><h3 class="text-danger">Matka</h3></strong></li>
<li>ALL RIGHTS RESERVED (2020-2021)</li>
<li>CONTACT Matka</li>
<li class="text-danger"><h3><?=$mobile;?></h3></li>
<li><a class="text-danger bold" href="https://sattamatkalive.site/"><strong>SATTA MATKA</strong></a></li>
</ul>
</div>
   
  <!--  <div class="useful_bg"><div class="heading_title13">FREE GAME FIND</div><div class="padding10"><a href="<?= base_url();?>assets/matka/https://Matka.sattamatka.wiki/" title="Matka">Matka</a> # <a href="<?= base_url();?>assets/matka/https://Matka.sattamatka.wiki/" title="Satta">Satta</a> # <a href="<?= base_url();?>assets/matka/index.html" target="_blank" class="strong font_color_white"><span class="blinking">Satta Matka Single Jodi</span></a> # <a href="<?= base_url();?>assets/matka/mini-mumbai-date-fix-panel-chart/index.html">Panel Chart - Mini Mumbai</a> # <a href="<?= base_url();?>assets/matka/maya-bazar-satta-king-panel-chart/index.html">Panel Chart - Maya Bazar</a> # <a href="<?= base_url();?>assets/matka/atm-draw-fix-jodi-panel-chart/index.html">Panel Chart - ATM Draw</a> # <a href="<?= base_url();?>assets/matka/atm-night-boss-matka-panel-chart/index.html">Panel Chart - ATM Night</a> # <a href="<?= base_url();?>assets/matka/mini-mumbai-matka-jodi-chart/index.html">Jodi Chart - Mini Mumbai</a> # <a href="<?= base_url();?>assets/matka/maya-bazar-kalyan-satta-jodi-chart/index.html">Jodi Chart - Maya Bazar</a> # <a href="<?= base_url();?>assets/matka/atm-draw-kalyan-open-jodi-chart/index.html">Jodi Chart - ATM Draw</a> # <a href="<?= base_url();?>assets/matka/atm-night-bazar-jodi-chart/index.html">Jodi Chart - ATM Night</a> # <a href="<?= base_url();?>assets/matka/worly-bazar-satta143-jodi-chart/index.html">Jodi Chart - Worly Bazar</a> # <a href="<?= base_url();?>assets/matka/worly-bazar-night-satta-satta-jodi-chart/index.html">Jodi Chart - Worly Bazar Night</a> # <a href="<?= base_url();?>assets/matka/worly-bazar-weekly-panel-chart/index.html">Panel Chart - Worly Bazar</a> # <a href="<?= base_url();?>assets/matka/worly-night-patti-panel-chart/index.html">Panel Chart - Worly Bazar Night</a> # <a href="<?= base_url();?>assets/matka/new-kalyan-matka-result-jodi-chart/index.html">Jodi Chart - New Kalyan</a> # <a href="<?= base_url();?>assets/matka/new-kalyan-matka-result-panel-chart/index.html">Panel Chart - New Kalyan</a> # <a href="<?= base_url();?>assets/matka/ratan-atka-matka-satka-jodi-chart/index.html">Jodi Chart - Ratan</a> # <a href="<?= base_url();?>assets/matka/ratan-matka-panel-chart/index.html">Panel Chart - Ratan</a> # <a href="<?= base_url();?>assets/matka/raj-mumbai-indian-satta-panel-chart/index.html">Panel Chart - Raj Mumbai</a> #<a href="<?= base_url();?>assets/matka/new-bombay-bazar-matka-panel-chart/index.html">Panel Chart - New Bombay Bazar</a> #<a href="<?= base_url();?>assets/matka/raj-mumbai-Matka-jodi-chart/index.html">Jodi Chart - Raj Mumbai</a> #<a href="<?= base_url();?>assets/matka/new-bombay-bazar-satta-jodi-chart/index.html">Jodi Chart - New Bombay Bazar</a> # <a href="<?= base_url();?>assets/matka/kalyan-night-matka-boss-jodi-chart/index.html">Jodi Chart - Kalyan Night</a> # <a href="<?= base_url();?>assets/matka/kalyan-night-matka-boss-panel-chart/index.html">Panel Chart - Kalyan Night</a> # <a href="<?= base_url();?>assets/matka/main-mumbai-b-jodi-chart/index.html">Jodi Chart - Main Mumbai B</a> # <a href="<?= base_url();?>assets/matka/mumbai-day-b-jodi-chart/index.html">Jodi Chart - Mumbai Day B</a> # <a href="<?= base_url();?>assets/matka/main-mumbai-b-panel-chart/index.html">Panel Chart - Main Mumbai B</a> # <a href="<?= base_url();?>assets/matka/mumbai-day-b-panel-chart/index.html">Panel Chart - Mumbai Day B</a> # <a href="<?= base_url();?>assets/matka/andheri-night-satta-matka-jodi-chart/index.html">Jodi Chart - Andheri Night</a> # <a href="<?= base_url();?>assets/matka/andheri-night-satta-matka-panel-chart/index.html">Panel Chart - Andheri Night</a> # <a href="<?= base_url();?>assets/matka/plan-tic-day-matka-game-jodi-chart/index.html">Jodi Chart - Plant Tic Day</a> # <a href="<?= base_url();?>assets/matka/plan-tic-night-all-matka-jodi-chart/index.html">Jodi Chart - Plant Tic Night</a> # <a href="<?= base_url();?>assets/matka/plan-tic-day-open-panel-chart/index.html">Panel Chart - Plant Tic Day</a> # <a href="<?= base_url();?>assets/matka/plan-tic-night-close-panel-chart/index.html">Panel Chart - Plant Tic Night</a> # <a href="<?= base_url();?>assets/matka/kalyan-starline-panel-panel-chart/index.html">Panel Chart - Kalyan Starline</a> # <a href="<?= base_url();?>assets/matka/atm-matka-jodi-chart/index.html">Jodi Chart - ATM Matka</a> # <a href="<?= base_url();?>assets/matka/atm-matka-panel-chart/index.html">Panel Chart - ATM Matka</a> # <a href="<?= base_url();?>assets/matka/main-kalyan-fix-matka-jodi-chart/index.html">Jodi Chart - Main Kalyan</a> # <a href="<?= base_url();?>assets/matka/main-kalyan-fix-matka-panel-chart/index.html">Panel Chart - Main Kalyan</a> # <a href="<?= base_url();?>assets/matka/time-night-bazar-jodi-chart/index.html">Jodi Chart - Time Night</a> # <a href="<?= base_url();?>assets/matka/time-night-bazar-panel-chart/index.html">Panel Chart - Time Night</a> # <a href="<?= base_url();?>assets/matka/main-ratan-satta-boss-jodi-chart/index.html">Jodi Chart - Main Ratan</a> # <a href="<?= base_url();?>assets/matka/main-ratan-satta-boss-panel-chart/index.html">Panel Chart - Main Ratan</a> # 
<a href="<?= base_url();?>assets/matka/basanti-satta-jodi-chart/index.html">Jodi Chart - Basanti</a> # 
<a href="<?= base_url();?>assets/matka/basanti-night-satta-jodi-chart/index.html">Jodi Chart - Basanti Night</a> # <a href="<?= base_url();?>assets/matka/basanti-satta-panel-chart/index.html">Panel Chart - Basanti</a> # <a href="<?= base_url();?>assets/matka/basanti-night-satta-panel-chart/index.html">Panel Chart - Basanti Night</a> # <a href="<?= base_url();?>assets/matka/black-kinght-satta-market-jodi-chart/index.html">Jodi Chart - Black Knight [BK]</a> # <a href="<?= base_url();?>assets/matka/black-kinght-satta-market-panel-chart/index.html">Panel Chart - Black Knight [BK]</a> # 
<a href="<?= base_url();?>assets/matka/mumbai-shree-satta-jodi-chart/index.html">Jodi Chart - Mumbai Shree</a> # 
<a href="<?= base_url();?>assets/matka/mumbai-shree-satta-panel-chart/index.html">Panel Chart - Mumbai Shree</a> # 
<a href="<?= base_url();?>assets/matka/delhi-day-satta-king-jodi-chart/index.html">Jodi Chart - Delhi Day</a> #
<a href="<?= base_url();?>assets/matka/delhi-day-satta-king-panel-chart/index.html">Panel Chart - Delhi Day</a> # 
<a href="<?= base_url();?>assets/matka/delhi-night-satta-jodi-chart/index.html">Jodi Chart - Delhi Night</a> # 
<a href="<?= base_url();?>assets/matka/delhi-night-satta-panel-chart/index.html">Panel Chart - Delhi Night</a> # 
<a href="<?= base_url();?>assets/matka/rajdhani-evening-result-jodi-chart/index.html">Jodi Chart - Rajdhani Evening Day</a> # 
<a href="<?= base_url();?>assets/matka/rajdhani-evening-result-panel-chart/index.html">Panel Chart - Rajdhani Evening Day</a> # 
<a href="<?= base_url();?>assets/matka/maruti-morning-matka-jodi-chart/index.html">Jodi Chart - Maruti Morning</a> #
<a href="<?= base_url();?>assets/matka/maharashtra-laxmi-day-lottery-jodi-chart/index.html">Jodi Chart - Maharashtra Laxmi Day</a> # 
<a href="<?= base_url();?>assets/matka/maruti-morning-matka-panel-chart/index.html">Panel Chart - Maruti Morning</a> # 
<a href="<?= base_url();?>assets/matka/maharashtra-laxmi-day-lottery-panel-chart/index.html">Panel Chart - Maharashtra Laxmi Day</a> # 
<a href="<?= base_url();?>assets/matka/main-sridevi-satta-matka-jodi-chart/index.html">Jodi Chart - Main Sridevi</a> #
<a href="<?= base_url();?>assets/matka/main-sridevi-night-satta-matka-jodi-chart/index.html">Jodi Chart - Main Sridevi Night</a> # 
<a href="<?= base_url();?>assets/matka/main-sridevi-satta-matka-panel-chart/index.html">Panel Chart - Main Sridevi</a> #
<a href="<?= base_url();?>assets/matka/main-sridevi-night-satta-matka-panel-chart/index.html">Panel Chart - Main Sridevi Night</a> # 
<a href="<?= base_url();?>assets/matka/kaala-bazaar-matka-jodi-chart/index.html">Jodi Chart - Kaala Bazaar</a> # 
<a href="<?= base_url();?>assets/matka/kaala-bazaar-matka-panel-chart/index.html">Panel Chart - Kaala Bazaar</a> # 
<a href="<?= base_url();?>assets/matka/new-time-bazar-result-jodi-chart/index.html">Jodi Chart - New Time Bazar</a> # 
<a href="<?= base_url();?>assets/matka/new-time-bazar-result-panel-chart/index.html">Panel Chart - New Time Bazar</a> # 
<a href="<?= base_url();?>assets/matka/rajdhani-morning-matka-jodi-chart/index.html">Jodi Chart - Rajdhani Morning</a> # 
<a href="<?= base_url();?>assets/matka/rajdhani-morning-matka-panel-chart/index.html">Panel Chart - Rajdhani Morning</a> # 
<a href="<?= base_url();?>assets/matka/super-mail-Matka-net-jodi-chart/index.html">Jodi Chart - Super Mail</a> # 
<a href="<?= base_url();?>assets/matka/super-mail-open-ank-panel-chart/index.html">Panel Chart - Super Mail</a> # 
<a href="<?= base_url();?>assets/matka/singapur-matka-bazar-jodi-chart/index.html">Jodi Chart - Singapur</a> # 
<a href="<?= base_url();?>assets/matka/singapur-matka-bazar-panel-chart/index.html">Panel Chart - Singapur</a> # 
<a href="<?= base_url();?>assets/matka/devi-night-matka-jodi-chart/index.html">Jodi Chart - Devi Night</a> # 
<a href="<?= base_url();?>assets/matka/devi-night-matka-panel-chart/index.html">Panel Chart - Devi Night</a> # 
<a href="<?= base_url();?>assets/matka/morning-mumbai-satta-jodi-chart/index.html">Jodi Chart - Morning Mumbai</a> # 
<a href="<?= base_url();?>assets/matka/morning-mumbai-satta-panel-chart/index.html">Panel Chart - Morning Mumbai</a> # 
<a href="<?= base_url();?>assets/matka/main-maharashtra-day-jodi-chart-satta/index.html">Jodi Chart - Main Maharashtra Day</a> # 
<a href="<?= base_url();?>assets/matka/main-maharashtra-night-jodi-chart-matka/index.html">Jodi Chart - Main Maharashtra Night</a> # 
<a href="<?= base_url();?>assets/matka/main-maharashtra-day-panel-chart-satta/index.html">Panel Chart - Main Maharashtra Day</a> # 
<a href="<?= base_url();?>assets/matka/main-maharashtra-night-panel-chart-matka/index.html">Panel Chart - Main Maharashtra Night</a> # 
<a href="<?= base_url();?>assets/matka/lucky-7-satta-matka-jodi-chart/index.html">Jodi Chart - Lucky 7</a> # 
<a href="<?= base_url();?>assets/matka/lucky-7-satta-matka-panel-chart/index.html">Panel Chart - Lucky 7</a> # 
<a href="<?= base_url();?>assets/matka/sundar-day-satta-jodi-chart/index.html">Jodi Chart - Sundar Day</a> # 
<a href="<?= base_url();?>assets/matka/sundar-day-satta-panel-chart/index.html">Panel Chart - Sundar Day</a> # 
<a href="<?= base_url();?>assets/matka/golden-satta-jodi-chart/index.html">Jodi Chart - Golden</a> # 
<a href="<?= base_url();?>assets/matka/golden-satta-panel-chart/index.html">Panel Chart - Golden</a> # 
<a href="<?= base_url();?>assets/matka/rajdhani-day-satta-matka-result-jodi-chart/index.html">Jodi Chart - Rajdhani Day</a> #
<a href="<?= base_url();?>assets/matka/rajdhani-day-matka-panel-chart/index.html">Panel Chart - Rajdhani Day</a> #
<a href="<?= base_url();?>assets/matka/main-milan-day-matka-jodi-chart/index.html">Jodi Chart - Main Milan Day</a> #
<a href="<?= base_url();?>assets/matka/main-milan-day-matka-panel-chart/index.html">Panel Chart - Main Milan Day</a> #
<a href="<?= base_url();?>assets/matka/anand-time-day-matka-jodi-chart/index.html">Jodi Chart - Anand Time Day</a> #
<a href="<?= base_url();?>assets/matka/anand-time-day-matka-panel-chart/index.html">Panel Chart - Anand Time Day</a> #
<a href="<?= base_url();?>assets/matka/anand-time-night-matka-jodi-chart/index.html">Jodi Chart - Anand Time Night</a> #
<a href="<?= base_url();?>assets/matka/anand-time-night-matka-panel-chart/index.html">Panel Chart - Anand Time Night</a>-->
</div></div></div>


<!--
<div class="keyword_top"><a href="<?= base_url();?>assets/matka/index.html" class="link_hover">Matka</a><br />ALL RIGHTS RESERVED (2017-2021)<br>Admin Sir<br><a href="<?= base_url();?>assets/matka/tel:<?=$mobile;?>" class="link_hover"><?=$mobile;?></a></div><div class="padding10"><a href="<?= base_url();?>assets/matka/javascript:history.back()" class="btn btn-success">Back</a><a href="<?= base_url();?>assets/matka/index.html" class="btn btn-warning">Home</a><a href="<?= base_url();?>assets/matka/dmca/index.html" class="btn btn-success">DMCA</a></div><input class="refresh_button2" type="button" onclick="window.location.reload()" value="Refresh"><a href="<?= base_url();?>assets/matka/tel:<?=$mobile;?>"><input value="Call Us" type="button" class="callus_button"></a><div class="headings"><h2>SattaMatka Market</h2><h3>Matka Result</h3><h4>Kalyan Main Matka</h4><h5>Satta Market</h5><h6>Indian Matka</h6></div><script>function openNav(){document.getElementById("myNav").style.width = "100%";}function closeNav(){document.getElementById("myNav").style.width = "0%";}</script>
-->

<div class="text-center" style="position: fixed;
 bottom: 60px;
    right: 10px;">
<a href="<?= base_url();?>"  class="btnrefresh">Refresh</a>
</div>

<div class="text-center" style="position: fixed;
 bottom: 20px; right: 10px;">
<a href="tel:<?=$mobile;?>" class="btncall">Call Us</a>
</div>


</body>
<!-- Mirrored from Matka/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Oct 2021 11:35:33 GMT -->
</html> 

<style>
    .btnrefresh {
    font-size: 16px!important;
    border: none!important;
    border-radius: 5px;
    background-image: #add8e6;
    background-image: linear-gradient(45deg,#0196ae,#241946e6);
    color: #fff;
    padding: 8px 16px;
}

    .btncall {
    font-style: normal;
    text-decoration: none;
    font-size: 16px!important;
    border-radius: 5px;
    background-image: #add8e6;
    background-image: linear-gradient(45deg,#ffc107,#bd2130);
    color: #fff;
    padding: 8px 17px;
}

</style>

