<!DOCTYPE html><html lang="en">
    
       
     <?php 
 $res= $this->db->limit(1)->get("setting")->row();
 $mobile=$res->contact_no;
 ?>
    
    
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <?php if(isset($status['typechart']) == "panel") { ?>
    <title> <?=$status['title'];?></title>
    
     <meta name="keyword" content="<?=$status['meta_desc'];?>"/>
    
    <meta name="description" content="<?=$status['description'];?>"/>
    <?php } ?>
    <link rel="icon" href="<?= base_url();?>assets/matka/fevii.png" type="image/gif" sizes="16x16">
    
    <link rel="alternate" hreflang="x-default" href="<?= base_url();?>" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><link rel="shortcut icon" href="<?= base_url();?>assets/matka/images/favicon.ico" type="image/x-icon" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><link rel="icon" href="<?= base_url();?>assets/matka/images/matka.jpg"/ ><meta content="yes" name="apple-mobile-web-app-capable" /><meta content="yes" name="apple-touch-fullscreen" /><meta name="author" content="MatkaSattamatkaWiki" /><meta name="copyright" content="matka satta matka" /><meta property="og:url" content="index.html" /><meta property="og:image" content="images/logo2.jpg" /><meta property="og:type" content="website" /><meta property="og:title" content="Matka Satta Matka" /><meta property="og:description" content="Matka Sattamatka" /><meta name="twitter:card" content="summary" /><meta name="twitter:site" content="@MatkaSattamatkaWiki?lang=en" /><meta name="twitter:title" content="MatkaSattamatkaWiki" /><meta name="twitter:description" content="MatkaSattamatkaWiki" /><meta name="twitter:image" content="images/logo.jpg"><meta name="twitter:image:alt" content="MatkaSattamatkaWiki"><meta name="theme-color" content="#F00000">
   <!-- <style>@media print{... CSS for print goes here} </style>-->
    <link rel="stylesheet"  href="<?= base_url();?>assets/css/panel.css" />

<!--<script async src="<?= base_url();?>assets/matka/https://www.googletagmanager.com/gtag/js?id=UA-113909704-1" ></script><script>  window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'UA-113909704-1');</script><script type="application/ld+json">{  "@context": "https://schema.org", "@type": "Blog", "url": "https://matka.Sattamatka.wiki/blog" }</script><script type="application/ld+json">{ "@context": "https://schema.org", "@type": "Organization", "name": "MATKA SATTA MATKA WIKI", "url": "https://matka.Sattamatka.wiki/", "address": "Mumbai",  "sameAs": [  "https://www.facebook.com/1Sattamatka.WIKI", "https://twitter.com/Sattamatkawiki?lang=en"  ]  }</script><meta name="google-site-verification" content="GWUjxOsZbyawYa-o7_6ryb1SwSU67qSqS_UJ77KIc_8"/><script type="application/ld+json">{"@context": "https://schema.org","@type": "Blog","url": "https://matka.Sattamatka.wiki/blog"}</script><script type="application/ld+json">{"@context": "https://schema.org/","@type": "Website","name": "Matka Satta Matka","url": "https://matka.Sattamatka.wiki"}</script>-->
<!-- right click disable  start -->

    <style>
       
    </style>

<?php
    $run=$check['run_in_week'];
    ?>
 
    <div class="header"><a href="<?= base_url();?>" title="Matka Sattamatka Matka">
        
<img loading=lazy border="0" src="<?php echo base_url($res->logo); ?>" alt="Satta Matka Sattamatka Matka Satta" title="Matka Sattamatka Matka" class="img-responsive lod" />

<div class="panel_chart_bg">
<h1 class="heading_title5"><?=$check['game_name'];?> PANEL CHART</h1>
</div>
<div class="panel_chart_bg padding10">
<h5 class="" style="padding: 11px;"> <?=$status['key_words'];?> </h5> <br>
</div>


<div class="panel_chart_bg">
    <!--<a href="<?php echo base_url();?>">Back</a>-->

<div align="center">
<center>
<table class="mobile" border="1">
<tbody><tr class="td_center strong">
<td>Date</td>
<td colspan="3">Mon</td>
<td colspan="3">Tue</td>
<td colspan="3">Wed</td>
<td colspan="3">Thu</td>
<td colspan="3">Fri</td>
<?php if($run>5){ ?>
<td colspan="3">Sat</td>
<?php if($run>6){ ?>		
<td colspan="3">Sun</td>
<?php }?>  
<?php }?>    
 </tr>  
</tr>


<tr>
    <?php 
    foreach($list as $data){ 
      $dayname = date('D', strtotime($data['date'])); 
      //$no_of_day=$data['date'];
      
  
       
 ?>
  <?php if($dayname=='Mon'){
           $date = date('d/m/Y', strtotime($data['date'])); 
           $date1 = date('d/m/Y', strtotime("+".($run-1)."day",strtotime(($data['date'])))); 
           
  ?>
  <td class="chart_date">
<?php echo $date;?><br>
To<br>
<?php echo $date1;?></td>
<?php }?>
     
   
    <?php if($dayname=='Mon'){  
          $ss=explode('-',$data['game_number']);
        $k=  strlen($ss[0]);
         echo "<td>";
          for($i=0;$i<$k;$i++){
             echo $ss[0][$i].'<br>';
          }
          echo "</td>"; 
        
        echo " <td><span style=font-size:13px;color:$data[color]> <b> $ss[1] </b></span></td>";
        
         $k=  strlen($ss[2]);
         echo "<td>";
          for($i=0;$i<$k;$i++){
             echo $ss[2][$i].'<br>';
          }
          echo "</td>"; 
      
      } ?>
      <?php if($dayname=='Tue'){  
          $ss=explode('-',$data['game_number']);
        $k=  strlen($ss[0]);
         echo "<td>";
          for($i=0;$i<$k;$i++){
             echo $ss[0][$i].'<br>';
          }
          echo "</td>"; 
        
        echo " <td><span style=font-size:13px;color:$data[color]> <b> $ss[1] </b></span></td>";
        
         $k=  strlen($ss[2]);
         echo "<td>";
          for($i=0;$i<$k;$i++){
             echo $ss[2][$i].'<br>';
          }
          echo "</td>"; 
      
      } ?>
      <?php if($dayname=='Wed'){  
         $ss=explode('-',$data['game_number']);
        $k=  strlen($ss[0]);
         echo "<td>";
          for($i=0;$i<$k;$i++){
             echo $ss[0][$i].'<br>';
          }
          echo "</td>"; 
        
        echo " <td><span style=font-size:13px;color:$data[color]> <b> $ss[1]</b></span></td>";
        
         $k=  strlen($ss[2]);
         echo "<td>";
          for($i=0;$i<$k;$i++){
             echo $ss[2][$i].'<br>';
          }
          echo "</td>"; 
      
      } ?>
      
       <?php  if($dayname=='Thu'){  
          $ss=explode('-',$data['game_number']);
        $k=  strlen($ss[0]);
         echo "<td>";
          for($i=0;$i<$k;$i++){
             echo $ss[0][$i].'<br>';
          }
          echo "</td>"; 
        
        echo " <td><span style=font-size:13px;color:$data[color]> <b> $ss[1]</b></span></td>";
        
         $k=  strlen($ss[2]);
         echo "<td>";
          for($i=0;$i<$k;$i++){
             echo $ss[2][$i].'<br>';
          }
          echo "</td>"; 
      
      } ?>
       <?php if($dayname=='Fri'){  
           $ss=explode('-',$data['game_number']);
        $k=  strlen($ss[0]);
         echo "<td>";
          for($i=0;$i<$k;$i++){
             echo $ss[0][$i].'<br>';
          }
          echo "</td>"; 
        
        echo " <td><span style=font-size:13px;color:$data[color]> <b>$ss[1]</b></span></td>";
        
         $k=  strlen($ss[2]);
         echo "<td>";
          for($i=0;$i<$k;$i++){
             echo $ss[2][$i].'<br>';
          }
          echo "</td>"; 
      
        
      } ?> 
       
       <?php if($run>=6){ if($dayname=='Sat'){   
         $ss=explode('-',$data['game_number']);
        $k=  strlen($ss[0]);
         echo "<td>";
          for($i=0;$i<$k;$i++){
             echo $ss[0][$i].'<br>';
          }
          echo "</td>"; 
        
        echo " <td><span style=font-size:13px;color:$data[color]> <b> $ss[1]</b></span></td>";
        
         $k=  strlen($ss[2]);
         echo "<td>";
          for($i=0;$i<$k;$i++){
             echo $ss[2][$i].'<br>';
          }
          echo "</td>"; 
      
      }} ?> 
       <?php if($run>=7){if($dayname=='Sun'){  
          $ss=explode('-',$data['game_number']);
        $k=  strlen($ss[0]);
         echo "<td>";
          for($i=0;$i<$k;$i++){
             echo $ss[0][$i].'<br>';
          }
          echo "</td>"; 
        
        echo " <td><span style=font-size:13px;color:$data[color]><b> $ss[1]</b></span></td>";
        
         $k=  strlen($ss[2]);
         echo "<td>";
          for($i=0;$i<$k;$i++){
             echo $ss[2][$i].'<br>';
          }
          echo "</td>"; 
      
      } }?> 
	

 <?php if($run==5){if($dayname=='Fri'){   ?>
     </tr><tr>
 <?php  } }  ?>
 <?php if($run==6){if($dayname=='Sat'){   ?>
     </tr><tr>
 <?php  } }  ?>
  <?php if($run==7){if($dayname=='Sun'){   ?>
     </tr><tr>
 <?php  } }  ?>

<?php } ?>



</tbody></table></center></div></div>


<div class="keyword_top"><a href="#" class="link_hover">MATKA</a><br>ALL RIGHTS RESERVED (2021-2026)<br>Admin<br><a href="tel:<?=$mobile;?>" class="link_hover"><?=$mobile;?></a></div>

<div class="padding10"><a href="javascript:history.back()" class="btn btn-success">Back</a><a href="<?= base_url(); ?>" class="btn btn-warning">Home</a></div>

<div class="text-center msd" >
<input class="btnrefresh" type="button" id="regbut" onclick="window.location.reload()" value="Refresh"><div class="clear">    
</div>

<div class="text-center msn" >
<a href="tel:<?=$mobile;?>" class="btncall">Call Us</a>
</div>

<style>
    

</style>

