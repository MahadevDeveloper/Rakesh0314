<!DOCTYPE html><html lang="en">
    
       
 <?php 
 $res= $this->db->limit(1)->get("setting")->row();
 $mobile=$res->contact_no;
 ?>
    
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />



<head>
    <?php if(isset($status['typechart']) == "jodi") { ?>
    <title><?=$status['title'];?></title>
    
     <meta name="keyword" content="<?=$status['meta_desc'];?>"/>
     
    <meta name="description" content="<?=$status['description'];?>"/>
     <?php } ?>
    <link rel="icon" href="<?= base_url();?>assets/matka/fevii.png" type="image/gif" sizes="16x16">
    
   
    
   <link rel="alternate" hreflang="x-default" href="<?= base_url();?>assets/matka/index.html" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <link rel="shortcut icon" href="<?= base_url();?>assets/matka/images/favicon.ico" type="image/x-icon" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <link rel="icon" href="<?= base_url();?>assets/matka/images/matka.jpg"/ >
   <meta content="yes" name="apple-mobile-web-app-capable" /><meta content="yes" name="apple-touch-fullscreen" />
   <meta name="author" content="MatkaReport" />
   <meta name="copyright" content="matka satta matka" />
   <meta property="og:url" content="index.html" />
   <meta property="og:image" content="images/logo2.jpg" />
   <meta property="og:type" content="website" />
   <meta property="og:title" content="Matka Satta Matka" />
   <meta property="og:description" content="Matka Sattamatka" />
   <meta name="twitter:card" content="summary" />
   <meta name="twitter:site" content="@MatkaReport?lang=en" />
   <meta name="twitter:title" content="MatkaReport" />
   <meta name="twitter:description" content="MatkaReport" />
   <meta name="twitter:image" content="images/logo.jpg">
   <meta name="twitter:image:alt" content="MatkaReport">
   <meta name="theme-color" content="#F00000">
  <!-- <style>@media print{... CSS for print goes here} </style>-->
  <link rel="stylesheet"  href="<?= base_url();?>assets/css/jodi.css" />  
   
<!--<script async src="<?= base_url();?>assets/matka/https://www.googletagmanager.com/gtag/js?id=UA-113909704-1" ></script>
<script>  window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'UA-113909704-1');</script>-->

<!-- right click disable  start -->






<?php
function check_whek($da){
    $siz=array(7=>'Mon',6=>'Tue',5=>'Wed',4=>'Thu',3=>'Fri',2=>'Sat',1=>'Sun');
   // print_r($siz);
    return $d= array_search($da,$siz);
}
?>



<?php
    $run=$check['run_in_week'];
    ?>
    
 
    
    
        
    <div class="header"><a href="<?= base_url();?>" title="Matka Sattamatka Matka">

<img loading=lazy border="0" src="<?php echo base_url($res->logo); ?>" alt="Satta Matka Sattamatka Matka Satta" title="Matka Sattamatka Matka" style="" class="img-responsive lod" />


<div class="jodi_chart_bg">
<h1 class="heading_title5"><?=$check['game_name'];?> JODI CHART</h1>
</div>

<div class="panel_chart_bg padding10">
<p class="" style="padding: 11px;"> <?=$status['key_words'];?> </p> <br>
</div>


<div class="jodi_chart_bg">


<div align="center">
<center>
<table class="strong tbls" style="">
<thead>
 
 <tr class="bg_tr">
     
<td>Mon</td>
		
<td>Tue</td>
		
<td>Wed</td>
		
<td>Thr</td>
		
<td>Fri</td>
<?php if($run>5){ ?>
<td>Sat</td>
<?php if($run>6){ ?>		
<td>Sun</td>
<?php }?>  
<?php }?>    
 </tr>  
 
 <?php
    $run=$check['run_in_week'];
    
 
 ?>
  </thead>
 <tbody>
<tr>
    <?php 
    foreach($list as $data){ 
      $dayname = date('D', strtotime($data['date'])); 
      //$no_of_day=$data['date'];
      
  
       
 ?>

     
   
    <?php if($dayname=='Mon'){  
          $ss=explode('-',$data['game_number']);
        echo " <td><span style=color:$data[color]>  $ss[1]</span></td>";
      
      } ?>
      <?php if($dayname=='Tue'){  
          $ss=explode('-',$data['game_number']);
         echo " <td><span style=color:$data[color]>  $ss[1]</span></td>";
        
      } ?>
      <?php if($dayname=='Wed'){  
          $ss=explode('-',$data['game_number']);
        echo " <td><span style=color:$data[color]>  $ss[1]</span></td>";
     
      } ?>
       <?php  if($dayname=='Thu'){  
          $ss=explode('-',$data['game_number']);
         echo " <td><span style=color:$data[color]>  $ss[1]</span></td>";
      
      } ?>
       <?php if($dayname=='Fri'){  
          $ss=explode('-',$data['game_number']);
       echo " <td><span style=color:$data[color]>  $ss[1]</span></td>";
         
        
      } ?> 
       
       <?php if($run>=6){ if($dayname=='Sat'){   
          $ss=explode('-',$data['game_number']);
        echo " <td><span style=color:$data[color]>  $ss[1]</span></td>";
     
      }} ?> 
       <?php if($run>=7){if($dayname=='Sun'){  
          $ss=explode('-',$data['game_number']);
          echo " <td><span style=color:$data[color]>  $ss[1]</span></td>";
        
      } }?> 
	

 <?php if($run==5){if($dayname=='Fri'){   ?>
     </tr><tr>
 <?php  } }  ?>
 <?php if($run==6){if($dayname=='Sat'){   ?>
     </tr><tr>
 <?php  } }  ?>
  <?php if($run==7){if($dayname=='Sun'){   ?>
     </tr><tr>
 <?php  } }  ?>

<?php } ?>


</tbody></table></center></div></div>




<div class="keyword_top"><a href="#" class="link_hover">MATKA</a><br>ALL RIGHTS RESERVED (2021-2026)<br>Admin<br><a href="tel:<?=$mobile;?>" class="link_hover"><?=$mobile;?></a></div>

<div class="padding10"><a href="javascript:history.back()" class="btn btn-success">Back</a><a href="<?= base_url(); ?>" class="btn btn-warning">Home</a></div>

<div class="text-center msd" >
<input class="btnrefresh" type="button" id="regbut" onclick="window.location.reload()" value="Refresh"><div class="clear">    
</div>

<div class="text-center msn">
<a href="tel:<?=$mobile;?>" class="btncall">Call Us</a>
</div>

<style>
  

</style>

