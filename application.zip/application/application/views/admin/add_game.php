<style>
 .d-none {
    display: none !important;
}
.info_info{
	margin-bottom: 20px;
	margin-left: 20%;
}

body {
    margin: 0;
    font-family: Nunito,-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;
    font-size: .875rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    text-align: left;
    background-color: #e12335 !important;
}

</style>

<div class="container-fluid p-0">
		<h1 class="h3 mb-3">Add New Game</h1>&nbsp; <a href="<?=base_url('admin/view_all_game');?>" class="btn btn-success" style="float: right;">View</a> <br><br>
			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-body">
							<?php
							if($this->session->flashdata('details'))
							{
							  $det = $this->session->flashdata('details');	
							  echo '<div class=" alert alert-'.$det['type'].'" style="padding: 10px;">'.$det['msg'].'</div>';
							}
							?>
							
								<?php echo $this->session->flashdata('error'); ?>
							
							<form id="forms" method="post" action="" role="form" enctype="multipart/form-data" >
							   <div class="form-row">
									
									<div class="form-group col-md-6">
										<label for="inputEmail4">Game Name</label>
										<input type="text" name="game_name" class="form-control" value="<?php if(isset($game['game_name'])) { echo $game['game_name'];} ?>" id="inputEmail4" placeholder="Enter Game Name" required>
									</div>
								
								</div>
								
							   <div class="form-row">
									
									<div class="form-group col-md-6">
										<label for="inputEmail4">Start Time</label>
										<input type="time" name="start_time" class="form-control" value="<?php if(isset($game['start_time'])) { echo $game['start_time'];} ?>" id="inputEmail4" placeholder="Select start time" required>
									</div>
								
								</div>
								 <div class="form-row">
									
									<div class="form-group col-md-6">
										<label for="inputEmail4">End Time</label>
										<input type="time" name="end_time" class="form-control" value="<?php if(isset($game['end_time'])) { echo $game['end_time'];} ?>" id="inputEmail4" placeholder="Select end time" required>
									</div>
								
								</div>
								
								<div class="form-row">
								
									<div class="col-md-6">
									    
									        	<label for="inputEmail4">Position</label><br>
										
										<input type="number" mim='1' max='999' name="position" class="form-control" value="<?php if(isset($game['position'])) { echo $game['position'];} ?>" placeholder="Input position"  required >
									
									
									</div>
								
								</div><br>
								
								
								<div class="form-row">
									
									<div class="form-group col-md-4">
									Monday To Sunday - 7 Days  <input type="radio" name="run_in_week" class="" value="7" <?php if(isset($game['run_in_week']) && $game['run_in_week'] == '7') { echo "checked";} ?> id="inputEmail4" placeholder="" required>
									
									</div>
									<div class="form-group col-md-4">
										Monday To Saturday - 6 Days <input type="radio" name="run_in_week" class="" value="6" <?php if(isset($game['run_in_week']) && $game['run_in_week'] == '6') { echo "checked";} ?> id="inputEmail4" placeholder="" required>
										
									</div>
									<div class="form-group col-md-4">
									Monday To Friday - 5 Days  <input type="radio" name="run_in_week" class="" value="5" <?php if(isset($game['run_in_week']) && $game['run_in_week'] == '5') { echo "checked";} ?> id="inputEmail4" placeholder="" required>
									
									</div>
								
								</div>	
							
								<br>
								<center>
								<button type="submit" class="btn btn-primary">Submit</button>
								</center>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	
