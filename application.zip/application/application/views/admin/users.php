<div class="container-fluid p-0">
	<h1 class="h3 mb-3">Users</h1>
	<div class="row">
		<div class="col-12">
			<div class="card">
				<div class="card-body">
					<?php
					if($this->session->flashdata('details'))
					{
					  $det = $this->session->flashdata('details');	
					  echo '<div class="p-1 alert alert-'.$det['type'].'">'.$det['msg'].'</div>';
					}
					?>
					<table id="datatables-buttons" class="table table-striped" style="width:100%">
						<thead>
							<tr>
								<th>Name</th>
								<th>Email</th>
								<th>Contact</th>
								<th>Password</th>
								<th>Address</th>
								<th>Landmark </th>
								<th>State</th>
								<th>City</th>
								<th>Pincode </th>
								
								<th>Status</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php
							if(isset($scat['users'])){
							    $i =1;
							foreach ($scat['users'] as $k) {
								 $state=$this->Main_model->getstatebyid($k->state);
								
							$scator = 'scat_'.$i;?>
							<tr>
								<td><a href="<?=base_url('admin/user_history/'.$k->id)?>"><?=$k->name;?></td>
								<td><?=$k->email;?></td>
								<td><?=$k->contact?></td>
								<td><?=$k->password ?></td>
								<td><?=$k->address ?></td>
								<td><?=$k->landmark ?></td>
								<td><?=$state['name']?></td>
								<td><?=$k->city ?></td>
								<td><?=$k->pin_code ?></td>
								<td><?=ucfirst($k->status);?></td>
								<td><a href="<?=base_url('admin/edit_users/'.$k->id)?>" ><button class="btn btn-success">Edit</button></a>&nbsp;<a href="<?=base_url('admin/delete_user/'.$k->id)?>" ><button class="btn btn-danger" onclick="return confirm(`Are you sure you want to Delete this User?`);">Delete</button></a></td>
								
							</tr>
						<?php $i++; } } ?>
							
							
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>				
</div>
	<script>
		$(function() {
			// Datatables with Buttons
			var datatablesButtons = $("#datatables-buttons").DataTable({
				responsive: true,
				lengthChange: !1,
				buttons: ["excel","print"]
			});
			datatablesButtons.buttons().container().appendTo("#datatables-buttons_wrapper .col-md-6:eq(0)");
		});
	</script>
<<!-- script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script> -->
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.print.min.js"></script>


