<style>
 .d-none {
    display: none !important;
}
.info_info{
	margin-bottom: 20px;
	margin-left: 20%;
}


</style>

<div class="container-fluid p-0">
		<h1 class="h3 mb-3">Edit User</h1>
			<div class="row">
				<div class="col-md-10">
					<div class="card">
						<div class="card-body">
							<?php
							if($this->session->flashdata('details'))
							{
							  $det = $this->session->flashdata('details');	
							  echo '<div class=" alert alert-'.$det['type'].'" style="padding: 10px;">'.$det['msg'].'</div>';
							}
							?>
							<?php 
							#   echo"<pre>";print_r($s_user); 
							   $chk='0';
							   if(!empty($s_user->additional_emails) || !empty($s_user->additional_contacts) || !empty($s_user->additional_addresses) || !empty($s_user->additional_socials) || !empty($s_user->servies) || !empty($s_user->bio) ){$chk='1';}
							  
							
							
							?>
							<form method="post" action="<?php echo base_url('admin/update_new_user/'.$s_user->id)?>" role="form" enctype="multipart/form-data" >
							   <div class="form-row">
									<div class="form-group col-md-2">
										<label for="inputEmail4">Prefix</label>
										<select  name="prefix" class="form-control" id="inputEmail4" >
										   <option value =''>Select</option>
										   <option value ='Mr.' <?php if($s_user=='Mr.'){echo "selected";}?>>Mr.</option>
										   <option value ='Mrs.'  <?php if($s_user=='Mrs.'){echo "selected";}?>>Mrs.</option>
										   <option value ='Miss.' <?php if($s_user=='Miss.'){echo "selected";}?>>Miss.</option>
										  
										</select>
									</div>
									<div class="form-group col-md-4">
										<label for="inputEmail4">Name</label>
										<input type="text" name="name" class="form-control" value="<?php echo $s_user->name;?>" id="inputEmail4" placeholder="Name" >
									</div>
									
								</div>
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Email</label>
										<input type="email" name="email" class="form-control" value="<?php echo $s_user->email;?>" id="inputEmail4" placeholder="Email" >
									</div>
									
								</div>
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Contact Number</label>
										<input type="text" name="contact" class="form-control" value="<?php echo $s_user->contact;?>" id="inputEmail4" placeholder="Contact No." >
									</div>
									
								</div>
								
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Address</label>
										<textarea type="text" name="address" class="form-control"  id="inputEmail4" placeholder="Address"><?php echo $s_user->address;?></textarea>
									</div>
									
								</div>
													
								
							
							<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Company Name</label>
										<input type="text" name="company_name" value="<?php echo $s_user->company_name;?>" class="form-control" placeholder="Company Name" > 
								</div>
								
							</div>
							<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Designation</label>
										<input type="text" name="designation" value="<?php echo $s_user->designation;?>" class="form-control" placeholder='designation' > 
								</div>
								
							</div>
                            							
							
								<div class="form-row">
									<input type="hidden" name="old_image" value="<?=$s_user->img;?>"> 
									<div class="form-group col-md-6">
										<img src="<?php echo base_url($s_user->img); ?>" alt="logo" style="max-height: 100px;"><br> 
										<label for="inputAddress">Profile Image</label>
										<input type="file" class="form-control" id="inputAddress" name="image" placeholder="profile" >
									</div>
								</div>
								
								
								
								 <a href="javascript:void(0);" class="btn btn-primary info_info more " onclick="show_info()"> More Info </a>
								 <br>
								
								 
								<div class='additional_information' <?php if($chk=='1'){ ?> style="display:block;" <?php }else{?> style="display:none;"  <?php }?>>
								
								 <!--Email-->
								 <h5>Email Information</h5>
								<div class="email_data" style="padding:20px">
								<?php if(!empty($s_user->additional_emails)){
									     $email_add_data = json_decode($s_user->additional_emails,true);
									   # echo"<pre>"; print_r($email_add_data);
									     foreach($email_add_data as $k => $va){
								?>
								<div class="form-row rows_e">
								
								    <div class="form-group col-md-2">
									   <label for="inputEmail4">Select Type</label>
									   <input list="email_type_list" name="email_type[]" class="form-control email_opt" autocomplete="off" value="<?php echo $k;?>" />
											<datalist id="email_type_list">
											 <option value ='Home'>Home</option>
										     <option value ='Work'>Work</option>
											</datalist>
									 										
									</div>
									<div class="form-group col-md-4">
										<label for="inputEmail4">Email</label>
										<input type="email" name="email_additional[]" class="form-control" value="<?php echo $va;?>" id="inputEmail4" placeholder="Email" >
									</div>
									 <a class="btn-pluse_email"><i class="fa fa-plus" aria-hidden="true"></i></a>
									  &nbsp;&nbsp;&nbsp
									    <a class="btn-minus_email d-none"><i class="fa fa-minus" aria-hidden="true"></i></a>
								</div>
								<?php }}else{ ?>
								
								  <div class="form-row rows_e">
								
								    <div class="form-group col-md-2">
									   <label for="inputEmail4">Select Type</label>
									   <input list="email_type_list" name="email_type[]" class="form-control email_opt" autocomplete="off" value="" />
											<datalist id="email_type_list">
											 <option value ='Home'>Home</option>
										     <option value ='Work'>Work</option>
											</datalist>
									 										
									</div>
									<div class="form-group col-md-4">
										<label for="inputEmail4">Email</label>
										<input type="email" name="email_additional[]" class="form-control" value="" id="inputEmail4" placeholder="Email" >
									</div>
									 <a class="btn-pluse_email"><i class="fa fa-plus" aria-hidden="true"></i></a>
									  &nbsp;&nbsp;&nbsp
									    <a class="btn-minus_email d-none"><i class="fa fa-minus" aria-hidden="true"></i></a>
								</div>
								
								<?php } ?>
								</div>
								<!--Contact-->
								<h5>Contact Information</h5>
								<div class="contact_data" style="padding:20px">
								<?php if(!empty($s_user->additional_contacts)){
									     $contacts_add_data = json_decode($s_user->additional_contacts,true);
									   # echo"<pre>"; print_r($email_add_data);
									     foreach($contacts_add_data as $k => $va){
								?>
								<div class="form-row rows_c">
								  <div class="form-group col-md-2">
									   <label for="inputEmail4">Select Type</label>
									   <input list="contact_type_list" name="contact_type[]" class="form-control email_opt" value="<?php echo $k;?>"  />
											<datalist id="contact_type_list">
											 <option value ='Home'>Home</option>
										     <option value ='Work'>Work</option>
											</datalist>
									 										
									</div>
									
									<div class="form-group col-md-4">
										<label for="inputEmail4">Contact Number</label>
										<input type="text" name="contact_additional[]" class="form-control" value="<?php echo $va;?>" id="inputEmail4" placeholder="Contact No." >
									</div>
									  <a class="btn-pluse_contact"><i class="fa fa-plus" aria-hidden="true"></i></a>
									  &nbsp;&nbsp;&nbsp
									    <a class="btn-minus_contact d-none"><i class="fa fa-minus" aria-hidden="true"></i></a>
								</div>
								<?php }}else{?>
								 <div class="form-row rows_c">
								  <div class="form-group col-md-2">
									   <label for="inputEmail4">Select Type</label>
									   <input list="contact_type_list" name="contact_type[]" class="form-control email_opt"  />
											<datalist id="contact_type_list">
											 <option value ='Home'>Home</option>
										     <option value ='Work'>Work</option>
											</datalist>
									 										
									</div>
									
									<div class="form-group col-md-4">
										<label for="inputEmail4">Contact Number</label>
										<input type="text" name="contact_additional[]" class="form-control" value="" id="inputEmail4" placeholder="Contact No." >
									</div>
									  <a class="btn-pluse_contact"><i class="fa fa-plus" aria-hidden="true"></i></a>
									  &nbsp;&nbsp;&nbsp
									    <a class="btn-minus_contact d-none"><i class="fa fa-minus" aria-hidden="true"></i></a>
								</div>
								<?php } ?>
								</div>
								<!--Address-->
								<h5>Address Information</h5>
								<div class="address_data" style="padding:20px">
								
								<?php if(!empty($s_user->additional_addresses)){
									     $address_add_data = json_decode($s_user->additional_addresses,true);
									   # echo"<pre>"; print_r($email_add_data);
									     foreach($address_add_data as $k => $va){
								?>
								
								<div class="form-row rows_a">
								
									<div class="form-group col-md-2">
									   <label for="inputEmail4">Select Type</label>
									   <input list="address_type_list" name="address_type[]" class="form-control address_opt" value="<?php echo $k;?>"  />
											<datalist id="address_type_list">
											 <option value ='Home'>Home</option>
										     <option value ='Work'>Work</option>
											</datalist>
									 										
									</div>
									
									<div class="form-group col-md-4">
										<label for="inputEmail4">Address</label>
										<input type="text" name="address_additional[]" class="form-control"  value="<?php echo $va;?>"  id="inputEmail4" placeholder="Address">
									</div>
									
									
									 <a class="btn-pluse_address"><i class="fa fa-plus" aria-hidden="true"></i></a>
									  &nbsp;&nbsp;&nbsp
									    <a class="btn-minus_address d-none"><i class="fa fa-minus" aria-hidden="true"></i></a>
								</div>
								<?php }}else{  ?>
									<div class="form-row rows_a">
								
									<div class="form-group col-md-2">
									   <label for="inputEmail4">Select Type</label>
									   <input list="address_type_list" name="address_type[]" class="form-control address_opt"  />
											<datalist id="address_type_list">
											 <option value ='Home'>Home</option>
										     <option value ='Work'>Work</option>
											</datalist>
									 										
									</div>
									
									<div class="form-group col-md-4">
										<label for="inputEmail4">Address</label>
										<input type="text" name="address_additional[]" class="form-control" value="" id="inputEmail4" placeholder="Address">
									</div>
									
									
									 <a class="btn-pluse_address"><i class="fa fa-plus" aria-hidden="true"></i></a>
									  &nbsp;&nbsp;&nbsp
									    <a class="btn-minus_address d-none"><i class="fa fa-minus" aria-hidden="true"></i></a>
								</div>
							    <?php }?>
								</div>
								
								<!--Social Media-->
								<h5>Social Media Information</h5>
								<div class="social_data" style="padding:20px">
								
								 <?php if(!empty($s_user->additional_socials)){
									     $social_add_data = json_decode($s_user->additional_socials,true);
									   # echo"<pre>"; print_r($email_add_data);
									     foreach($social_add_data as $k => $va){
								?>
								<div class="form-row rows_so">
								
									<div class="form-group col-md-2">
									   <label for="inputEmail4">Select Type</label>
									   <input list="social_type_list" name="social_type[]" class="form-control social_opt" value="<?php echo $k;?>"  />
											<datalist id="social_type_list">
											 <option value ='LinkedIn'>LinkedIn</option>
										     <option value ='Youtube'>Youtube</option>
										     <option value ='Instagram'>Instagram</option>
										     <option value ='Twitter'>Twitter</option>
										     <option value ='Facebook'>Facebook</option>
											</datalist>
									 										
									</div>
									
									<div class="form-group col-md-4">
										<label for="inputEmail4">Social Media</label>
										<input type="text" name="social_additional[]" class="form-control"value="<?php echo $va;?>" id="inputEmail4" placeholder="social">
									</div>
									 <a class="btn-pluse_social"><i class="fa fa-plus" aria-hidden="true"></i></a>
									  &nbsp;&nbsp;&nbsp
									    <a class="btn-minus_social d-none"><i class="fa fa-minus" aria-hidden="true"></i></a>
								</div>
								 <?php }}else{?>
								 <div class="form-row rows_so">
								
									<div class="form-group col-md-2">
									   <label for="inputEmail4">Select Type</label>
									   <input list="social_type_list" name="social_type[]" class="form-control social_opt"  />
											<datalist id="social_type_list">
											 <option value ='LinkedIn'>LinkedIn</option>
										     <option value ='Youtube'>Youtube</option>
										     <option value ='Instagram'>Instagram</option>
										     <option value ='Twitter'>Twitter</option>
										     <option value ='Facebook'>Facebook</option>
											</datalist>
									 										
									</div>
									
									<div class="form-group col-md-4">
										<label for="inputEmail4">Social Media</label>
										<input type="text" name="social_additional[]" class="form-control" value="" id="inputEmail4" placeholder="social">
									</div>
									 <a class="btn-pluse_social"><i class="fa fa-plus" aria-hidden="true"></i></a>
									  &nbsp;&nbsp;&nbsp
									    <a class="btn-minus_social d-none"><i class="fa fa-minus" aria-hidden="true"></i></a>
								</div>
								 <?php }?>
								</div>
								<h5>Additional Information</h5>
								<div class="form-row ">
																	
									<div class="form-group col-md-6">
										<label for="inputEmail4">Service</label>
										<input type="text" name="service" class="form-control" value="<?php echo $s_user->service;?>" id="inputEmail4" placeholder="Service">
									</div>
									
								</div>
								
								<div class="form-row ">
																	
									<div class="form-group col-md-6">
										<label for="inputEmail4">Bio</label>
										<input type="text" name="bio" class="form-control" value="<?php echo $s_user->bio;?>" id="inputEmail4" placeholder="Bio">
									</div>
									
								</div>
								
								 <a href="javascript:void(0);" class="btn btn-danger info_info" onclick="show_less()"> Less Info </a>
								
								</div>
								

								
								<button type="submit" name="submit" class="btn btn-primary">Submit</button>
								<a href="<?=base_url('admin/user');?>" class="btn btn-danger">Cancel</a>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<script>
		
		  $(document).ready(function(){
			   <?php if($ckh=='0'){?>
			   $( " .additional_information input" ).prop( "disabled", true ); //Disable
			   <?php }else{ ?>
			    $( " .additional_information input" ).prop( "disabled", false ); //Disable
			   <?php } ?>
		  });
		
		
		
		  function show_info(){
			  $('.additional_information').css('display','block');
			  $('.more').hide();
			  $( ".additional_information input" ).prop( "disabled", false ); //Enable
			  
		  } 
		  function show_less(){
			  $('.additional_information').css('display','none');
			  $('.more').show();
			  $( ".additional_information input" ).prop( "disabled", true ); //Disable
		  }
		
		
		
		
		 /// contact
		
		
		 $(document).off('click','.btn-pluse_contact').on('click','.btn-pluse_contact',function(){
				/*if($(this).closest('.row').find('select').data('select2'))
				{
					$(this).closest('.row').find('select')
								.select2('destroy');	
				} */
				var html = $(this).closest('.rows_c').clone();
				$(this).addClass('d-none');
							
				$(this).closest('.contact_data').append(html);

				$(this).closest('.contact_data .rows_c:last input').val('');

				//$(this).closest('.contact_data .row:last select').val(null).trigger('change');	
				
				$(this).closest('.contact_data').find('.btn-minus_contact').removeClass('d-none');
				$(this).closest('.contact_data').find('.btn-minus_contact:first').addClass('d-none');
                  /*
				$('.more-input .body_part,.disease').each(function(){
					$(this).removeAttr('data-select2-id');
				})
				$('.more-input .body_part').select2({
					placeholder:'Select Body part',
				});
				$('.more-input .disease').select2({
					placeholder:'Select Disease',
				});
                  */
			});
			
			$(document).off('click','.btn-minus_contact').on('click','.btn-minus_contact',function(){
				$this = $(this).closest('.contact_data');

				//console.log($this);
				$(this).closest('.rows_c').remove();

				($this).closest('.contact_data').find('.rows_c:last .btn-pluse_contact').removeClass('d-none');

			});
			
			
			/// email
			
			 $(document).off('click','.btn-pluse_email').on('click','.btn-pluse_email',function(){
				/*if($(this).closest('.row').find('select').data('select2'))
				{
					$(this).closest('.row').find('select')
								.select2('destroy');	
				} */
				var html = $(this).closest('.rows_e').clone();
				$(this).addClass('d-none');
							
				$(this).closest('.email_data').append(html);

				$(this).closest('.email_data .rows_e:last input').val('');

				//$(this).closest('.contact_data .row:last select').val(null).trigger('change');	
				
				$(this).closest('.email_data').find('.btn-minus_email').removeClass('d-none');
				$(this).closest('.email_data').find('.btn-minus_email:first').addClass('d-none');
                  /*
				$('.more-input .body_part,.disease').each(function(){
					$(this).removeAttr('data-select2-id');
				})
				$('.more-input .body_part').select2({
					placeholder:'Select Body part',
				});
				$('.more-input .disease').select2({
					placeholder:'Select Disease',
				});
                  */
			});
			
			$(document).off('click','.btn-minus_email').on('click','.btn-minus_email',function(){
				$this = $(this).closest('.email_data');

				//console.log($this);
				$(this).closest('.rows_e').remove();

				($this).closest('.email_data').find('.rows_e:last .btn-pluse_email').removeClass('d-none');

			});
			
			//address
		     
			 
			 $(document).off('click','.btn-pluse_address').on('click','.btn-pluse_address',function(){
				/*if($(this).closest('.row').find('select').data('select2'))
				{
					$(this).closest('.row').find('select')
								.select2('destroy');	
				} */
				var html = $(this).closest('.rows_a').clone();
				$(this).addClass('d-none');
							
				$(this).closest('.address_data').append(html);

				$(this).closest('.address_data .rows_a:last input').val('');

				//$(this).closest('.contact_data .row:last select').val(null).trigger('change');	
				
				$(this).closest('.address_data').find('.btn-minus_address').removeClass('d-none');
				$(this).closest('.address_data').find('.btn-minus_address:first').addClass('d-none');
                  /*
				$('.more-input .body_part,.disease').each(function(){
					$(this).removeAttr('data-select2-id');
				})
				$('.more-input .body_part').select2({
					placeholder:'Select Body part',
				});
				$('.more-input .disease').select2({
					placeholder:'Select Disease',
				});
                  */
			});
			
			$(document).off('click','.btn-minus_address').on('click','.btn-minus_address',function(){
				$this = $(this).closest('.address_data');

				//console.log($this);
				$(this).closest('.rows_a').remove();

				($this).closest('.address_data').find('.rows_a:last .btn-pluse_address').removeClass('d-none');

			});
			
				//Social media
		     
			 
			 $(document).off('click','.btn-pluse_social').on('click','.btn-pluse_social',function(){
				/*if($(this).closest('.row').find('select').data('select2'))
				{
					$(this).closest('.row').find('select')
								.select2('destroy');	
				} */
				var html = $(this).closest('.rows_so').clone();
				$(this).addClass('d-none');
							
				$(this).closest('.social_data').append(html);

				$(this).closest('.social_data .rows_so:last input').val('');

				//$(this).closest('.contact_data .row:last select').val(null).trigger('change');	
				
				$(this).closest('.social_data').find('.btn-minus_social').removeClass('d-none');
				$(this).closest('.social_data').find('.btn-minus_social:first').addClass('d-none');
                  /*
				$('.more-input .body_part,.disease').each(function(){
					$(this).removeAttr('data-select2-id');
				})
				$('.more-input .body_part').select2({
					placeholder:'Select Body part',
				});
				$('.more-input .disease').select2({
					placeholder:'Select Disease',
				});
                  */
			});
			
			$(document).off('click','.btn-minus_social').on('click','.btn-minus_social',function(){
				$this = $(this).closest('.social_data');

				//console.log($this);
				$(this).closest('.rows_so').remove();

				($this).closest('.social_data').find('.rows_so:last .btn-pluse_social').removeClass('d-none');

			});
			 
		
		</script>
