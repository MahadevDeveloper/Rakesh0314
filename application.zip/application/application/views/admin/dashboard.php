<style type="text/css">.linkcolor{text-decoration: none !important; color: #495057;}.linkcolor:hover{text-decoration: none !important;}</style>
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.3/dist/Chart.min.js"></script>


   <style>
a {
    color: #ffc800;
    text-decoration: none;
    background-color: transparent;
}

.fa {
        border-radius: 50%;
    background-color: #3770d7;
    padding: 10px;
}
       body{
           background-color: #df2d2d;
       }
   </style>

        <main class="main">
        <?php
        error_reporting(0);
           
            ?>

  <div class="container-fluid p-0">
	
	<div class="row mb-2 mb-xl-4">
		<div class="col-auto d-none d-sm-block">
			
		</div>
	</div>
<?php
//print_r($user_count);
?>
   
   <div class="row">
       
    <div class="col-6">
        
        <div class="col-md-2">
            
       <a href="<?= base_url();?>admin/todayluky"> <img src="<?= base_url();?>assets/img/mobile.png" style="width: auto; height: 124px;">Todaty Luky Number </a> <br><br>   
            
        </div>
   <!--       
        <div class="col-md-2">
            
       <a href="<?= base_url();?>"> <img src="<?= base_url();?>assets/img/home.png" style="width: auto; height: 124px;"> </a> <br><br>   
            
        </div>
        
          -->
        <div class="col-md-2">
            
       <a href="<?= base_url();?>admin/edit_setting/1"> <img src="<?= base_url();?>assets/img/mobile.png" style="width: auto; height: 124px;"> </a> <br><br>   
            
        </div>
      
        <div class="col-md-2">
            
        <a href="<?= base_url();?>admin/add_game"> <img src="<?= base_url();?>assets/img/game.png" style="width: auto; height: 124px;"></a><br><br>
            
        </div>
        
        <div class="col-md-2">
            
        <a href="<?= base_url();?>admin/add_daily_entry"> <img src="<?= base_url();?>assets/img/daily entry.png" style="width: auto; height: 124px;"> </a> <br><br>   
            
        </div>
        
         <div class="col-md-2">
            
       <a href="<?= base_url();?>admin/add_description"> <img src="<?= base_url();?>assets/img/notification.png" style="width: auto; height: 124px;"> </a> <br><br>   
            
        </div>
      
         
        <div class="col-md-2">
            
        <a href="<?= base_url();?>admin/update_daily_entry"> <img src="<?= base_url();?>assets/img/update.png" style="width: auto; height: 124px;"> </a>  <br><br>  
            
        </div>
      
    </div>    
 
   <div class="col-6">
       
          
       
      
        
        <div class="col-md-2">
            
        <a href="<?= base_url();?>admin/gussing"> <img src="<?= base_url();?>assets/matka/gussing.png" style="width: auto; height: 124px;"> </a>  <br><br>  
            
        </div>
        
         <div class="col-md-2">
            
        <a href="<?= base_url();?>admin/add_leak_game/1"> <img src="<?= base_url();?>assets/matka/leak game.png" style="width: auto; height: 124px;"> </a><br><br>
            
        </div>
        
        <div class="col-md-2">
            
        <a href="<?= base_url();?>admin/add_passing_record/1"> <img src="<?= base_url();?>assets/matka/passing record.png" style="width: auto; height: 124px;"> </a>  <br><br>  
            
        </div>
        
        <div class="col-md-2">
            
        <a href="<?= base_url();?>admin/add_membership_charges/1"> <img src="<?= base_url();?>assets/matka/membership charges.png" style="width: auto; height: 124px;"> </a>  <br><br>  
            
        </div>
        
        <div class="col-md-2">
            
        <a href="<?= base_url();?>admin/add_game_description"> <img src="<?= base_url();?>assets/img/title.png" style="width: auto; height: 124px;"> </a>  <br><br>  
            
        </div>
     
        
       
   </div>       
 
 
 
    </div>
    
    
    
    
    <br/><br/><br/><br/>
	<div class="row">
		<div class="col-md-3 col-sm-12  d-flex">
			<div class="card flex-fill">
				<div class="card-body py-4">
					<div class="media">
						<div class="d-inline-block mt-2 mr-3">
							<i class="feather-lg text-primary" data-feather="user"></i>
						</div>
						<div class="media-body">
						    <p class="linkcolor">
							<h3 class="mb-2"><?php $result = $this->db->get('add_game'); 
							                echo $result->num_rows();?></h3>
						    	<div class="mb-0">Total Number of games </div>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>

        </div>
	</div>
	
</div>
<script>
		$(function() {
			// Bar chart
			new Chart(document.getElementById("chartjs-dashboard-bar"), {
				type: "bar",
				data: {
					labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
					datasets: [{
						label: "Last year",
						backgroundColor: window.theme.primary,
						borderColor: window.theme.primary,
						hoverBackgroundColor: window.theme.primary,
						hoverBorderColor: window.theme.primary,
						data: [54, 67, 41, 55, 62, 45, 55, 73, 60, 76, 48, 79]
					}, {
						label: "This year",
						backgroundColor: "#E8EAED",
						borderColor: "#E8EAED",
						hoverBackgroundColor: "#E8EAED",
						hoverBorderColor: "#E8EAED",
						data: [69, 66, 24, 48, 52, 51, 44, 53, 62, 79, 51, 68]
					}]
				},
				options: {
					maintainAspectRatio: false,
					legend: {
						display: false
					},
					scales: {
						yAxes: [{
							gridLines: {
								display: false
							},
							stacked: false,
							ticks: {
								stepSize: 20
							}
						}],
						xAxes: [{
							barPercentage: .75,
							categoryPercentage: .5,
							stacked: false,
							gridLines: {
								color: "transparent"
							}
						}]
					}
				}
			});
		});
	</script>
	<script>
		$(function() {
			$("#datetimepicker-dashboard").datetimepicker({
				inline: true,
				sideBySide: false,
				format: "L"
			});
		});
	</script>
	<script>
		$(function() {
			// Line chart
			new Chart(document.getElementById("chartjs-dashboard-line"), {
				type: "line",
				data: {
					labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
					datasets: [{
						label: "Sales ($)",
						fill: true,
						backgroundColor: "transparent",
						borderColor: window.theme.primary,
						data: [2015, 1465, 1487, 1796, 1387, 2123, 2866, 2548, 3902, 4938, 3917, 4927]
					}, {
						label: "Orders",
						fill: true,
						backgroundColor: "transparent",
						borderColor: window.theme.tertiary,
						borderDash: [4, 4],
						data: [928, 734, 626, 893, 921, 1202, 1396, 1232, 1524, 2102, 1506, 1887]
					}]
				},
				options: {
					maintainAspectRatio: false,
					legend: {
						display: false
					},
					tooltips: {
						intersect: false
					},
					hover: {
						intersect: true
					},
					plugins: {
						filler: {
							propagate: false
						}
					},
					scales: {
						xAxes: [{
							reverse: true,
							gridLines: {
								color: "rgba(0,0,0,0.05)"
							}
						}],
						yAxes: [{
							ticks: {
								stepSize: 500
							},
							display: true,
							borderDash: [5, 5],
							gridLines: {
								color: "rgba(0,0,0,0)",
								fontColor: "#fff"
							}
						}]
					}
				}
			});
		});
	</script>
	<script>
		$(function() {
			// Pie chart
			new Chart(document.getElementById("chartjs-dashboard-pie"), {
				type: "pie",
				data: {
					labels: ["Direct", "Affiliate", "E-mail", "Other"],
					datasets: [{
						data: [2602, 1253, 541, 1465],
						backgroundColor: [
							window.theme.primary,
							window.theme.warning,
							window.theme.danger,
							"#E8EAED"
						],
						borderColor: "transparent"
					}]
				},
				options: {
					responsive: !window.MSInputMethodContext,
					maintainAspectRatio: false,
					legend: {
						display: false
					}
				}
			});
		});
	</script>
	<script>
		$(function() {
			$("#datatables-dashboard-projects").DataTable({
				pageLength: 6,
				lengthChange: false,
				bFilter: false,
				autoWidth: false
			});
		});
	</script>
	<script>

    // var month_list = ['JAN','FEB','MAR','APR','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
   var month_list=['1','2','3','4','5','6','7','8','9','10','11','12'];
  var month = '<?php echo json_encode($months) ?>';
  month  = JSON.parse(month);

  var vendor = '<?php echo json_encode($total_vendor) ?>';
   vendor = JSON.parse(vendor);
  //console.log(vendor);

var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: month,
        datasets: [{
            label: '# total User',
            data: vendor,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    precision: 0
                }
            }]
        },
        title:{
            display:true,
            text:"Monthly User",
            position:"bottom",
            fontStyle:"bold",
            lineHeight:1.2,
            fontSize:20
        }
    }
});

 var month_list=['1','2','3','4','5','6','7','8','9','10','11','12'];
  var months = '<?php echo json_encode($months1) ?>';
  months  = JSON.parse(months);

  var order = '<?php echo json_encode($total_order) ?>';
   order = JSON.parse(order);
  console.log(order);

var ctx = document.getElementById('myChart2').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: months,
        datasets: [{
            label: '# total Order',
            data: order,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    precision: 0
                }
            }]
        },
        title:{
            display:true,
            text:"Monthly Order",
            position:"bottom",
            fontStyle:"bold",
            lineHeight:1.2,
            fontSize:20
        }
    }
});
var month_list=['1','2','3','4','5','6','7','8','9','10','11','12'];
  var months = '<?php echo json_encode($months3) ?>';
  months  = JSON.parse(months);

  var order = '<?php echo json_encode($total_order_deliver) ?>';
   order = JSON.parse(order);
  console.log(order);

var ctx = document.getElementById('myChart3').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: months,
        datasets: [{
            label: '# total Deliver Order',
            data: order,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    precision: 0
                }
            }]
        },
        title:{
            display:true,
            text:"Monthly Order Deliver",
            position:"bottom",
            fontStyle:"bold",
            lineHeight:1.2,
            fontSize:20
        }
    }
});
var month_list=['1','2','3','4','5','6','7','8','9','10','11','12'];
  var months = '<?php echo json_encode($months4) ?>';
  months  = JSON.parse(months);

  var order = '<?php echo json_encode($product_graph1) ?>';
   order = JSON.parse(order);
  console.log(order);
var ctx = document.getElementById('myChart4').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: months,
        datasets: [{
            label: '# Added Products',
            data: order,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    precision: 0
                }
            }]
        },
        title:{
            display:true,
            text:"Monthly Add Product",
            position:"bottom",
            fontStyle:"bold",
            lineHeight:1.2,
            fontSize:20
        }
    }
});
</script>
