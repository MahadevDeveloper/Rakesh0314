<style>
 .d-none {
    display: none !important;
}
.info_info{
	margin-bottom: 20px;
	margin-left: 20%;
}

body {
    margin: 0;
    font-family: Nunito,-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;
    font-size: .875rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    text-align: left;
    background-color: #e12335 !important;
}

</style>

<div class="container-fluid p-0">
		<h1 class="h3 mb-3">Game Page Description (For SEO)</h1>&nbsp; <a href="<?=base_url('admin/view_game_page_data');?>" class="btn btn-success" style="float: right;">View</a> <br><br>
			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-body">
							<?php
							if($this->session->flashdata('details'))
							{
							  $det = $this->session->flashdata('details');	
							  echo '<div class=" alert alert-'.$det['type'].'" style="padding: 10px;">'.$det['msg'].'</div>';
							}
							?>
							<form id="forms" method="post" action="" role="form" enctype="multipart/form-data" >
							    
							    <div class="form-row">
									
									<div class="form-group col-md-6">
									    
									<?php $data = $this->db->get('add_game')->result_array(); ?>
									
									<select name="game_id" id="game_id" class="form-control">
                                          <option value="">Select game to update</option>
                                          <?php foreach($data as $row){ ?>
                                          <option value="<?= $row['id'];?>" <?php if((isset($add_game_page_data['game_id'])) && $add_game_page_data['game_id'] == $row['id'])  { echo "selected"; } ?>> <?= $row['game_name'];?></option>
                                          <?php } ?>
                                        </select>
									
									</div>
								
								</div>
							    
							   <div class="form-row">
									
									<div class="form-group col-md-6">
										<label for="inputEmail4">Title</label>
										<input type="text" name="title" class="form-control" value="<?php if(isset($add_game_page_data['title'])) { echo $add_game_page_data['title'];} ?>" id="inputEmail4" placeholder="Enter Title" required>
									</div>
								
								</div>
								
							   <div class="form-row">
									
									<div class="form-group col-md-6">
										<label for="inputEmail4">Meta Key</label>
										<textarea name="meta_desc" class="form-control" value="" id="inputEmail4" placeholder="Enter Meta Description" required> <?php if(isset($add_game_page_data['meta_desc'])) { echo $add_game_page_data['meta_desc'];} ?> </textarea>
									</div>
								
								</div>
								
								 <div class="form-row">
									
									<div class="form-group col-md-6">
										<label for="inputEmail4">Meta Description</label>
										<textarea name="description" class="form-control" value="" id="inputEmail4" placeholder="Enter Description" required> <?php if(isset($add_game_page_data['description'])) { echo $add_game_page_data['description'];} ?> </textarea>
									</div>
								
								</div>
					
					         <div class="form-row">
									
									<div class="form-group col-md-6">
										<label for="inputEmail4">Key Words (This will appear in Jodi Chart Page)</label>
										<textarea name="key_words" class="form-control" value="" id="inputEmail4" placeholder="Enter Key Words " required> <?php if(isset($add_game_page_data['key_words'])) { echo $add_game_page_data['key_words'];} ?> </textarea>
									</div>
								
								</div>
								
								  <div class="form-row">
								      
								<input type="radio" id="html" name="typechart" value="jodi" <?php if((isset($add_game_page_data['typechart']) && $add_game_page_data['typechart'] == "jodi")){ echo "checked";} ?>><br><br>
								
                                <label for="html"> Jodi Chart  </label><br><br>
                                
                                <input type="radio" id="css" name="typechart" value="panel" <?php if((isset($add_game_page_data['typechart']) && $add_game_page_data['typechart'] == "panel")){ echo "checked";} ?>><br><br>
                                
                                <label for="css"> Panel Chart </label><br><br>
							
							    </div>
							
								<br>
								<center>
								<button type="submit" class="btn btn-primary">Submit</button>
								</center>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	
