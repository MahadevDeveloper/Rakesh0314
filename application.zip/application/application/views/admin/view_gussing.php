

<style>
    body {
    margin: 0;
    font-family: Nunito,-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;
    font-size: .875rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    text-align: left;
    background-color: #e12335 !important;
}
</style>

<?php //print_r($all_user);?>
<div class="container-fluid p-0">
	<h1 class="h3 mb-3">All Gussing</h1>
					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-body">
									<?php
									if($this->session->flashdata('details'))
									{
									  $det = $this->session->flashdata('details');	
									  echo '<div class="p-1 alert alert-'.$det['type'].'">'.$det['msg'].'</div>';
									}
									?>
									<table id="datatables-buttons" class="table table-striped" style="width:100%">
										<thead>
											<tr>
												<th>S.No</th>
												<th>Game Name</th>
												<th>Game Number</th>
												<th>Status</th>
												<th>Addedon</th>
											  
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php
											if(isset($gussing)){
											    $k=1;
											  //  print_r($all_user);exit; ?>
												<?php foreach($gussing as $all ){ ?>
											<tr>
											    <td><?=$k;?></td>
												<td><?php 
												$data = $this->db->get_where('add_game', array('id'=> $all->game_id))->row_array(); 
												if(!empty($data)){
												    echo $data['game_name'];
												} ?>
												
											</td>
											<td><?=$all->game_number;?></td>
												<td>
												    <?php if($all->status == 1) { ?>
												        <a href="<?=base_url('admin/check_guss_status/'.$all->id.'/'.$all->status); ?>"><button class="btn btn-success">Active</button></a>
												   <?php }else{ ?>
												       <a href="<?=base_url('admin/check_guss_status/'.$all->id.'/'.$all->status); ?>"><button class="btn btn-danger">Inactive</button></a>
												    <?php } ?>
												    </td>
												<td><?=$all->addedon;?></td>
											 
												<td>
												    <a href="<?=base_url('admin/gussing/'.$all->id); ?>"><button class="btn btn-info">View/Edit</button></a>
												    <a href="<?=base_url('admin/delete_gussing/'.$all->id); ?>"><button class="btn btn-danger">Delete</button></a>
												    </td>
											</tr>
												<?php  $k++; } } ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>

			

	<script>
		$(function() {
			// Datatables with Buttons
			var datatablesButtons = $("#datatables-buttons").DataTable({
				responsive: true,
				lengthChange: !1,
				buttons: ["copy", "print"]
			});
			datatablesButtons.buttons().container().appendTo("#datatables-buttons_wrapper .col-md-6:eq(0)");
		});
		$(document).ready(function() {
    $('a[rel=external]').click(function(){
        window.open(this.href);
        return false;
    });
    $('a[rel=external-new-window]').click(function(){
        window.open(this.href, "myWindowName", "width=800, height=600");
        return false;
    });
});
	</script>