<style>
 .d-none {
    display: none !important;
}
.info_info{
	margin-bottom: 20px;
	margin-left: 20%;
}


</style>

<div class="container-fluid p-0">
		<h1 class="h3 mb-3">Add User</h1>
			<div class="row">
				<div class="col-md-10">
					<div class="card">
						<div class="card-body">
							<?php
							if($this->session->flashdata('details'))
							{
							  $det = $this->session->flashdata('details');	
							  echo '<div class=" alert alert-'.$det['type'].'" style="padding: 10px;">'.$det['msg'].'</div>';
							}
							?>
							<form method="post" action="add_new_user" role="form" enctype="multipart/form-data" >
							   <div class="form-row">
									<div class="form-group col-md-2">
										<label for="inputEmail4">Prefix</label>
										<select  name="prefix" class="form-control" id="inputEmail4" >
										   <option value =''>Select</option>
										   <option value ='Mr.'>Mr.</option>
										   <option value ='Mrs.'>Mrs.</option>
										   <option value ='Miss.'>Miss.</option>
										  
										</select>
									</div>
									<div class="form-group col-md-4">
										<label for="inputEmail4">Name</label>
										<input type="text" name="name" class="form-control" value="" id="inputEmail4" placeholder="Name" >
									</div>
									
								</div>
								
							<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Email</label>
										<input type="email" name="email" value="" class="form-control" placeholder="Enter Email" required> 
								    </div>
								
							</div>		

                            <div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Contact No.</label>
										<input type="text" name="contact" value="" class="form-control" placeholder="Enter Contact No." required> 
								    </div>
								
							</div>	

							<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Address.</label>
										<textarea  name="address" value="" class="form-control" placeholder="Enter Address." > </textarea>
								    </div>
								
							</div>			
								
							
							<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Company Name</label>
										<input type="text" name="company_name" value="" class="form-control" placeholder="Company Name" > 
								</div>
								
							</div>
							<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Designation</label>
										<input type="text" name="designation" value="" class="form-control" placeholder='designation' > 
								</div>
								
							</div>
                            							
							
								<div class="form-row">
									<!--<input type="hidden" name="old_image" value="<?=$cat->logo;?>"> -->
									<div class="form-group col-md-6">
										<!--<img src="<?php echo base_url($cat->logo); ?>" alt="logo" style="max-height: 100px;"><br>  -->
										<label for="inputAddress">Profile Image</label>
										<input type="file" class="form-control" id="inputAddress" name="image" placeholder="profile" >
									</div>
								</div>
								
								
								
								<button type="submit" name="submit" class="btn btn-primary">Submit</button>
								<a href="<?=base_url('admin/user');?>" class="btn btn-danger">Cancel</a>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		
