<style type="text/css">.linkcolor{text-decoration: none !important; color: #495057;}.linkcolor:hover{text-decoration: none !important;}</style>
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.3/dist/Chart.min.js"></script>
        <main class="main">
        <?php
        error_reporting(0);
            $new_array = array_combine(array_column($vendor_monthly_graph,'months'),array_column($vendor_monthly_graph,'total_vendor'));
            $new_month = array(0,0,0,0,0,0,0,0,0,0,0,0,0);
            $month = array('','JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC');
            $new_diff = array_diff_key($new_month,$new_array);
            $arr = array();
            foreach ($new_array as $key => $value) {
                 foreach ($month as $key1 => $value1) {
                     if($key==$key1)
                     {
                        $arr[$value1]= $value;  
                        break;
                     }
                     else
                     {
                        $arr[$value1] = null;
                     }
                 }
            }
            array_shift($arr);
            $months = array_keys($arr);
            $total_vendor = array_values($arr);
            ?>
            <?php
            $new_array = array_combine(array_column($toorder_graph,'months'),array_column($toorder_graph,'total_order'));
            $new_month = array(0,0,0,0,0,0,0,0,0,0,0,0,0);
            $month = array('','JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC');
            $new_diff = array_diff_key($new_month,$new_array);
            $arr = array();
            foreach ($new_array as $key => $value) {
                 foreach ($month as $key1 => $value1) {
                     if($key==$key1)
                     {
                        $arr[$value1]= $value;  
                        break;
                     }
                     else
                     {
                        $arr[$value1] = null;
                     }
                 }
            }
            array_shift($arr);
            $months1 = array_keys($arr);
            $total_order = array_values($arr);
            ?>
            <?php
            $new_array = array_combine(array_column($deliver_order_graph,'months'),array_column($deliver_order_graph,'total_order'));
            $new_month = array(0,0,0,0,0,0,0,0,0,0,0,0,0);
            $month = array('','JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC');
            $new_diff = array_diff_key($new_month,$new_array);
            $arr = array();
            foreach ($new_array as $key => $value) {
                 foreach ($month as $key1 => $value1) {
                     if($key==$key1)
                     {
                        $arr[$value1]= $value;  
                        break;
                     }
                     else
                     {
                        $arr[$value1] = null;
                     }
                 }
            }
            array_shift($arr);
            $months3 = array_keys($arr);
            $total_order_deliver = array_values($arr);
            ?>
            <?php
            $new_array = array_combine(array_column($product_graph,'months'),array_column($product_graph,'total_order'));
            $new_month = array(0,0,0,0,0,0,0,0,0,0,0,0,0);
            $month = array('','JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC');
            $new_diff = array_diff_key($new_month,$new_array);
            $arr = array();
            foreach ($new_array as $key => $value) {
                 foreach ($month as $key1 => $value1) {
                     if($key==$key1)
                     {
                        $arr[$value1]= $value;  
                        break;
                     }
                     else
                     {
                        $arr[$value1] = null;
                     }
                 }
            }
            array_shift($arr);
            $months4 = array_keys($arr);
            $product_graph1 = array_values($arr);
            ?>
<!--<div class="container-fluid p-0">
	
	<div class="row mb-2 mb-xl-4">
		<div class="col-auto d-none d-sm-block">
			
		</div>
	</div>


   
    <div class="col-12">
        <h3>App Orders</h3><br/>
    </div>
	<div class="row">
		<div class="col-12 col-sm-3 col-xl d-flex">
			<div class="card flex-fill">
				<div class="card-body py-4">
					<div class="media">
						<div class="d-inline-block mt-2 mr-3">
							<i class="feather-lg text-primary" data-feather="shopping-cart"></i>
						</div>
						<div class="media-body">
							<h3 class="mb-2"><?php if(isset($totalsaletoday) && !empty($totalsaletoday)){ echo $totalsaletoday; }else{ echo '0'; }?></h3>
							<div class="mb-0">Total Sale Today </div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-12 col-sm-3 col-xl d-flex">
		<div class="card flex-fill">
			<div class="card-body py-4">
				<div class="media">
					<div class="d-inline-block mt-2 mr-3">
						<i class="feather-lg text-warning" data-feather="activity"></i>
					</div>
					<div class="media-body">
                        <a href="<?php echo base_url(); ?>admin/apporders?status=Recieved" class="linkcolor">
						<h3 class="mb-2"><?php if(isset($totalneworder) && !empty($totalneworder)){ echo $totalneworder; }else{ echo '0'; }?></h3>
						<div class="mb-0">New Orders</div>
                    </a>
					</div>
				</div>
			</div>
		</div>
		</div>
		
		<div class="col-12 col-sm-3 col-xl d-flex">
		<div class="card flex-fill">
			<div class="card-body py-4">
				<div class="media">
					<div class="d-inline-block mt-2 mr-3">
						<i class="feather-lg text-danger" data-feather="shopping-bag"></i>
					</div>
					<div class="media-body">
					   <a href="<?php echo base_url(); ?>admin/apporders?status=Assigned" class="linkcolor">
						<h3 class="mb-2"><?php if(isset($totalassignorders) && !empty($totalassignorders)){ echo $totalassignorders; }else{ echo '0'; }?></h3>
						<div class="mb-0">Assigned Orders</div></a>
					</div>
				</div>
			</div>
		</div>
		</div>
        <div class="col-12 col-sm-3 col-xl d-flex">
        <div class="card flex-fill">
            <div class="card-body py-4">
                <div class="media">
                    <div class="d-inline-block mt-2 mr-3">
                        <i class="feather-lg text-danger" data-feather="shopping-bag"></i>
                    </div>
                    <div class="media-body">
                      <a href="<?php echo base_url(); ?>admin/apporders?status=Holded" class="linkcolor">
                        <h3 class="mb-2"><?php if(isset($get_all_opendinghold) && !empty($get_all_opendinghold)){ echo $get_all_opendinghold; }else{ echo '0'; }?></h3>
                        <div class="mb-0">Holded Orders</div></a>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div class="col-12 col-sm-3 col-xl d-flex">
        <div class="card flex-fill">
            <div class="card-body py-4">
                <div class="media">
                    <div class="d-inline-block mt-2 mr-3">
                        <i class="feather-lg text-danger" data-feather="shopping-bag"></i>
                    </div>
                    <div class="media-body">
                        <a href="<?php echo base_url(); ?>admin/apporders?status=Cancelled" class="linkcolor">
                        <h3 class="mb-2"><?php if(isset($totalcancelorders) && !empty($totalcancelorders)){ echo $totalcancelorders; }else{ echo '0'; }?></h3>
                        <div class="mb-0"> Canceled Orders</div></a>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div class="col-12 col-sm-3 col-xl d-flex">
        <div class="card flex-fill">
            <div class="card-body py-4">
                <div class="media">
                    <div class="d-inline-block mt-2 mr-3">
                        <i class="feather-lg text-danger" data-feather="shopping-bag"></i>
                    </div>
                    <div class="media-body">
                        <a href="<?php echo base_url(); ?>admin/products" class="linkcolor">
                        <h3 class="mb-2"><?php if(isset($totproduct) && !empty($totproduct)){ echo $totproduct->total; }else{ echo '0'; }?></h3>
                        <div class="mb-0">Total Products</div></a>
                    </div>
                </div>
            </div>
        </div>
        </div>
	</div> -->
    <!--end app orders-->

    <!--website orders-->
    <!-- <div class="col-12">
        <h3>Website Orders</h3><br/>
    </div>
    <div class="row">
        <div class="col-12 col-sm-3 col-xl d-flex">
            <div class="card flex-fill">
                <div class="card-body py-4">
                    <div class="media">
                        <div class="d-inline-block mt-2 mr-3">
                            <i class="feather-lg text-primary" data-feather="shopping-cart"></i>
                        </div>
                        <div class="media-body">
                           <a href="javascript:viod()" class="linkcolor"> 
                            <h3 class="mb-2"><?php if(isset($totalsaletodayweb) && !empty($totalsaletodayweb)){ echo $totalsaletodayweb; }else{ echo '0'; }?></h3>
                            <div class="mb-0">Total Sale Today </div>
                      </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-3 col-xl d-flex">
        <div class="card flex-fill">
            <div class="card-body py-4">
                <div class="media">
                    <div class="d-inline-block mt-2 mr-3">
                        <i class="feather-lg text-warning" data-feather="activity"></i>
                    </div>
                    <div class="media-body">
                         <a href="<?php echo base_url(); ?>admin/orders?status=Pending" class="linkcolor">
                        <h3 class="mb-2"><?php if(isset($totalneworderweb) && !empty($totalneworderweb)){ echo $totalneworderweb; }else{ echo '0'; }?></h3>
                        <div class="mb-0">New Orders</div></a>
                    </div>
                </div>
            </div>
        </div>
        </div>
        
        <div class="col-12 col-sm-3 col-xl d-flex">
        <div class="card flex-fill">
            <div class="card-body py-4">
                <div class="media">
                    <div class="d-inline-block mt-2 mr-3">
                        <i class="feather-lg text-danger" data-feather="shopping-bag"></i>
                    </div>
                    <div class="media-body">
                       <a href="<?php echo base_url(); ?>admin/orders?status=Assigned" class="linkcolor">
                        <h3 class="mb-2"><?php if(isset($totalassignordersweb) && !empty($totalassignordersweb)){ echo $totalassignordersweb; }else{ echo '0'; }?></h3>
                        <div class="mb-0">Assigned Orders</div></a>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div class="col-12 col-sm-3 col-xl d-flex">
        <div class="card flex-fill">
            <div class="card-body py-4">
                <div class="media">
                    <div class="d-inline-block mt-2 mr-3">
                        <i class="feather-lg text-danger" data-feather="shopping-bag"></i>
                    </div>
                    <div class="media-body">
                       <a href="<?php echo base_url(); ?>admin/orders?status=Holded" class="linkcolor">
                        <h3 class="mb-2"><?php if(isset($get_all_opendingholdweb) && !empty($get_all_opendingholdweb)){ echo $get_all_opendingholdweb; }else{ echo '0'; }?></h3>
                        <div class="mb-0">Holded Orders</div></a>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div class="col-12 col-sm-3 col-xl d-flex">
        <div class="card flex-fill">
            <div class="card-body py-4">
                <div class="media">
                    <div class="d-inline-block mt-2 mr-3">
                        <i class="feather-lg text-danger" data-feather="shopping-bag"></i>
                    </div>
                    <div class="media-body">
                        <a href="<?php echo base_url(); ?>admin/orders?status=Cancelled" class="linkcolor">
                        <h3 class="mb-2"><?php if(isset($totalcancelordersweb) && !empty($totalcancelordersweb)){ echo $totalcancelordersweb; }else{ echo '0'; }?></h3>
                        <div class="mb-0"> Canceled Orders</div></a>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div class="col-12 col-sm-3 col-xl d-flex">
        <div class="card flex-fill">
            <div class="card-body py-4">
                <div class="media">
                    <div class="d-inline-block mt-2 mr-3">
                        <i class="feather-lg text-danger" data-feather="shopping-bag"></i>
                    </div>
                    <div class="media-body">
                         <a href="<?php echo base_url(); ?>admin/products" class="linkcolor">
                        <h3 class="mb-2"><?php if(isset($totproduct) && !empty($totproduct)){ echo $totproduct->total; }else{ echo '0'; }?></h3>
                        <div class="mb-0">Total Products</div></a>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>-->
    <!--end website orders-->
	
	
  <div class="container-fluid p-0">
	
	<div class="row mb-2 mb-xl-4">
		<div class="col-auto d-none d-sm-block">
			
		</div>
	</div>
<?php
//print_r($user_count);
?>
   
    <div class="col-12">
        <h3></h3><br/>
    </div>
	<div class="row">
		<div class="col-md-3 col-sm-12  d-flex">
			<div class="card flex-fill">
				<div class="card-body py-4">
					<div class="media">
						<div class="d-inline-block mt-2 mr-3">
							<i class="feather-lg text-primary" data-feather="user"></i>
						</div>
						<div class="media-body">
						    <a href="<?php echo base_url(); ?>admin/show_user" class="linkcolor">
							<h3 class="mb-2"><?php if(isset($user_count) && !empty($user_count)){ echo $user_count[0]->no_of_users; }else{ echo '0'; }?></h3>
						    	<div class="mb-0">Total Registered User </div>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-3 col-sm-12  d-flex">
		<div class="card flex-fill">
			<div class="card-body py-4">
				<div class="media">
					<div class="d-inline-block mt-2 mr-3">
						<i class="feather-lg text-warning" data-feather="activity"></i>
					</div>
					<div class="media-body">
                        <a href="<?php echo base_url(); ?>admin/view_qrcode" class="linkcolor">
						<h3 class="mb-2"><?php if(isset($no_opr_count) && !empty($no_opr_count)){ echo $no_opr_count[0]->no_of_op; }else{ echo '0'; }?></h3>
						<div class="mb-0"> Total No. Of Operators</div>
                    </a>
					</div>
				</div>
			</div>
		</div>
		</div>
		
		<div class="col-md-3 col-sm-12  d-flex">
		<div class="card flex-fill">
			<div class="card-body py-4">
				<div class="media">
					<div class="d-inline-block mt-2 mr-3">
						<i class="feather-lg text-danger" data-feather="shopping-bag"></i>
					</div>
					<div class="media-body">
					   <a href="<?php echo base_url(); ?>admin/" class="linkcolor">
						<h3 class="mb-2"><?php if(isset($qr_not_gen_count) && !empty($qr_not_gen_count)){ echo $qr_not_gen_count[0]->no_of_qr; }else{ echo '0'; }?></h3>
						<div class="mb-0">  </div></a>
					</div>
				</div>
			</div>
		</div>
		</div>
        <div class="col-md-3 col-sm-12  d-flex">
        <div class="card flex-fill">
            <div class="card-body py-4">
                <div class="media">
                    <div class="d-inline-block mt-2 mr-3">
                        <i class="feather-lg text-danger" data-feather="shopping-bag"></i>
                    </div>
                    <div class="media-body">
                      <a href="<?php echo base_url(); ?>admin/view_package" class="linkcolor">
                       <h3 class="mb-2"><?php if(isset($pkg_count) && !empty($pkg_count)){ echo $pkg_count[0]->pkg_count; }else{ echo '0'; }?></h3>
                        <div class="mb-0">  </div></a>
                    </div>
                </div>
            </div>
        </div>
        </div>
		 <div class="col-md-3 col-sm-12  d-flex">
        <div class="card flex-fill">
            <div class="card-body py-4">
                <div class="media">
                    <div class="d-inline-block mt-2 mr-3">
                        <i class="feather-lg text-danger" data-feather="shopping-bag"></i>
                    </div>
                    <div class="media-body">
                      <a href="<?php echo base_url(); ?>admin/view_cards" class="linkcolor">
                       <h3 class="mb-2"><?php if(isset($card_count) && !empty($card_count)){ echo $card_count[0]->card_counting; }else{ echo '0'; }?></h3>
                        <div class="mb-0"> </div></a>
                    </div>
                </div>
            </div>
        </div>
        </div>
     <!-- <div class="col-12 col-sm-3 col-xl d-flex">
        <div class="card flex-fill">
            <div class="card-body py-4">
                <div class="media">
                    <div class="d-inline-block mt-2 mr-3">
                        <i class="feather-lg text-danger" data-feather="shopping-bag"></i>
                    </div>
                    <div class="media-body">
                        <a href="<?php echo base_url(); ?>admin/apporders?status=Cancelled" class="linkcolor">
                        <h3 class="mb-2"><?php if(isset($pkg_count) && !empty($pkg_count)){ echo $pkg_count[0]->pkg_count; }else{ echo '0'; }?></h3>
                        <div class="mb-0">No.of Available Packages</div></a>
                    </div>
                </div>
            </div>
        </div>
        </div>
       <div class="col-12 col-sm-3 col-xl d-flex">
        <div class="card flex-fill">
            <div class="card-body py-4">
                <div class="media">
                    <div class="d-inline-block mt-2 mr-3">
                        <i class="feather-lg text-danger" data-feather="shopping-bag"></i>
                    </div>
                    <div class="media-body">
                        <a href="<?php echo base_url(); ?>admin/products" class="linkcolor">
                        <h3 class="mb-2"><?php if(isset($totproduct) && !empty($totproduct)){ echo $totproduct->total; }else{ echo '0'; }?></h3>
                        <div class="mb-0">Total Products</div></a>
                    </div>
                </div>
            </div>
        </div>-->
        </div>
	</div>
	
</div>
<script>
		$(function() {
			// Bar chart
			new Chart(document.getElementById("chartjs-dashboard-bar"), {
				type: "bar",
				data: {
					labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
					datasets: [{
						label: "Last year",
						backgroundColor: window.theme.primary,
						borderColor: window.theme.primary,
						hoverBackgroundColor: window.theme.primary,
						hoverBorderColor: window.theme.primary,
						data: [54, 67, 41, 55, 62, 45, 55, 73, 60, 76, 48, 79]
					}, {
						label: "This year",
						backgroundColor: "#E8EAED",
						borderColor: "#E8EAED",
						hoverBackgroundColor: "#E8EAED",
						hoverBorderColor: "#E8EAED",
						data: [69, 66, 24, 48, 52, 51, 44, 53, 62, 79, 51, 68]
					}]
				},
				options: {
					maintainAspectRatio: false,
					legend: {
						display: false
					},
					scales: {
						yAxes: [{
							gridLines: {
								display: false
							},
							stacked: false,
							ticks: {
								stepSize: 20
							}
						}],
						xAxes: [{
							barPercentage: .75,
							categoryPercentage: .5,
							stacked: false,
							gridLines: {
								color: "transparent"
							}
						}]
					}
				}
			});
		});
	</script>
	<script>
		$(function() {
			$("#datetimepicker-dashboard").datetimepicker({
				inline: true,
				sideBySide: false,
				format: "L"
			});
		});
	</script>
	<script>
		$(function() {
			// Line chart
			new Chart(document.getElementById("chartjs-dashboard-line"), {
				type: "line",
				data: {
					labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
					datasets: [{
						label: "Sales ($)",
						fill: true,
						backgroundColor: "transparent",
						borderColor: window.theme.primary,
						data: [2015, 1465, 1487, 1796, 1387, 2123, 2866, 2548, 3902, 4938, 3917, 4927]
					}, {
						label: "Orders",
						fill: true,
						backgroundColor: "transparent",
						borderColor: window.theme.tertiary,
						borderDash: [4, 4],
						data: [928, 734, 626, 893, 921, 1202, 1396, 1232, 1524, 2102, 1506, 1887]
					}]
				},
				options: {
					maintainAspectRatio: false,
					legend: {
						display: false
					},
					tooltips: {
						intersect: false
					},
					hover: {
						intersect: true
					},
					plugins: {
						filler: {
							propagate: false
						}
					},
					scales: {
						xAxes: [{
							reverse: true,
							gridLines: {
								color: "rgba(0,0,0,0.05)"
							}
						}],
						yAxes: [{
							ticks: {
								stepSize: 500
							},
							display: true,
							borderDash: [5, 5],
							gridLines: {
								color: "rgba(0,0,0,0)",
								fontColor: "#fff"
							}
						}]
					}
				}
			});
		});
	</script>
	<script>
		$(function() {
			// Pie chart
			new Chart(document.getElementById("chartjs-dashboard-pie"), {
				type: "pie",
				data: {
					labels: ["Direct", "Affiliate", "E-mail", "Other"],
					datasets: [{
						data: [2602, 1253, 541, 1465],
						backgroundColor: [
							window.theme.primary,
							window.theme.warning,
							window.theme.danger,
							"#E8EAED"
						],
						borderColor: "transparent"
					}]
				},
				options: {
					responsive: !window.MSInputMethodContext,
					maintainAspectRatio: false,
					legend: {
						display: false
					}
				}
			});
		});
	</script>
	<script>
		$(function() {
			$("#datatables-dashboard-projects").DataTable({
				pageLength: 6,
				lengthChange: false,
				bFilter: false,
				autoWidth: false
			});
		});
	</script>
	<script>

    // var month_list = ['JAN','FEB','MAR','APR','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
   var month_list=['1','2','3','4','5','6','7','8','9','10','11','12'];
  var month = '<?php echo json_encode($months) ?>';
  month  = JSON.parse(month);

  var vendor = '<?php echo json_encode($total_vendor) ?>';
   vendor = JSON.parse(vendor);
  //console.log(vendor);

var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: month,
        datasets: [{
            label: '# total User',
            data: vendor,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    precision: 0
                }
            }]
        },
        title:{
            display:true,
            text:"Monthly User",
            position:"bottom",
            fontStyle:"bold",
            lineHeight:1.2,
            fontSize:20
        }
    }
});

 var month_list=['1','2','3','4','5','6','7','8','9','10','11','12'];
  var months = '<?php echo json_encode($months1) ?>';
  months  = JSON.parse(months);

  var order = '<?php echo json_encode($total_order) ?>';
   order = JSON.parse(order);
  console.log(order);

var ctx = document.getElementById('myChart2').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: months,
        datasets: [{
            label: '# total Order',
            data: order,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    precision: 0
                }
            }]
        },
        title:{
            display:true,
            text:"Monthly Order",
            position:"bottom",
            fontStyle:"bold",
            lineHeight:1.2,
            fontSize:20
        }
    }
});
var month_list=['1','2','3','4','5','6','7','8','9','10','11','12'];
  var months = '<?php echo json_encode($months3) ?>';
  months  = JSON.parse(months);

  var order = '<?php echo json_encode($total_order_deliver) ?>';
   order = JSON.parse(order);
  console.log(order);

var ctx = document.getElementById('myChart3').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: months,
        datasets: [{
            label: '# total Deliver Order',
            data: order,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    precision: 0
                }
            }]
        },
        title:{
            display:true,
            text:"Monthly Order Deliver",
            position:"bottom",
            fontStyle:"bold",
            lineHeight:1.2,
            fontSize:20
        }
    }
});
var month_list=['1','2','3','4','5','6','7','8','9','10','11','12'];
  var months = '<?php echo json_encode($months4) ?>';
  months  = JSON.parse(months);

  var order = '<?php echo json_encode($product_graph1) ?>';
   order = JSON.parse(order);
  console.log(order);
var ctx = document.getElementById('myChart4').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: months,
        datasets: [{
            label: '# Added Products',
            data: order,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    precision: 0
                }
            }]
        },
        title:{
            display:true,
            text:"Monthly Add Product",
            position:"bottom",
            fontStyle:"bold",
            lineHeight:1.2,
            fontSize:20
        }
    }
});
</script>
