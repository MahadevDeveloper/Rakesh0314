<style>
 .d-none {
    display: none !important;
}
.info_info{
	margin-bottom: 20px;
	margin-left: 20%;
}
</style>

<div class="container-fluid p-0">
		<h1 class="h3 mb-3">Register New User</h1>
			<div class="row">
				<div class="col-md-10">
					<div class="card">
						<div class="card-body">
							<?php
							if($this->session->flashdata('details'))
							{
							  $det = $this->session->flashdata('details');	
							  echo '<div class=" alert alert-'.$det['type'].'" style="padding: 10px;">'.$det['msg'].'</div>';
							}
							?>
							<form id="forms" method="post" action="<?php echo base_url().'admin/reg_new_user';?>" role="form" enctype="multipart/form-data" >
							   <div class="form-row">
									
									<div class="form-group col-md-6">
										<label for="inputEmail4">Name</label>
										<input type="text" name="name" class="form-control" value="" id="inputEmail4" placeholder="Enter Name" required>
									</div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Father Name</label>
										<input type="text" name="fname" class="form-control" value="" id="inputEmail4" placeholder="Enter Father Name" required>
									</div>
								</div>
								
								<div class="form-row">
									
									<div class="form-group col-md-6">
										<label for="inputEmail4">Age</label>
										<input type="text" name="age" class="form-control" pattern="[0-9]{2}" value="" id="inputEmail4" placeholder="Enter Age" required>
									</div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Gender</label>
										<select name="gender" class="form-control" required>
										   <option value="Male">Male</option>
										   <option value="Female">Female</option>
										   <option value="Other">Other</option>
										</select>
									</div>
									
								</div>
								
								
							<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Email</label>
										<input type="email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" value="" class="form-control" placeholder="Enter Email" required> 
								    </div>
								
							</div>		

                            <div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Permanent Contact No.</label>
										<input type="text" name="per_contact" value="" class="form-control" pattern="[0-9]{10}" placeholder="Enter Contact No. (Do't use +91 or 0 before mobile no.)" required> 
								    </div>
								  
									<div class="form-group col-md-6">
									   <label for="inputEmail4"> Contact No.(Optional)</label>
									   <input type="text" name="contact" pattern="[0-9]{10}" value="" class="form-control" placeholder="Enter Contact No.(Do't use +91 or 0 before mobile no.)" > 
									</div>
								    
							</div>
							 	

							<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Address.</label>
										<textarea  name="address" value="" class="form-control" placeholder="Enter Address." required> </textarea>
								    </div>
								
							</div>			
								
						 <div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">City</label>
										<input type="text" name="city" value="" class="form-control" placeholder="Enter City ." required> 
								    </div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">State</label>
										<input type="text" name="state" value="" class="form-control" placeholder="Enter state ." required> 
								    </div>
								
							</div>
							
							 <div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Country</label>
									
										<select name="country" class="form-control" >
										   <option value="India">India</option>
										</select>
										
								    </div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Pincode</label>
										<input type="tel" pattern="[0-9]{6}" name="pincode" value="" class="form-control" placeholder="Enter Pincode ." required> 
								    </div>
								
							</div>
							
							<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Qualification</label>
										<input type="text" name="qualification" value="" class="form-control" placeholder="Enter Qualification ." required> 
								    </div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Occupation</label>
										<input type="text" name="occupation" value="" class="form-control" placeholder="Enter Occupation ." required> 
								    </div>
							</div>
							
								<div class="form-row">
									<!--<input type="hidden" name="old_image" value="<?=$cat->logo;?>"> -->
									<div class="form-group col-md-6">
										<!--<img src="<?php echo base_url($cat->logo); ?>" alt="logo" style="max-height: 100px;"><br>  -->
										<label for="inputAddress">Profile Image</label>
										<input type="file" class="form-control" id="inputAddress" name="image" placeholder="profile" required>
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Password</label>
										<input id="pass" type="text" name="password" value="" class="form-control" placeholder="Enter Password ." required> 
									</div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Confirm Password</label>
										<input id="cpass" type="text" name="cpassword" value="" class="form-control" placeholder="Enter Confirm Password ." required> 
									</div>
							    </div>
								
								<center>
								<button type="submit" onclick="check()"; class="btn btn-primary">Submit</button>
								<a href="<?=base_url('admin/show_user');?>" class="btn btn-danger">Cancel</a>
								</center>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<script>
		   function check(){
			  $pass = $("#pass").val();
			  $cpass= $("#cpass").val();
			   if($pass==$cpass){
				   $("#forms").submit();
			   }else{
				   alert("Password And Confirm Password Did Not Matched");
				   event.preventDefault();
			   }
		   }
		
		
		
		</script>
