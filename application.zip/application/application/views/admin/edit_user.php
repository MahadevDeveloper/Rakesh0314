<div class="container-fluid p-0">
	<h1 class="h3 mb-3">Edit User</h1>
		<div class="row">
			<div class="col-md-12">
				<div class="card"> 
					<div class="card-body">
						<?php
						if($this->session->flashdata('details'))
						{
							$det = $this->session->flashdata('details');	
							echo '<div class=" alert alert-'.$det['type'].'" style="padding: 10px;">'.$det['msg'].'</div>';
						}
						?>
						<form method="post" enctype="multipart/form-data">
						<div class="form-row">
							<div class="form-group col-md-6">
								<label for="inputEmail4">Name</label>
								<input type="text" class="form-control" name="user_name" value="<?=$user['name']?>" placeholder="Enter user name" required>
							</div>
							<div class="form-group col-md-6">
								<label for="inputEmail4">Email</label>
								<input type="text" value="<?=$user['email']?>" class="form-control" placeholder="Enter Email" name="user_email" required>
							</div>
						</div>
						<div class="form-row">
							<div class="form-group col-md-6">
								<label for="inputEmail4">Contact</label>
								<input type="text" value="<?=$user['contact']?>" class="form-control" name="user_contact" placeholder="Enter Mobile no." >
							</div>
							<div class="form-group col-md-6">
								<label for="inputEmail4">Password</label>
								<input type="text" value="<?=$user['password']?>" class="form-control" placeholder="Enter Password" name="password" required>
							</div>
						</div>
						
						
						
						
						<button type="submit" name="submit" class="btn btn-primary">Submit</button>
						
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript">
		$(function() {
			// Select2
			$(".select2").each(function() {
				$(this)
					.wrap("<div class=\"position-relative\"></div>")
					.select2({
						placeholder: "Select value",
						dropdownParent: $(this).parent()
					});
			})
		});
		
	</script>
