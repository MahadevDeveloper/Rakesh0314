


<style>
    body {
    margin: 0;
    font-family: Nunito,-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;
    font-size: .875rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    text-align: left;
    background-color: #e12335 !important;
}
</style>

<?php //print_r($all_user);?>
<div class="container-fluid p-0">
	<h1 class="h3 mb-3">All Game Page Description
</h1>
					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-body">
									<?php
									if($this->session->flashdata('details'))
									{
									  $det = $this->session->flashdata('details');	
									  echo '<div class="p-1 alert alert-'.$det['type'].'">'.$det['msg'].'</div>';
									}
									?>
									<table id="datatables-buttons" class="table table-striped" style="width:100%">
										<thead>
											<tr>
												<th>S.No</th>
												<th>Game Name</th>
												<th>Title</th>
												<th>Meta Key</th>
												<th>Description</th>
												<th>Type Chart</th>
											  
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php
											if(isset($view_game_page_data)){
											    $k=1;
											  //  print_r($all_user);exit; ?>
												<?php foreach($view_game_page_data as $all ){ ?>
											<tr>
											    <td><?=$k;?></td>
												<td><?php 
												$data = $this->db->get_where('add_game', array('id'=> $all->game_id))->row_array(); 
												if(!empty($data)){
												    echo $data['game_name'];
												} ?>
												
											</td>
												<td><?=$all->title;?></td>
												<td><?=$all->meta_desc;?></td>
												<td><?=$all->description;?></td>
												<td><?=$all->typechart;?></td>
											 
												<td>
												<a href="<?=base_url('admin/add_game_description/'.$all->id); ?>"><button class="btn btn-info">View/Edit</button></a>
												<a href="<?=base_url('admin/delete_game_page_data/'.$all->id); ?>"><button class="btn btn-danger">Delete</button></a>
												</td>
											</tr>
												<?php  $k++; } } ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>

			

	<script>
		$(function() {
			// Datatables with Buttons
			var datatablesButtons = $("#datatables-buttons").DataTable({
				responsive: true,
				lengthChange: !1,
				buttons: ["copy", "print"]
			});
			datatablesButtons.buttons().container().appendTo("#datatables-buttons_wrapper .col-md-6:eq(0)");
		});
		$(document).ready(function() {
    $('a[rel=external]').click(function(){
        window.open(this.href);
        return false;
    });
    $('a[rel=external-new-window]').click(function(){
        window.open(this.href, "myWindowName", "width=800, height=600");
        return false;
    });
});
	</script>