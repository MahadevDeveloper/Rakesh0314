<div class="container-fluid p-0">
    
    
    
		<h1 class="h3 mb-3">Edit Setting</h1> &nbsp;

			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-body">
							<?php
							if($this->session->flashdata('details'))
							{
							  $det = $this->session->flashdata('details');	
							  echo '<div class=" alert alert-'.$det['type'].'" style="padding: 10px;">'.$det['msg'].'</div>';
							}
							?>
							<form method="post" role="form" enctype="multipart/form-data" >
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Email</label>
										<input type="email" name="email" class="form-control" value="<?=$cat->email;?>" id="inputEmail4" placeholder="Category">
									</div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Facebook link</label>
										<input type="text" name="fb" class="form-control" value="<?=$cat->fb;?>" id="inputEmail4" placeholder="Category">
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Contact Number</label>
										<input type="text" name="contact" class="form-control" value="<?=$cat->contact_no;?>" id="inputEmail4" placeholder="Category">
									</div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Twitter link</label>
										<input type="text" name="twitter" class="form-control" value="<?=$cat->twitter;?>" id="inputEmail4" placeholder="Category">
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Whatsapp Number</label>
										<input type="text" name="whatsapp_no" class="form-control" value="<?=$cat->whatsapp_no;?>" id="inputEmail4" placeholder="Category">
									</div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Whatsapp link</label>
										<input type="text" name="whatsapp_link" class="form-control" value="<?=$cat->whatsapp_link;?>" id="inputEmail4" placeholder="Category">
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Address</label>
										<textarea type="text" name="address" class="form-control"  id="inputEmail4" placeholder="Address"><?=$cat->address;?></textarea>
									</div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Instagram link</label>
										<input type="text" name="instagram" class="form-control" value="<?=$cat->instagram;?>" id="inputEmail4" placeholder="Category">
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">State</label>
										<select class="select2 form-control" name="state" required>
											<option>Select State</option>
											<?php if(!empty($state)){
												foreach($state as $k){?>
													<option value="<?php echo $k->id?>" <?php if($cat->state == $k->id){ echo 'Selected'; }?>><?=$k->name?></option>
												<?php } } ?>
										</select>
									</div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Youtube link</label>
										<input type="text" name="youtube" class="form-control" value="<?=$cat->youtube;?>" id="inputEmail4" placeholder="Category">
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">City</label>
										<!--<select class="select2 form-control" name="city" required>
											<option>Select City</option>
											<?php //if(!empty($state)){
												//foreach($city as $k){?>
													<option value="<?php //echo $k->id?>" <?php// if($cat->city == $k->id){ echo 'Selected'; }?>><?php //echo $k->name?></option>
												<?php // } } ?>
										</select>-->
										<input type="text" class="form-control" value='<?php echo $cat->city;?>' name="city" required >
									</div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Google link</label>
										<input type="text" name="google" class="form-control" value="<?=$cat->google;?>" id="inputEmail4" placeholder="Category">
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Pin Code</label>
										<input type="number" name="pincode" value="<?=$cat->pincode;?>" class="form-control" required> 
								</div>
								<div class="form-group col-md-6">
										<label for="inputEmail4">Linkedin link</label>
										<input type="text" name="linkedin" class="form-control" value="<?=$cat->linkedin;?>" id="inputEmail4" placeholder="Category">
									</div>
								
							</div>
							<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Company Name</label>
										<input type="text" name="company_name" value="<?=$cat->company_name ;?>" class="form-control" required> 
								</div>
								<div class="form-group col-md-6">
										<label for="inputEmail4">Pinterest link</label>
										<input type="text" name="pinterest" class="form-control" value="<?=$cat->pinterest;?>" id="inputEmail4" placeholder="Category">
									</div>
							</div>	
								<div class="form-row">
									<input type="hidden" name="old_image" value="<?=$cat->logo;?>">
									<div class="form-group col-md-6">
										<img src="<?php echo base_url($cat->logo); ?>" alt="logo" style="max-height: 100px;"><br>
										<label for="inputAddress">Logo Image</label>
										<input type="file" class="form-control" id="inputAddress" name="image" placeholder="1234 Main St">
									</div>
								</div>
								
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Privacy Policy Page</label>
										<input type="text" name="privacyPolicy" value="<?=$cat->privacyPolicy ;?>" class="form-control" required> 
								   </div>
								   <div class="form-group col-md-6">
										<label for="inputEmail4">Terms & Condition Page</label>
										<input type="text" name="termsCondition" class="form-control" value="<?=$cat->termsCondition;?>" id="inputEmail4" >
									</div>
							   </div>

								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Contact Us Page</label>
										<input type="text" name="contactUs_Page" value="<?=$cat->contactUs_Page ;?>" class="form-control" > 
								   </div>
								   <div class="form-group col-md-6">
										<label for="inputEmail4">About Us Page</label>
										<input type="text" name="aboutInfo" class="form-control" value="<?=$cat->aboutInfo;?>" id="inputEmail4" >
									</div>
							   </div>

								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Rate Us Page</label>
										<input type="text" name="rateus" value="<?=$cat->rateus ;?>" class="form-control" required> 
								   </div>
								   <div class="form-group col-md-6">
										<label for="inputEmail4">Card Package Page</label>
										<input type="text" name="fizzcardpackageurl" class="form-control" value="<?=$cat->fizzcardpackageurl;?>" id="inputEmail4">
									</div>
							   </div>
								
								
								<button type="submit" name="submit" class="btn btn-primary">Submit</button>
								<a href="<?=base_url('admin/setting');?>" class="btn btn-danger">Cancel</a>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
