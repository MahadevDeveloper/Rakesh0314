

<style>
    body {
    margin: 0;
    font-family: Nunito,-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;
    font-size: .875rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    text-align: left;
    background-color: #e12335 !important;
}
</style>

	<div class="container-fluid p-0">
		<h1 class="h3 mb-3">Update Password</h1>
			<div class="row">
				<div class="col-md-10">
					<div class="card">
						<div class="card-body">
							<?php
							if($this->session->flashdata('details'))
							{
							  $det = $this->session->flashdata('details');	
							  echo '<div class=" alert alert-'.$det['type'].'" style="padding: 10px;">'.$det['msg'].'</div>';
							}
							?>
							<form method="post"  action="<?php echo base_url('admin/update_pass');?>">
								
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Enter your existing password</label>
										<input type="password" name="password" class="form-control" id="inputEmail4" placeholder="" required>
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Enter your new password</label>
										<input type="password" name="new_password" class="form-control" id="inputEmail4" placeholder="" required>
									</div>
								</div>
								
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Confirm password</label>
										<input type="password" name="c_password" class="form-control" id="inputEmail4" placeholder="" required>
									</div>
								</div>
																						
								<button type="submit" class="btn btn-primary">Submit</button>
								<a href="<?=base_url('admin/');?>" class="btn btn-danger">Cancel</a>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

<script type="text/javascript">
// Unselect all

	$("#checkbox").click(function(){
    if($("#checkbox").is(':checked') ){
        ///$("#category > option").prop("selected","selected");
        $('#category').select2('destroy').find('option').prop('selected', 'selected').end().select2();
        $('#category').trigger('change');
    }else{
        //$("#category > option").removeAttr("selected");
        $('#category').select2('destroy').find('option').prop('selected', false).end().select2();
        $('#category').trigger('change');
     }
});
		


		
	</script>
	<script>

		$(function() {
			// Select2
			$(".select2").each(function() {
				$(this)
					.wrap("<div class=\"position-relative\"></div>")
					.select2({
						placeholder: "Select value",
						dropdownParent: $(this).parent()
					});
			})
			
		});
	</script>

