<div class="container-fluid p-0">
		<h1 class="h3 mb-3">Edit User</h1>
			<div class="row">
				<div class="col-md-10">
					<div class="card">
						<div class="card-body">
							<?php
							if($this->session->flashdata('details'))
							{
							  $det = $this->session->flashdata('details');	
							  echo '<div class=" alert alert-'.$det['type'].'" style="padding: 10px;">'.$det['msg'].'</div>';
							}
							?>
							<?php 
							  // echo"<pre>";print_r($s_user); exit;
							   
							
							?>
							<form method="post" action="<?php echo base_url('admin/update_new_user/'.$s_user->id)?>" role="form" enctype="multipart/form-data" >
						
							   <div class="form-row">
									
									<div class="form-group col-md-6">
										<label for="inputEmail4">Name</label>
										<input type="text" name="name" class="form-control" value="<?php echo $s_user->name;?>" id="inputEmail4" placeholder="Enter Name" required>
									</div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Father Name</label>
										<input type="text" name="fname" class="form-control" value="<?php echo $s_user->fname;?>" id="inputEmail4" placeholder="Enter Father Name" required>
									</div>
								</div>
								
								<div class="form-row">
									
									<div class="form-group col-md-6">
										<label for="inputEmail4">Age</label>
										<input type="text" name="age" class="form-control" pattern="[0-9]{2}" value="<?php echo $s_user->age;?>" id="inputEmail4" placeholder="Enter Age" required>
									</div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Gender</label>
										<select name="gender" class="form-control" required>
										   <option value="Male" <?php if($s_user->gender=="Male"){ echo "selected";}?>>Male</option>
										   <option value="Female"<?php if($s_user->gender=="Female"){ echo "selected";}?> >Female</option>
										   <option value="Other" <?php if($s_user->gender=="Other"){ echo "selected";}?> >Other</option>
										</select>
									</div>
									
								</div>
								
								
							<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Email</label>
										<input type="email"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" value="<?php echo $s_user->email;?>" class="form-control" placeholder="Enter Email" required disabled> 
								    </div>
								
							</div>		

                            <div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Permanent Contact No.</label>
										<input type="text" name="per_contact" value="<?php echo $s_user->perma_contact_no;?>" class="form-control" pattern="[0-9]{10}" placeholder="Enter Contact No. (Do't use +91 or 0 before mobile no.)" required> 
								    </div>
								  
									<div class="form-group col-md-6">
									   <label for="inputEmail4"> Contact No.(Optional)</label>
									   <input type="text" name="contact" pattern="[0-9]{10}" value="<?php echo $s_user->contact_no;?>" class="form-control" placeholder="Enter Contact No.(Do't use +91 or 0 before mobile no.)" required> 
									</div>
								    
							</div>
							 	

							<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Address.</label>
										<textarea  name="address"  class="form-control" placeholder="Enter Address." required><?php echo $s_user->address;?></textarea>
								    </div>
								
							</div>			
								
						 <div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">City</label>
										<input type="text" name="city" value="<?php echo $s_user->city;?>" class="form-control" placeholder="Enter City ." required> 
								    </div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">State</label>
										<input type="text" name="state" value="<?php echo $s_user->state;?>" class="form-control" placeholder="Enter state ." required> 
								    </div>
								
							</div>
							
							 <div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Country</label>
									
										<select name="country" class="form-control" >
										   <option value="India" <?php if($s_user->country=="India"){ echo "selected";} ?> >India</option>
										</select>
										
								    </div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Pincode</label>
										<input type="tel" pattern="[0-9]{6}" name="pincode" value="<?php echo $s_user->pincode;?>" class="form-control" placeholder="Enter Pincode ." required> 
								    </div>
								
							</div>
							
							<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Qualification</label>
										<input type="text" name="qualification" value="<?php echo $s_user->qualification;?>" class="form-control" placeholder="Enter Qualification ." required> 
								    </div>
									<div class="form-group col-md-6">
										<label for="inputEmail4">Occupation</label>
										<input type="text" name="occupation" value="<?php echo $s_user->occupation;?>" class="form-control" placeholder="Enter Occupation ." required> 
								    </div>
							</div>
							
								<div class="form-row">
									<input type="hidden" name="old_image" value="<?=$s_user->profile_img;?>"> 
									<div class="form-group col-md-6">
										<img src="<?php echo base_url($s_user->profile_img); ?>" alt="logo" style="max-height: 100px;"><br> 
										<label for="inputAddress">Profile Image</label>
										<input type="file" class="form-control" id="inputAddress" name="image" placeholder="profile" >
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Password</label>
										<input id="pass" type="text" name="password" value="<?php echo $s_user->password;?>" class="form-control" placeholder="Enter Password ." required> 
									</div>
									
							    </div>
								
								<center>
								<button type="submit"  class="btn btn-primary">Submit</button>
								<a href="<?=base_url('admin/show_user');?>" class="btn btn-danger">Cancel</a>
								</center>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
