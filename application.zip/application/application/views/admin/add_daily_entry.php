<style>
 .d-none {
    display: none !important;
}
.info_info{
	margin-bottom: 20px;
	margin-left: 20%;
}

body {
    margin: 0;
    font-family: Nunito,-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;
    font-size: .875rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    text-align: left;
    background-color: #e12335 !important;
}

</style>

<div class="container-fluid p-0">
		<h1 class="h3 mb-3">Add Daily Entry</h1> &nbsp; <a href="<?=base_url('admin/view_daily_entry');?>" class="btn btn-success" style="float: right;">View</a> <br><br>
			<div class="row"><br>
				<div class="col-md-12">
					<div class="card">
						<div class="card-body">
							<?php
							if($this->session->flashdata('details'))
							{
							  $det = $this->session->flashdata('details');	
							  echo '<div class=" alert alert-'.$det['type'].'" style="padding: 10px;">'.$det['msg'].'</div>';
							}
							?>
							
							<?php echo $this->session->flashdata('error'); ?>
							
							<form id="forms" method="post" action="" role="form" enctype="multipart/form-data" >
							   
							   <div class="form-row">
									
									<div class="form-group col-md-6">
									    
									<?php $data = $this->db->get('add_game')->result_array(); ?>
									
									
									<label for="inputEmail4">Select game</label>
									
									<select name="game_id" id="game_id" class="form-control">
									    
                                          <option value="">Select game</option>
                                          <?php foreach($data as $row){ ?>
                                          <option value="<?= $row['id'];?>" <?php if((isset($add_game_data['game_id'])) && $add_game_data['game_id'] == $row['id'])  { echo "selected"; } ?> > <?= $row['game_name'];?></option>
                                          <?php } ?>
                                        </select>
									
									</div>
								
								</div>
								
								<div class="form-row">
									
									<div class="form-group col-md-6">
										<label for="inputEmail4">Select Date</label>
										<input type="date" name="date" class="form-control" value="<?php if(isset($add_game_data['date'])) { echo $add_game_data['date'];} ?>" id="inputEmail4" placeholder="Select date" required>
									</div>
								
								</div>
									<div class="form-row">
											
											<div class="col-md-12">
												<sapn style="margin-right: 5px; float: left;">
													<label style=" width: 80px; text-align: center;"> <b>Open panel</b></label>
												</sapn>
												<sapn style="margin-right: 5px;  float: left;">
													<label style=" width: 80px; text-align: center;"><b>Jodi</b> </label>
												</sapn>
												<sapn style="margin-right: 5px;  float: left;">
													<label style=" width: 80px; text-align: center;"><b>Close panel</b></label>
												</sapn>
											</div>
											<div class="col-md-12">
												<sapn style="margin-right: 5px; float: left;">
													
													<input type="text" name="PateeOpen1" onkeyup ="OpnedataSet()" id="PateeOpen1" placeholder="XXX" style=" width: 100px; text-align: center;" >
												</sapn>
												<sapn style="margin-right: 5px;  float: left;">
													
													<input type="text" name="PateeOpen2" id="PateeOpen2" placeholder="XX" style=" width: 50px; text-align: center;" readonly>
												</sapn>
												<sapn style="margin-right: 5px;  float: left;">
													
													<input type="text" name="PateeOpen3" id="PateeOpen3"  onkeyup ="ClosedataSet()"  placeholder="XXX" style=" width: 100px; text-align: center;">
												</sapn>
												
											</div>
									</div>
									<div class="form-row">
								
									<div class="col-md-6">
									    
									        	<label for="inputEmail4">Number</label><br>
										
										<input type="tel" name="game_number" class="form-control" value="<?php if(isset($add_game_data['game_number'])) { echo $add_game_data['game_number'];} ?>" placeholder="Input Format 111-22-333"  required >
									
									
									</div>
								
								</div><br>
								
							
								<div class="form-row">
									
									<div class="form-group col-md-6">
							
								    <input type="radio" id="html" name="color" value="red" <?php if(isset($add_game_data['color']) && $add_game_data['color'] == 'red') { echo "checked";} ?>>
                                    <label for="html">Red</label><br>
                                    <input type="radio" id="css" name="color" value="black" checked <?php if(isset($add_game_data['color']) && $add_game_data['color'] == 'black') { echo "checked";} ?>>
                                    <label for="css">Black</label><br>
                                    
                                    	</div>
								
								</div>
								
								<br>
								<center>
								<button type="submit" class="btn btn-primary">Submit</button> &nbsp; <a href="<?=base_url('admin/update_daily_entry');?>" class="btn btn-danger">Close Entry</a>
							
								</center>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			function OpnedataSet(){
				// alert(":dfd");
				let OpenIS = $("#PateeOpen1").val();
				let OpenNumber = 0;
				let BB ={};
				let OldVAl = $("#PateeOpen2").val();
				
				if(OpenIS.length > 2){
					let OpenISArry = Array.from(String(OpenIS), Number);
					// console.log(OpenISArry);
					if(OpenIS.length > 3){
						$("#PateeOpen2").val('');
						$("#PateeOpen1").val('');
						alert("Invalid Number...!")
					}else{
					for(var i = 0; i <= OpenISArry.length; i++){
						
						OpenNumber  = OpenNumber + OpenISArry[i] ;
						
						if(i == 2){
							BB = OpenNumber;
						}
					}
					let BB1 = Array.from(String(BB), Number);
					let dataIs= '';
					if(BB1.length > 1){
						
						 dataIs =BB1[1];
						$("#PateeOpen2").val(dataIs);
						$("#PateeOpen3").focus();
					}else{
						
						 dataIs =BB1[0];
						$("#PateeOpen2").val(dataIs);
						$("#PateeOpen3").focus();
					}
				}

					
				}
			}

			function ClosedataSet(){
				// alert(":dfd");
				let OpenIS = $("#PateeOpen3").val();
				let OpenNumber = 0;
				let BB ={};
				
				if(OpenIS.length > 2){
					let OpenISArry = Array.from(String(OpenIS), Number);
					// console.log(OpenISArry);
					if(OpenIS.length > 3){
						alert("Invalid Number...!")
						let old = $("#PateeOpen2").val();
					   let old1 = Array.from(String(old), Number);
						$("#PateeOpen2").val(old1[0]);
						$("#PateeOpen3").val('');

					}else{
					for(var i = 0; i <= OpenISArry.length; i++){
						
						OpenNumber  = OpenNumber + OpenISArry[i] ;
						
						if(i == 2){
							BB = OpenNumber;
						}
					}
					let BB1 = Array.from(String(BB), Number);
					let old = $("#PateeOpen2").val();
					let old1 = Array.from(String(old), Number);
					let dataIs = 0;
					if(BB1.length > 1){
						
						 dataIs = old1[0]+''+BB1[1];
						$("#PateeOpen2").val(dataIs);
					}else{
						
						 dataIs = old1[0]+''+BB1[0];
						$("#PateeOpen2").val(dataIs);
					}
				}

					
				}
			}
		</script>
		
	
