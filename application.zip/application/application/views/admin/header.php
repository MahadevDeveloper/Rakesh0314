<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php if(isset($sett) && !empty($sett)){ echo $sett->company_name;}else{echo "Admin Panel";}?></title>
    <link rel="preconnect" href="http://fonts.gstatic.com/" crossorigin>
	<?php if(isset($sett) && !empty($sett)){?>
	<link rel="shortcut icon" href="<?php echo base_url($sett->logo)?>" type="image/png">
   <?php } ?>

	<!-- PICK ONE OF THE STYLES BELOW -->
	<link href="<?php echo base_url('assets/')?>css/classic.css" rel="stylesheet">
	<style type="text/css">
		.nav-item .indicatorapp {
    background: #47bac1;
    box-shadow: 0 0.1rem 0.2rem rgba(0,0,0,.05);
    border-radius: 50%;
    display: block;
    height: 18px;
    width: 18px;
    padding: 1px;
    position: absolute;
    top: 0;
    right: -8px;
    text-align: center;
    -webkit-transition: top .1s ease-out;
    transition: top .1s ease-out;
    font-size: .675rem;
    color: #fff;
}
*, :after, :b



	</style>
		<style> 
	 .flex-fill { background: linear-gradient(to right, rgba(13, 12, 12, 0.07), #e3a83e) !important;}
	</style>
	</head>

<body>
	<div class="wrapper">
		<nav id="sidebar" class="sidebar">
			<div class="sidebar-content ">
				<a class="sidebar-brand" href="#">
        <!--   <i class="align-middle" data-feather="box"></i> -->
          <span class="align-middle"><img src="<?php echo base_url($sett->logo); ?>" height="85"></span>
        </a>

				<ul class="sidebar-nav">0
					
					<li class="sidebar-item">
						<a href="<?php echo base_url('admin');?>" class="sidebar-link">
			              <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
			              
			            </a>
					</li>
				
					
					<li class="sidebar-item">
						<a href="#operator" data-toggle="collapse" class="sidebar-link collapsed">
			              <i class="align-middle" data-feather="plus"></i> <span class="align-middle">Add Game</span>
			            </a>
						<ul id="operator" class="sidebar-dropdown list-unstyled collapse " data-parent="#sidebar">
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/add_game')?>">Add</a></li>
					    	<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/view_all_game')?>">View</a></li>
						</ul>
					</li>
					<li class="sidebar-item">
						<a href="#opera" data-toggle="collapse" class="sidebar-link collapsed">
			              <i class="align-middle" data-feather="plus"></i> <span class="align-middle">Daily Entry</span>
			            </a>
						<ul id="opera" class="sidebar-dropdown list-unstyled collapse " data-parent="#sidebar">
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/add_daily_entry')?>">Daily Entry</a></li>
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/view_daily_entry')?>">View</a></li>
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/update_daily_entry')?>">Update Daily Entry</a></li>
					
						</ul>
					</li>
					
					<li class="sidebar-item">
						<a href="#operaa" data-toggle="collapse" class="sidebar-link collapsed">
			              <i class="align-middle" data-feather="plus"></i> <span class="align-middle">Game Description</span>
			            </a>
						<ul id="operaa" class="sidebar-dropdown list-unstyled collapse " data-parent="#sidebar">
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/add_game_description')?>">Add Game Description</a></li>
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/view_game_page_data')?>">View</a></li>
					
						</ul>
					</li>
					
					<li class="sidebar-item">
						<a href="#operas" data-toggle="collapse" class="sidebar-link collapsed">
			              <i class="align-middle" data-feather="plus"></i> <span class="align-middle">Add Description</span>
			            </a>
						<ul id="operas" class="sidebar-dropdown list-unstyled collapse " data-parent="#sidebar">
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/add_description')?>">Add Description</a></li>
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/view_description')?>">View</a></li>
					    </ul>
					</li>
					
					
						<li class="sidebar-item">
						<a href="#operaas" data-toggle="collapse" class="sidebar-link collapsed">
			              <i class="align-middle" data-feather="plus"></i> <span class="align-middle">Gussing</span>
			            </a>
						<ul id="operaas" class="sidebar-dropdown list-unstyled collapse " data-parent="#sidebar">
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/gussing')?>">Add Gussing</a></li>
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/view_gussing')?>">View</a></li>
					    </ul>
					</li>
					
					<li class="sidebar-item">
						<a href="#opereas" data-toggle="collapse" class="sidebar-link collapsed">
			              <i class="align-middle" data-feather="plus"></i> <span class="align-middle">Passing Record</span>
			            </a>
						<ul id="opereas" class="sidebar-dropdown list-unstyled collapse " data-parent="#sidebar">
						<!--	<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/add_passing_record')?>">Add Passing Record</a></li>-->
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/view_passing_record')?>">View</a></li>
					    </ul>
					</li>
					
					<li class="sidebar-item">
						<a href="#operees" data-toggle="collapse" class="sidebar-link collapsed">
			              <i class="align-middle" data-feather="plus"></i> <span class="align-middle">Leak Game</span>
			            </a>
						<ul id="operees" class="sidebar-dropdown list-unstyled collapse " data-parent="#sidebar">
						<!--	<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/add_leak_game')?>">Add Leak Game</a></li>-->
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/view_leak_game')?>">View</a></li>
					    </ul>
					</li>
					
					<li class="sidebar-item">
						<a href="#opereee" data-toggle="collapse" class="sidebar-link collapsed">
			              <i class="align-middle" data-feather="plus"></i> <span class="align-middle">MEMBERSHIP CHARGES</span>
			            </a>
						<ul id="opereee" class="sidebar-dropdown list-unstyled collapse " data-parent="#sidebar">
						<!--	<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/add_membership_charges')?>">Add MEMBERSHIP CHARGES</a></li>-->
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/view_membership_charges')?>">View</a></li>
					    </ul>
					</li>
					
					
						<li class="sidebar-item">
						<a href="#news" data-toggle="collapse" class="sidebar-link collapsed">
			              <i class="align-middle" data-feather="plus"></i> <span class="align-middle">NEWS</span>
			            </a>
						<ul id="news" class="sidebar-dropdown list-unstyled collapse " data-parent="#sidebar">
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/view_news')?>">View</a></li>
					    </ul>
					</li>
			
					
					
					<li class="sidebar-item">
						<a href="#setting" data-toggle="collapse" class="sidebar-link collapsed">
			              <i class="align-middle" data-feather="plus"></i> <span class="align-middle">Setting</span>
			            </a>
						
						<ul id="setting" class="sidebar-dropdown list-unstyled collapse " data-parent="#sidebar">
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/setting'); ?>">View Setting</a>
							</li>
							<li class="sidebar-item">
							<a class="sidebar-link" href="<?php echo base_url('admin/update_password'); ?>">Update Password</a></li>
						<!--	<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/add_page'); ?>">Add page</a></li>
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/show_pages'); ?>">View pages</a></li>-->
						</ul>
					</li>
					<!--<li class="sidebar-item">
						<a href="#bulk" data-toggle="collapse" class="sidebar-link collapsed">
			            <i class="align-middle" data-feather="users"></i> <span class="align-middle">Bulk SMS & Email</span>
			            </a>
						<ul id="bulk" class="sidebar-dropdown list-unstyled collapse " data-parent="#sidebar">
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/send_sms'); ?>">SMS</a></li>		
					<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/send_email_bulk'); ?>">Email</a></li>
						</ul>
					</li> -->
					<!--<li class="sidebar-item">
						<a href="#Notification" data-toggle="collapse" class="sidebar-link collapsed">
			              <i class="align-middle" data-feather="users"></i> <span class="align-middle">Live Notification</span>
			            </a>
						<ul id="Notification" class="sidebar-dropdown list-unstyled collapse " data-parent="#sidebar">
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/add_notification'); ?>">Add</a></li>
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/notification'); ?>">View</a></li>
						</ul>
					</li>-->
				<!--	<li class="sidebar-item">
						<a href="#User" data-toggle="collapse" class="sidebar-link collapsed">
			              <i class="align-middle" data-feather="users"></i> <span class="align-middle">Users</span>
			            </a>
						<ul id="User" class="sidebar-dropdown list-unstyled collapse " data-parent="#sidebar">
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/reg_user')?>">Add</a></li>
							
							<li class="sidebar-item"><a class="sidebar-link" href="<?php echo base_url('admin/show_user')?>">View</a></li>
						</ul>
					</li>-->
					
					

					<!-- <li class="sidebar-item">
						<a href="<?php echo base_url('admin/services')?>" class="sidebar-link">
			              <i class="align-middle" data-feather="check-square"></i> <span class="align-middle">Services</span>
			            </a>
					</li> -->
					<!--loclahost/flitch<li class="sidebar-item">
						<a href="<?php echo base_url('admin/CustomerQuery');?>" class="sidebar-link">
			             <i class="align-middle" data-feather="check-square"></i> <span class="align-middle">Customer Query</span>
			              
			            </a>
					</li>  -->
				</ul>

			

			</div>
		</nav>

		<div class="main">
			<nav class="navbar navbar-expand navbar-light bg-white">
				<a class="sidebar-toggle d-flex mr-2">
		          <i class="hamburger align-self-center"></i>
		        </a>

                	<div style="margin-left: 110px;">	
		
	<a href="<?php echo base_url();?>admin" >	<i class="fa fa-home fa-3x" aria-hidden="true"></i> </a>

    </div>
					    
			


				<div class="navbar-collapse collapse">
					<ul class="navbar-nav ml-auto">
					    
					    
					    		
			<!--<li class="nav-item dropdown">
							<a class="nav-icon dropdown-toggle" href="#" id="messagesDropdownapp" data-toggle="dropdown">
								<div class="position-relative">
									<span style="font-size:14px;">App Orders</span> <i class="align-middle" data-feather="bell"></i>
									<span class="indicatorapp">0</span>
								</div>
							</a>
							<div class="dropdown-menu dropdown-menu-lg dropdown-menu-right py-0" aria-labelledby="messagesDropdownapp">
								<div class="dropdown-menu-header">
									<div class="position-relative" id="ordercountapp">
										<span class="indicator12app">0</span> New Order
									</div>
								</div>
								<div class="list-group" id="ordpopupapp">
									
								</div>
								<div class="dropdown-menu-footer">
									<a href="<?=base_url('admin/apporders')?>" class="text-muted">Show all Orders</a>
								</div>
							</div>
						</li>  -->
					    <!--<li class="nav-item dropdown">
							<a class="nav-icon dropdown-toggle" href="#" id="messagesDropdown" data-toggle="dropdown">
								<div class="position-relative">
									<span style="font-size:14px;">Website Orders </span> <i class="align-middle" data-feather="bell"></i>
									<span class="indicator">0</span>
								</div>
							</a>
							<div class="dropdown-menu dropdown-menu-lg dropdown-menu-right py-0" aria-labelledby="messagesDropdown">
								<div class="dropdown-menu-header">
									<div class="position-relative" id="ordercount">
										<span class="indicator12">0</span> New Order
									</div>
								</div>
								<div class="list-group" id="ordpopup">
									
								</div>
								<div class="dropdown-menu-footer">
									<a href="<?=base_url('admin/orders')?>" class="text-muted">Show all Orders</a>
								</div>
							</div>
						</li>-->
						<li class="nav-item dropdown">
							<a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#" data-toggle="dropdown">
			                	<i class="align-middle" data-feather="settings"></i>
			              	</a>

							<a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-toggle="dropdown">
								<?php if(isset($sett) && !empty($sett)){?>
				                <img src="<?php echo base_url($sett->logo)?>" class="avatar img-fluid rounded-circle mr-1" alt="Chris Wood" /> <span class="text-dark"><?php echo $sett->company_name;?></span><?php } ?>
				              </a>
							<div class="dropdown-menu dropdown-menu-right">
								<!--<a class="dropdown-item" href="#"><i class="align-middle mr-1" data-feather="user"></i> Profile</a>
								<a class="dropdown-item" href="#"><i class="align-middle mr-1" data-feather="pie-chart"></i> Analytics</a>-->
								<a class="dropdown-item" href="<?php echo base_url('logout')?>">Sign out</a>
							</div>
						</li>
					</ul>
				</div>
			</nav>

			<main class="content">
				<script src="<?php echo base_url('assets/')?>js/app.js"></script>
				<script type='text/javascript'>
function orderpopup(){
	//alert(1);
	$.ajax({
          url:"<?php echo base_url('admin/check_order_popup') ?>",
          type:"post",
          dataType:"json",
          success:function(data)
          {
             console.log(data);
             //console.log(data['total_orders']);
            // alert(data);
            // $(".del_charge").html(data['del_amt']);
            // $(".cart_title").html(data['cart_title']);
            // $("#cart_data").html(data['cart_data']);
            // $("#count_data").html(data['count_data']);
            // $(".count_data").html(data['count_data']);
            // $("#total_pri").html(data['total']);
            // $(".total_pri").html(data['total']);
            // $('.total_old_price').html(data['total_old']);
             $('.indicator').html(data['total_orders']);
            $('.indicator12').html(data['total_orders']);
            $('#ordpopup').html(data['tot_orders']);
             $('.indicatorapp').html(data['total_ordersapp']);
            $('.indicator12app').html(data['total_ordersapp']);
            $('#ordpopupapp').html(data['tot_ordersapp']);
            // $('.disc_price').html(data['disc_price']);
            // $('.total_pri12').val(data['total']);
          }
        });
}
//setTimeout("orderpopup();",5000);
setInterval(function() {
    //alert("Message to alert every 5 seconds");
    orderpopup();
}, 10000);
orderpopup();
</script>