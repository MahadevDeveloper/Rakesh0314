


<style>
    body {
    margin: 0;
    font-family: Nunito,-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;
    font-size: .875rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    text-align: left;
    background-color: #e12335 !important;
}
</style>

<?php //print_r($sett);?>
<div class="container-fluid p-0">
	<h1 class="h3 mb-3">Setting</h1>
					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-body">
									<?php
									if($this->session->flashdata('details'))
									{
									  $det = $this->session->flashdata('details');	
									  echo '<div class="p-1 alert alert-'.$det['type'].'">'.$det['msg'].'</div>';
									}
									?>
									<table id="datatables-buttons" class="table table-striped" style="width:100%">
										<thead>
											<tr>
												<th>Email</th>
												<th>Contact No</th>
												<th>Image</th>
												<th>Address</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php
											if(isset($sett)){
											    //print_r($sett); ?>
											<tr>
												<td><?=$sett->email;?></td>
												<td><?=$sett->contact_no;?></td>
												<td><?php echo '<a href="'.base_url().'assets/img/web/logo/'.$sett->logo.'" rel="external-new-window" class="accessible-link">';?><?php echo '<img src="'.base_url().$sett->logo.'" alt="'.$sett->email.'" style="width:120px;height:70px;">'; ?></a></td>
												<td><?=ucfirst($sett->address)?></td>
												<td><a href="<?=base_url('admin/edit_setting/'.$sett->id); ?>"><button class="btn btn-info">View/Edit</button></a>
											</td>
											</tr>
										<?php } ?>
											
											
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>

			

	<script>
		$(function() {
			// Datatables with Buttons
			var datatablesButtons = $("#datatables-buttons").DataTable({
				responsive: true,
				lengthChange: !1,
				buttons: ["copy", "print"]
			});
			datatablesButtons.buttons().container().appendTo("#datatables-buttons_wrapper .col-md-6:eq(0)");
		});
		$(document).ready(function() {
    $('a[rel=external]').click(function(){
        window.open(this.href);
        return false;
    });
    $('a[rel=external-new-window]').click(function(){
        window.open(this.href, "myWindowName", "width=800, height=600");
        return false;
    });
});
	</script>