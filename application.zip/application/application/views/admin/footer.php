	</main>

		<?php $otp='1234';?>
		</div>
	</div>
</body>

	<script>
		   $(document).ready(function(){ 
		       
		         $('#game_id').change(function(){
		          var optionSelected =$(this).find('option:selected');
		          var id=optionSelected.val();
		          
		          
		          $.ajax({
		              url:"<?php echo base_url('admin/get_data_for_update');?>",
		              type:'Post',
		              data:{'id':id},
		              dataType:'JSON',
		              success:function(d){
		                  if(d.status==true){
		                      $('#bty').css('display','block');
		                      $('#gm_no').val(d.gm);
		                      
		                      if(d.rm=='red'){
		                          $('#color1').attr('checked',true);
		                      }
		                      
		                      if(d.rm=='black'){
		                           $('#color2').attr('checked',true);
		                      }
		                  }else{
		                      
		                     $('#bty').css('display','none'); 
		                      $('#gm_no').val('');
		                      $('#color1').attr('checked','false');
		                      $('#color2').attr('checked','false');
		                     alert('No Number is entered today for this game ');
		                  }
		              }
		          });
		          
		          
		          
		       });
		     
		   });
		
	</script>


<script>
    $(document).ready(function(){
        // Add minus icon for collapse element which is open by default
        $(".collapse.show").each(function(){
        	$(this).prev(".card-header").find(".fa").addClass("fa-minus").removeClass("fa-plus");
        });
        
        // Toggle plus minus icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function(){
        	$(this).prev(".card-header").find(".fa").removeClass("fa-plus").addClass("fa-minus");
        }).on('hide.bs.collapse', function(){
        	$(this).prev(".card-header").find(".fa").removeClass("fa-minus").addClass("fa-plus");
        });
    });
     $(document).off('click','.add_basket').on('click','.add_basket',function(){
     	
      var pid = $(this).attr('data-id');
      var cid = $(this).attr('data-city');
      var price = $(this).attr('data-price');
      var old_price = $(this).attr('data-old-price');
      var size = $(this).attr('data-size');
      var pname = $(this).attr('data-name');
      var unit = $(this).attr('data-unit');
      //var unit =$("#qty_input"+pid).val();

       
      var image = $(this).attr('data-image');
      var pslug = $(this).attr('data-slug');
      var qty = $(this).val();
      if(qty<=0 ){
      	qty = 1;
      }
      //alert(pslug);
      $.ajax({
        url:"<?php echo base_url('admin/add_cart_data') ?>",  
        type:"post",
        data:{pid:pid,cid:cid,price:price,size:size,pname:pname,qty:qty,image:image,unit:unit,slug:pslug,old_price:old_price},
        //dataType:"json",
        success:function(data)
          {
           alert("This product added");
            //alert(pslug);
            var carbtn = '<ul class="list-inline not__win_te"><li class="list-inline-item"><span class="minus_btn" data-id="'+pid+'" data-unit="'+unit+'">-</span></li><li class="list-inline-item"><input type="text" readonly="" value="'+qty+'" id="qty_input'+pid+''+unit+'" style="width:18px;border: none; " class="qty_input'+pid+''+unit+'" ></li><li class="list-inline-item"><span class="plus_btn" data-id="'+pid+'" data-unit="'+unit+'">+</span></li></ul>';
            $('#add_btncart'+pid+''+unit+''+size).html(carbtn);
            get_cart_details();
            location.reload();
          }
      });
    });
   // $(document).ready(function(){
   // $('#qty_input').prop('disabled', true);
    $(document).on('click','.plus_btn',function(){
    	var pro_id = $(this).attr('data-id');
    	var pro_unit = $(this).attr('data-unit');
    	//alert(pro_id);
    	$('#qty_input'+pro_id+''+pro_unit).val(parseInt($('#qty_input'+pro_id+''+pro_unit).val()) + 1 );
    	$('.qty_input'+pro_id+''+pro_unit).val(parseInt($('.qty_input'+pro_id+''+pro_unit).val()) + 1 );
    	var newqty =$('#qty_input'+pro_id+''+pro_unit).val();
    	//alert(newqty);
    	$.ajax({
                  url:"<?php echo base_url('admin/update_cart_qty') ?>",
                  type:"post",
                  data:{product_id:pro_id,qty:newqty,pro_unit:pro_unit},
                  dataType:"json",
                  success:function(data)
                  {
                    console.log(data);
                    get_cart_details1();
                    get_cart_details();
                    get_coupon_data();
                  }
                });
    });
        
        $(document).on('click','.minus_btn',function(){
    	var pro_id = $(this).attr('data-id');
    	var pro_unit = $(this).attr('data-unit');
    	//alert(pro_id);
    	$('#qty_input'+pro_id+''+pro_unit).val(parseInt($('#qty_input'+pro_id+''+pro_unit).val()) - 1 );
    	$('.qty_input'+pro_id+''+pro_unit).val(parseInt($('.qty_input'+pro_id+''+pro_unit).val()) - 1 );
    	   // });
    	if ($('#qty_input'+pro_id+''+pro_unit).val() == 1) {
			$('#qty_input'+pro_id+''+pro_unit).val(1);
		}
		var newqty =$('#qty_input'+pro_id+''+pro_unit).val();
    	//alert(newqty);
    	$.ajax({
                  url:"<?php echo base_url('admin/update_cart_qty') ?>",
                  type:"post",
                  data:{product_id:pro_id,qty:newqty,pro_unit:pro_unit},
                  dataType:"json",
                  success:function(data)
                  {
                    console.log(data.pid);
                    if(newqty == 0)
                    {

                      var carbtn = '<div class="add_cart_btn"><a class="add_basket" data-city="'+data.cid+'" data-id="'+data.pid+'" data-unit="'+data.unit+'" data-size="'+data.size+'" data-name="'+data.pname+'" data-price="'+data.price+'" data-slug="'+data.slug+'" data-image="'+data.image+'" >Add +</a></div>';
                      //var nerw= 'add_btncart'+data.pid+''+data.unit+''+data.size;
                      //alert(carbtn);
                  $('#add_btncart'+data.pid+''+data.unit+''+data.size).html(carbtn);
                    }
                    get_cart_details1();
                    get_cart_details();
                    get_coupon_data();
                  }
                });

    	    });
  $(document).off('click','.remove_cart_itemall').on('click','.remove_cart_itemall',function(){
           
            var ans=confirm('Are you sure you want to Remove this Item?');
            if(ans)
            {
                 $.ajax({
                  url:"<?php echo base_url('admin/remove_cart_itemall') ?>",
                  type:"post",
                  data:{product_id:"56"},
                  //dataType:"json",
                  success:function(data)
                  {
                     console.log(data);
                //     Swal.fire({
                //   position: 'top-end',
                //   icon: 'success',
                //   title: 'Item Removed from Cart...',
                //   showConfirmButton: false,
                //   timer: 1500
                // });
                  $(".cart_data12").html('');
                    get_cart_details1();
                    get_cart_details();
                  }
                });
            }
      });
        $(document).off('click','.remove_cart_item').on('click','.remove_cart_item',function(){
            var product_id = $(this).attr('data-id');
            var unit = $(this).attr('data-unit');
           	var ans=confirm('Are you sure you want to Remove this Item?');
            if(ans)
            {
                 $.ajax({
                  url:"<?php echo base_url('admin/remove_cart_item') ?>",
                  type:"post",
                  data:{product_id:product_id,unit:unit},
                  //dataType:"json",
                  success:function(data)
                  {
                     console.log(data);
                //     Swal.fire({
                //   position: 'top-end',
                //   icon: 'success',
                //   title: 'Item Removed from Cart...',
                //   showConfirmButton: false,
                //   timer: 1500
                // });
                    get_cart_details1();
                    get_cart_details();
                  }
                });
            }
      });
        </script>
<script>
$(document).ready(function(){

 $('#signup_form').on('submit', function(event){
  event.preventDefault();
  $.ajax({
   url:"<?php echo base_url('admin/validation') ?>",
   method:"POST",
   data:$(this).serialize(),
   dataType:"json",
   
   success:function(data)
   {
  

    if(data.error)
    {
     if(data.user_name_error != '')
     {
      $('#user_name_error').html(data.user_name_error);
     }
     else
     {
      $('#user_name_error').html('');
     }
     if(data.email_error != '')
     {
      $('#email_error').html(data.email_error);
     }
     else
     {
      $('#email_error').html('');
     }
     if(data.mobile_error != '')
     {
      $('#mobile_error').html(data.mobile_error);
     }
     else
     {
      $('#mibile_error').html('');
     }
     if(data.password_error != '')
     {
      $('#password_error').html(data.password_error);
     }
     else
     {
      $('#password_error').html('');
     }
    }
    if(data.success)
    {
     $('#success_message').html(data.success);
     $('#user_name_error').html('');
     $('#email_error').html('');
     $('#mobile_error').html('');
     $('#password_error').html('');
     $('#contact_form')[0].reset();
      
    }
   
   location.reload(true);
   }
  })
 });

});
$(document).ready(function(){

 $('#login_form').on('submit', function(event){
  event.preventDefault();
  $('#login_success_message').html('');
  $.ajax({
   url:"<?php echo base_url('admin/login_user') ?>",
   method:"POST",
   data:$(this).serialize(),
   dataType:"json",
   beforeSend:function(){
    $('#login_btn').attr('disabled', 'disabled');
   },
   success:function(data)
   {
   	console.log(data);
    if(data.error)
    {
     $('#login_success_message').html(data.msg);
    }
    if(data.success)
    {
     $('#login_success_message').html(data.success);
     location.reload(true);
     //$('#login_form')[0].reset();
    }
    $('#login_btn').attr('disabled', false);
   }
  })
 });

});
    </script>
    <script type="text/javascript">
  $(document).ready(function(){
  function get_cart_details1()
      {
       
        $.ajax({
          url:"<?php echo base_url('admin/manage_cart') ?>",
          type:"post",
          dataType:"json",
          success:function(data)
          {
          	
            //alert(data['cart_data']);
             //console.log(data);
           $(".cart_data12").html(data['cart_data']);
          // $(".cart_amount").html('£'+data['total_price']);
          }
        });
      }
 $('#delivery_addresss_form').on('submit', function(event){
  event.preventDefault();
  $.ajax({
   url:"<?=base_url('admin/add_delivery_address')?>",
   method:"POST",
   data:$(this).serialize(),
   dataType:"json",
   beforeSend:function(){
    //$('#add_adress_btn').attr('disabled', 'disabled');
   },
   success:function(data)
   {
    console.log(data);
    if(data.error)
    {
     if(data.fname_error != '')
     {
      $('#fname_error').html(data.fname_error);
     }
     else
     {
      $('#fname_error').html('');
     }
     if(data.lname_error != '')
     {
      $('#lname_error').html(data.lname_error);
     }
     else
     {
      $('#lname_error').html('');
     }
     if(data.c_number_error != '')
     {
      $('#contact_num_error').html(data.c_number_error);
     }
     else
     {
      $('#contact_num_error').html('');
     }
     if(data.city_error != '')
     {
      $('#city_error').html(data.city_error);
     }
     else
     {
      $('#city_error').html('');
     }
     if(data.pincode_error !='')
     {
      $('#pincode_error').html(data.pincode_error);
     }else{
      $('#pincode_error').html('');
     }
     if(data.house_number_error !='')
     {
      $('#house_num_error').html(data.house_number_error);
     }else{
      $('#house_num_error').html('');
     }
    }
    if(data.success)
    {
     $('#address_success').html(data.success);
     $('#fname_error').html('');
     $('#lname_error').html('');
     $('#contact_num_error').html('');
     $('#city_error').html('');
     $('#pincode_error').html('');
    // $('#signup_form').reset();
     location.reload().delay(2000);
    // $('#pincode_error')[0].reset();
     location.reload(true);
    }
    $('#add_adress_btn').attr('disabled', false);
   }
  })
 });

});
  function do_search()
{
 // alert(1);
 var search_term=$("#search_inp").val();
 console.log(search_term);
 $.ajax
 ({
  type:'POST',
  url:"<?=base_url('admin/get_search_all_product')?>",
  data:{search_term:search_term},
  success:function(data) 
  {
    
  $("#result_div").html(data);
  $('#result_div1').html(data);
   console.log(data);
  }
 });
 
 //return false;
}
 function do_search1()
{
 //alert(1);
 var search_term=$("#search_inp1").val();
 console.log(search_term);
 $.ajax
 ({
  type:'POST',
  url:"<?=base_url('admin/get_search_all_product')?>",
  data:{search_term:search_term},
  success:function(data) 
  {
    
//   $("#result_div").html(data);
  $('#result_div1').html(data);
   console.log(data);
  }
 });
 
 //return false;
}
</script>
<script type="text/javascript">
    function get_cart_details1()
      {
        // alert("ok");
        $.ajax({
          url:"<?php echo base_url('admin/manage_cart') ?>",
          type:"post",
          dataType:"json",
          success:function(data)
          {
          
            //alert(data['cart_data']);
             //console.log(data);
           $(".cart_data12").html(data['cart_data']);
          // $(".cart_amount").html('£'+data['total_price']);
          }
        });
      }
      get_cart_details1();
    
     function get_cart_details()
      {
        // alert("ok");
        $.ajax({
          url:"<?php echo base_url('admin/get_cart_details') ?>",
          type:"post",
          dataType:"json",
          success:function(data)
          {
             console.log(data);
            // alert(data);
            $(".del_charge").html(data['del_amt']);
             $(".product_price").html(data['product_price']);
            
            $(".cart_title").html(data['cart_title']);
            $("#cart_data").html(data['cart_data']);
            $("#cart_data1").html(data['cart_data']);
            $("#count_data").html(data['count_data']);
            $(".count_data").html(data['count_data']);
            $("#total_pri").html(data['total']);
            $(".total_pri").html(data['total']);
            $('.total_old_price').html(data['total_old']);
            $('.total_old_price').val(data['total_old']);
            $('.disc_price').html(data['disc_price']);
            $('.total_pri12').val(data['total']);
          }
        });
      }
      get_cart_details();
       function get_coupon_data()
 {
  var cop = 'check';
  $.ajax({
      url:"<?=base_url('admin/get_coupon_data')?>",
      method:"POST",
      data:{cop:cop},
      dataType:"json",
      success:function(data)
      {
       console.log(data);
       //alert(data.discount);
       $('#coupon_alert').html(data.msg);
       if(data.error)
       {
         $('#coupon_alert').html(data.msg);

       }
       if(data.success)
       {
        $('.disc_price').html(data.discount);
        $('.total_pri').html(data.tamt);

       }
   }
 });
 }
 get_coupon_data();
</script>
<script type="text/javascript">
  $(document).off('click','#otp_btn').on('click','#otp_btn',function(){
      var mobile = $('#mobile').val();
    //  var otp = "<?php #$otp ;?>";
       var otp = "1234";
      //alert(otp); 
      var n = mobile.length;
      if(n==10){
      $.ajax({
      url:"<?=base_url('admin/sent_otp')?>",
      method:"POST",
      data:{mobile:mobile,otp:otp},
      dataType:"json",
      success:function(data)
      {
       console.log(data);
       //alert(data.discount);
       if(data.error)
       {
         $('#mobile_error').html(data.msg);
          //$('.otp_group').addClass('d-none');
       }
       if(data.success)
       {
        $('.after_send').html(data.msg);
        //$('.total_pri').html(data.tamt);
        $('.sent_otp_num').removeClass('d-none');
        $('.otp_group').removeClass('d-none');
        $('.mobile_group').addClass('d-none');

       }
   }
 });
      }else{
          $('#mobile_error').html('Please enter valid 10 digit mobile');
      }
  });
  $(document).off('click','#change').on('click','#change',function(){
      $('#sign_up_btn').prop( "disabled", true );
    $('.sent_otp_num').addClass('d-none');
        $('.otp_group').addClass('d-none');
        $('.mobile_group').removeClass('d-none');
  });
  function myFunction()
  {
      var validotp = '<?=$otp?>';
      var str = $('#otp').val();
      var n = str.length;
      if(n==4){
          if(str == validotp)
            {
                $('#sign_up_btn').prop( "disabled", false );
                $('#otp_error').html('<span class="text-success">OTP verified.</span>');
            }else{
                $('#sign_up_btn').prop( "disabled", true );
                $('#otp_error').html('<span class="text-danger">OTP not verified. Please enter correct OTP</span>');
            }
          
      }else{
           $('#sign_up_btn').prop( "disabled", true );
      }
  }
  // Trigger

$(function () {
  
var $range = $(".js-range-slider"),
    $inputFrom = $(".js-input-from"),
    $inputTo = $(".js-input-to"),
    instance,
    min = 0,
    max = 1000,
    from = 0,
    to = 0;

$range.ionRangeSlider({
    type: "double",
    min: min,
    max: max,
    from: 0,
    to: 500,
  prefix: '₹. ',
    onStart: updateInputs,
    onChange: updateInputs,
    step: 10,
    prettify_enabled: true,
    prettify_separator: ".",
  values_separator: " - ",
  force_edges: true
  

});

instance = $range.data("ionRangeSlider");

function updateInputs (data) {
    from = data.from;
    to = data.to;
    
    $inputFrom.prop("value", from);
    $inputTo.prop("value", to); 
}

$inputFrom.on("input", function () {
    var val = $(this).prop("value");
    
    // validate
    if (val < min) {
        val = min;
    } else if (val > to) {
        val = to;
    }
    
    instance.update({
        from: val
    });
});

$inputTo.on("input", function () {
    var val = $(this).prop("value");
    
    // validate
    if (val < from) {
        val = from;
    } else if (val > max) {
        val = max;
    }
    
    instance.update({
        to: val
    });
});

    });
    // $("#forgotpass").on('submit', function(event){
    //         event.preventDefault();
    //     //var result = $(this).serialize();
    //     var email = $("#forgotemail").val();
    //   // alert(email);
    //     $.ajax({
    //           url:"<?php echo base_url('admin/forgot_pass') ?>",  
    //           type:"post",
    //           data:{email:email},
    //           dataType:"json",
    //           success:function(data)
    //           {
    //             console.log(data);
    //             $('#forgotcont').html(data.msg);
    //             //alert(data.msg);
    //             if(data.result ==false)
    //             {
    //           var message = data.msg;
               
    //             type='error';
    //             show_toast(message,type);
    //             $("#forgat_pass").modal("hide");
    //             //$("#change_pass_modal").modal('hide');
    //             }
    //             else if(data.result ==true)
    //             {
    //             var message = data.msg;
                
    //             type='success';
    //             //$("#change_pass_modal").modal('hide');
    //              show_toast(message,type);
    //              $("#forgat_pass").modal("hide");
    //              // setTimeout(function(){
    //              //    location.reload();
    //              // },5000);
    //             // $('#reset_btn').trigger('click');
    //             // pagination();
    //             }
    //           },
    //           error: function(xhr){
    //             console.log(xhr.status + " " + xhr.statusText);
    //           }
    //      });
    
    
    // }); 
       
</script>
<script>
      function onSignIn(googleUser) {
          var cou = 0;
        // Useful data for your client-side scripts:
        var profile = googleUser.getBasicProfile();
        console.log("ID: " + profile.getId()); // Don't send this directly to your server!
        console.log('Full Name: ' + profile.getName());
        console.log('Given Name: ' + profile.getGivenName());
        console.log('Family Name: ' + profile.getFamilyName());
        console.log("Image URL: " + profile.getImageUrl());
        console.log("Email: " + profile.getEmail());

        // The ID token you need to pass to your backend:
        var id_token = googleUser.getAuthResponse().id_token;
        console.log("ID Token: " + id_token);
        var gid=profile.getId();
        var fullname = profile.getName();
        var email = profile.getEmail();
        var image = profile.getImageUrl();
        var role = 'User';
        var type = 'Google';
        console.log(email);
        
         $.ajax({
	              url:"<?php echo base_url('admin/google_login') ?>",  
	              type:"post",
	              data:{gid:gid,fullname:fullname,email:email,image:image,role:role,type:type },
	              dataType:"json",
	              success:function(data)
	              {
	                 console.log(data);
	                
    if(data.error)
    {
     $('#login_success_message').html(data.msg);
    }
    if(data.success)
    {
     $('#login_success_message').html(data.success);
     googlelogin();
    //  if(cou ==0)
    //  {
    //  location.reload(true);
    //  cou++;
     //}
     //$('#login_form')[0].reset();
    }
	              },
	              error: function(xhr){
	                console.log(xhr.status + " " + xhr.statusText);
	              }
      });
      }
      function googlelogin()
      {
          var gname = $('#googleuser').val();
          //alert(1);
          if(gname == null)
          {
             //alert(gname);
             location.reload(true);
          }else{
              //location.reload(true);
          }
      }
      function signOut() {
    var auth2 = gapi.auth2.getAuthInstance();
    auth2.signOut().then(function () {
      console.log('User signed out.');
      var logout='logout';
      $.ajax({
	              url:"<?php echo base_url('admin/logout') ?>",  
	              type:"post",
	              data:{logout:logout },
	             // dataType:"json",
	              success:function(data)
	              {
	                  console.log(data);
	                  location.reload(true);
	              }
	              
      });
      
    });
  }
  $(document).off('click','#fotp_btn').on('click','#fotp_btn',function(){
      
      var mobile = $('#fmobile').val();
      var otp = '<?=$otp?>';
      //alert(otp); 
      $.ajax({
      url:"<?=base_url('admin/sent_forget_otp')?>",
      method:"POST",
      data:{mobile:mobile,otp:otp},
      dataType:"json",
      success:function(data)
      {
       console.log(data);
       //alert(data.discount);
       if(data.error)
       {
         $('#mobile_error').html(data.msg);
          //$('.otp_group').addClass('d-none');
       }
       if(data.success)
       {
        $('.after_send1').html(data.msg);
        //$('.total_pri').html(data.tamt);
        $('.sent_otp_num1').removeClass('d-none');
        $('.otp_group1').removeClass('d-none');
        $('.mobile_group1').addClass('d-none');

       }
   }
 });
  });
  $(document).off('click','#fchange').on('click','#fchange',function(){
      $('#forgot_btn').prop( "disabled", true );
    $('.sent_otp_num1').addClass('d-none');
        $('.otp_group1').addClass('d-none');
        $('.mobile_group1').removeClass('d-none');
  });
  function myFunction1()
  {
      var validotp = '<?=$otp?>';
      var str = $('#fotp').val();
      var n = str.length;
      if(n==4){
          if(str == validotp)
            {
                $('#forgot_btn').prop( "disabled", false );
                $('#fotp_error').html('<span class="text-success">OTP verified.</span>');
            }else{
                $('#forgot_btn').prop( "disabled", true );
                $('#fotp_error').html('<span class="text-danger">OTP not verified. Please enter correct OTP</span>');
            }
          
      }else{
           $('#forgot_btn').prop( "disabled", true );
      }
  }
  
  $("#forgotpass").on('submit', function(event){
            event.preventDefault();
            $('#fcpassword_error').html(''); 
            var mobile = $('#fmobile').val();
             var pass = $('#fpassword').val();
              var cpass = $('#fcpassword').val();
        //var result = $(this).serialize();
        // var mobile = $('#fmobile').val();
        // var email = $("#forgotemail").val();
       // alert(email);
       if(pass == cpass){
        $.ajax({
              url:"<?php echo base_url('admin/create_forgot_pass') ?>",  
              type:"post",
              data:{email:mobile,pass:pass},
               dataType:"json",
              success:function(data)
              {
                console.log(data);
                $('#forgotcont').html(data.msg);
                //alert(data.msg);
                if(data.result ==false)
                {
               var message = data.msg;
               
                type='error';
                // show_toast(message,type);
                $("#forgat_pass").modal("hide");
                //$("#change_pass_modal").modal('hide');
                }
                else if(data.result ==true)
                {
                var message = data.msg;
                $('.after_send1').html(message);
                type='success';
                setTimeout(function(){
                     location.reload();
                  },2000);
                //$("#change_pass_modal").modal('hide');
                //  show_toast(message,type);
                 //$("#forgat_pass").modal("hide");
                 // setTimeout(function(){
                 //    location.reload();
                 // },5000);
                // $('#reset_btn').trigger('click');
                // pagination();
                }
              },
              error: function(xhr){
                console.log(xhr.status + " " + xhr.statusText);
              }
         });
       }else{
          $('#fcpassword_error').html('<span class="text-danger">Password and Confirm password not match.</span>'); 
       }
    
    
    }); 
    </script>

    
</html>