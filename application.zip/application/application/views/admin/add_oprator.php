	<div class="container-fluid p-0">
		<h1 class="h3 mb-3">Add User As Operator</h1>
		 <!--<a class="btn btn-success"href="<?php echo base_url('admin/get_card_user_details'); ?>" > Back </a> -->
			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-body">
							<?php
							if($this->session->flashdata('details'))
							{
							  $det = $this->session->flashdata('details');	
							  echo '<div class=" alert alert-'.$det['type'].'" style="padding: 10px;">'.$det['msg'].'</div>';
							}
							?>
							
							
							
							<table id="datatables-buttons" class="table table-striped table-responsive" style="width:100%">
						<thead>
							<tr>
								<th>S.No.</th>
								<th>Member Id</th>
								<th>User Name</th>
								<th>Father Name</th>
								<th>User Email</th>
								<th>Permanent Contact No.</th>
								<th>Age</th>
								<th>Gender</th>
								<th>Action</th>
								<th>Profile</th>
							</tr>
						</thead>
						<tbody>
							<?php
						  # echo"<pre>";print_r($user_and_card);exit;
							if(isset($s_data) && !empty($s_data)){
								$a=0;
							foreach ($s_data as $k) { ++$a; ?>
							<tr>
								<td><?=$a?></td>
								<td><?=$k->member_id ?></td>
								<td><?=$k->name?></td>
								<td><?=$k->fname?></td>
								<td><?=$k->email?></td>
								<td><?=$k->perma_contact_no?></td>
								<td><?=$k->age?></td>
								<td><?=$k->gender?></td>
								
								<td>
								<a class="btn btn-primary" href="<?=base_url('admin/add_as_operator/'.$k->member_id.'/'.$k->id)?>" >Add As Operator </a> 
								<td><img height="100px" width="100px" src="<?php echo base_url($k->profile_img);?>"></td>		
								 </td>
						
							
							</tr>
						<?php } } ?>
							
							
						</tbody>
					</table>
						
							
						</div>
					</div>
				</div>
				
				
			</div>
		</div>

<script type="text/javascript">



	$(function() {
			// Datatables with Buttons
			var datatablesButtons = $("#datatables-buttons").DataTable({
				responsive: true,
				//lengthChange: !1,
				buttons: ["copy", "print"]
			});
			datatablesButtons.buttons().container().appendTo("#datatables-buttons_wrapper .col-md-6:eq(0)");
		});
		$(document).ready(function() {
    $('a[rel=external]').click(function(){
        window.open(this.href);
        return false;
    });
    $('a[rel=external-new-window]').click(function(){
        window.open(this.href, "myWindowName", "width=800, height=600");
        return false;
    });
});



// Unselect all

	$("#checkbox").click(function(){
    if($("#checkbox").is(':checked') ){
        ///$("#category > option").prop("selected","selected");
        $('#category').select2('destroy').find('option').prop('selected', 'selected').end().select2();
        $('#category').trigger('change');
    }else{
        //$("#category > option").removeAttr("selected");
        $('#category').select2('destroy').find('option').prop('selected', false).end().select2();
        $('#category').trigger('change');
     }
});
		


		
	</script>
	<script>

		$(function() {
			// Select2
			$(".select2").each(function() {
				$(this)
					.wrap("<div class=\"position-relative\"></div>")
					.select2({
						placeholder: "Select value",
						dropdownParent: $(this).parent()
					});
			})
			
		});
	</script>

