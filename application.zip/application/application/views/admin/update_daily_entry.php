<style>
 .d-none {
    display: none !important;
}
.info_info{
	margin-bottom: 20px;
	margin-left: 20%;
}

body {
    margin: 0;
    font-family: Nunito,-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;
    font-size: .875rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    text-align: left;
    background-color: #e12335 !important;
}
.alert{
    color:red;
}

</style>

<div class="container-fluid p-0">
		<h1 class="h3 mb-3">Update Today's Daily Entry</h1> <a href="<?=base_url('admin/add_daily_entry');?>" class="btn btn-success">Add Daily Entry</a> &nbsp; <a href="<?=base_url('admin/view_daily_entry');?>" class="btn btn-success" style="float: right;">View</a> <br><br>
		
	
		
			<div class="row"><br>
				<div class="col-md-12">
					<div class="card">
						<div class="card-body">
						
							<?php if(!empty($this->session->flashdata('success'))){echo "<p class='alert'>".$this->session->flashdata('success')."</p>";} ?>
							<?php  if(!empty($this->session->flashdata('error'))){echo "<p class='alert'>". $this->session->flashdata('error')."</p>";} ?>
							
							
							
						
						
						
							<form id="forms" method="post" action="<?php echo base_url('admin/update_daily_entry_up');?>" role="form" enctype="multipart/form-data" >
							   
							   <div class="form-row">
									
									<div class="form-group col-md-6">
									    
									<?php $data = $this->db->get('add_game')->result_array(); ?>
									
									
									<label for="inputEmail4">Select game</label>
									
									<select name="game_id" id="game_id" class="form-control">
									    
                                          <option value="">Select game</option>
                                          <?php foreach($data as $row){ ?>
                                          <option value="<?= $row['id'];?>" <?php if((isset($add_game_data['game_id'])) && $add_game_data['game_id'] == $row['id'])  { echo "selected"; } ?> > <?= $row['game_name'];?></option>
                                          <?php } ?>
                                        </select>
									
									</div>
								
								</div>
								
								<div class="form-row">
									
									<div class="form-group col-md-6">
										<label for="inputEmail4">Select Date</label>
										<input type="text" name="date" class="form-control" value="<?php echo date('Y-m-d');?>" id="inputEmail4" placeholder="Select date" readonly required>
									</div>
								
								</div>
								
									<div class="form-row">
								
									<div class="col-md-6">
									    
									        	<label for="inputEmail4">Number</label><br>
										
										<input type="tel" id="gm_no" name="game_number" class="form-control" value="" placeholder="Input Format 111-22-333"  required >
									
									
									</div>
								
								</div>
								
									<div class="form-row">
									
									<div class="form-group col-md-6">
							
								    <input type="radio" id="color1" name="color" value="red">
                                    <label for="html">Red</label><br>
                                    <input type="radio" id="color2" name="color" value="black">
                                    <label for="css">Black</label><br>
                                    
                                    	</div>
								
								</div>
								
								<br>
								
							
							<!--	<div class="form-row">
									
									<div class="form-group col-md-6">
							
								    <input type="radio" id="html" name="color" value="red" <?php if(isset($add_game_data['color']) && $add_game_data['color'] == 'red') { echo "checked";} ?>>
                                    <label for="html">Red</label><br>
                                    <input type="radio" id="css" name="color" value="black" checked <?php if(isset($add_game_data['color']) && $add_game_data['color'] == 'black') { echo "checked";} ?>>
                                    <label for="css">Black</label><br>
                                    
                                    	</div>
								
								</div>-->
								
								<br>
								<center>
								<button id='bty' type="submit" class="btn btn-primary" style="display:none">Submit</button>
							 
								</center>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		
		
	
		
	
