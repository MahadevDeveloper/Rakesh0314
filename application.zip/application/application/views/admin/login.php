<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	 <?php if(isset($sett) && !empty($sett)){?>
	            <title>Sign In - <?php echo $sett->company_name ;?> </title>
    <?php } else{?>
    	  <title>Sign In - Admin Panel </title>
    	<?php } ?>

	<link rel="preconnect" href="http://fonts.gstatic.com/" crossorigin>
	<?php if(isset($sett) && !empty($sett)){?>
	<link rel="shortcut icon" href="<?php echo base_url($sett->logo);?>" type="image/png">
    <?php } ?>
	<!-- PICK ONE OF THE STYLES BELOW -->
	<link href="<?php echo base_url('assets/')?>css/classic.css" rel="stylesheet">
	</head>

<body>
	<main class="main d-flex justify-content-center w-100">
		<div class="container d-flex flex-column">
			<div class="row h-100">
				<div class="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
					<div class="d-table-cell align-middle">

						<div class="text-center mb-3 p-3">
							<?php if(isset($sett) && !empty($sett)){?>
							<img src="<?php echo base_url($sett->logo);?>" alt="Img" class="img-fluid" width="120" height="100" />
						<?php } ?>
						</div>
						<?php 
							if($this->session->flashdata('item'))
							{
								echo $this->session->flashdata('item');
							}

						?>
						<div class="card">
							<div class="card-body">
								<div class="m-sm-4">
									
									<?php 
										echo form_open('admin_login');
									?>
										<div class="form-group">
											<label>Email</label>
											<input class="form-control form-control-lg" type="text" name="email" placeholder="Enter your email or mobile number" />
										</div>
										<div class="form-group">
											<label>Password</label>
											<input class="form-control form-control-lg" type="password" name="password" placeholder="Enter your password" />
											<small>
            <!-- <a href="pages-reset-password.html">Forgot password?</a> -->
          </small>
										</div>
										<div>
											<div class="custom-control custom-checkbox align-items-center">
												<input type="checkbox" class="custom-control-input" value="remember-me" name="remember-me" checked>
												<label class="custom-control-label text-small">Remember me next time</label>
											</div>
										</div>
										<div class="text-center mt-3">
											<!-- <a href="dashboard-default.html" class="btn btn-lg btn-primary">Sign in</a> -->
											<button type="submit" class="btn btn-lg btn-primary">Sign in</button>
										</div>
									</form>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
	</main>

	<script src="<?php echo base_url('assets/')?>js/app.js"></script>

</body>

</html>