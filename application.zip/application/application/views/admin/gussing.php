<style>
 .d-none {
    display: none !important;
}
.info_info{
	margin-bottom: 20px;
	margin-left: 20%;
}

body {
    margin: 0;
    font-family: Nunito,-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;
    font-size: .875rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    text-align: left;
    background-color: #e12335 !important;
}

</style>

<div class="container-fluid p-0">
		<h1 class="h3 mb-3">Add Gussing</h1> &nbsp; <a href="<?=base_url('admin/view_gussing');?>" class="btn btn-success" style="float: right;">View</a> <br><br>
			<div class="row"><br>
				<div class="col-md-12">
					<div class="card">
						<div class="card-body">
							<?php
							if($this->session->flashdata('details'))
							{
							  $det = $this->session->flashdata('details');	
							  echo '<div class=" alert alert-'.$det['type'].'" style="padding: 10px;">'.$det['msg'].'</div>';
							}
							?>
							<form id="forms" method="post" action="" role="form" enctype="multipart/form-data" >
							   
							   <div class="form-row">
									
									<div class="form-group col-md-6">
									    
									<?php $data = $this->db->get('add_game')->result_array(); ?>
									
									
									<label for="inputEmail4">Select game</label>
									
									<select name="game_id" id="game_id" class="form-control">
									    
                                          <option value="">Select game</option>
                                          <?php foreach($data as $row){ ?>
                                          <option value="<?= $row['id'];?>" <?php if((isset($gussing['game_id'])) && $gussing['game_id'] == $row['id'])  { echo "selected"; } ?> > <?= $row['game_name'];?></option>
                                          <?php } ?>
                                        </select>
									
									</div>
								
								</div>
							
									<div class="form-row">
								
									<div class="col-md-6">
									    
									        	<label for="inputEmail4">Number</label><br>
										
									<input type="tel" name="game_number" class="form-control" value="<?php if(isset($gussing['game_number'])) { echo $gussing['game_number'];} ?>" placeholder="Input Number 1234"  required >
									
									
									</div>
								
								</div><br>
								
								
								<br>
								<center>
								<button type="submit" class="btn btn-primary">Submit</button>
							
								</center>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	
