    <script src="https://cdn.ckeditor.com/ckeditor5/30.0.0/balloon-block/ckeditor.js"></script>


<style>
 .d-none {
    display: none !important;
}
.info_info{
	margin-bottom: 20px;
	margin-left: 20%;
}

body {
    margin: 0;
    font-family: Nunito,-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;
    font-size: .875rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    text-align: left;
    background-color: #e12335 !important;
}

</style>

<div class="container-fluid p-0">
		<h1 class="h3 mb-3">Add News</h1> &nbsp; <a href="<?=base_url('admin/view_news');?>" class="btn btn-success" style="float: right;">View</a> <br><br>
			<div class="row"><br>
				<div class="col-md-12">
					<div class="card">
						<div class="card-body">
							<?php
							if($this->session->flashdata('details'))
							{
							  $det = $this->session->flashdata('details');	
							  echo '<div class=" alert alert-'.$det['type'].'" style="padding: 10px;">'.$det['msg'].'</div>';
							}
							?>
							<form id="forms" method="post" action="" role="form" enctype="multipart/form-data" >
							   
							
								
				<div class="form-row">
								
				<div class="col-md-6">
				
				<label for="inputEmail4">Description</label><br>
				
				<textarea cols="80" rows="10" id="editor" name="description"> <?php if(isset($news['description'])) { echo $news['description'];} ?> </textarea>
									
				</div>
								
				</div><br>
							
				<br>
								<center>
								<button type="submit" class="btn btn-primary">Submit</button>
							
								</center>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
  
    <script>tinymce.init({selector:'textarea'});</script>
