<?php //print_r($all_user);?>
<div class="container-fluid p-0">
	<h1 class="h3 mb-3">All Leak Game</h1>
					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-body">
									<?php
									if($this->session->flashdata('details'))
									{
									  $det = $this->session->flashdata('details');	
									  echo '<div class="p-1 alert alert-'.$det['type'].'">'.$det['msg'].'</div>';
									}
									?>
									<table id="datatables-buttons" class="table table-striped" style="width:100%">
										<thead>
											<tr>
												<th>Sr. No.</th>
												<th>Description</th>
											
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php
											if(isset($leak_game)){
											    $i = 1;
											  //  print_r($all_user);exit; ?>
												<?php foreach($leak_game as $all ){ ?>
											<tr>
												<td><?=$i++;?></td>
												<td><?=$all->description;?></td>
											
												<td><a href="<?=base_url('admin/add_leak_game/'.$all->id); ?>"><button class="btn btn-info">View/Edit</button></a>
												
											</td>
											</tr>
												<?php }} ?>
											
											
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>

			

	<script>
		$(function() {
			// Datatables with Buttons
			var datatablesButtons = $("#datatables-buttons").DataTable({
				responsive: true,
				lengthChange: !1,
				buttons: ["copy", "print"]
			});
			datatablesButtons.buttons().container().appendTo("#datatables-buttons_wrapper .col-md-6:eq(0)");
		});
		$(document).ready(function() {
    $('a[rel=external]').click(function(){
        window.open(this.href);
        return false;
    });
    $('a[rel=external-new-window]').click(function(){
        window.open(this.href, "myWindowName", "width=800, height=600");
        return false;
    });
});
	</script>