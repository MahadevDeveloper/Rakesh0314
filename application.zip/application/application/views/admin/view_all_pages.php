
<style>
    body {
    margin: 0;
    font-family: Nunito,-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;
    font-size: .875rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    text-align: left;
    background-color: #e12335 !important;
}
</style>


<?php //print_r($sett);?>
<div class="container-fluid p-0">
	<h1 class="h3 mb-3">All Pages</h1>
					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-body">
									<?php
									if($this->session->flashdata('details'))
									{
									  $det = $this->session->flashdata('details');	
									  echo '<div class="p-1 alert alert-'.$det['type'].'">'.$det['msg'].'</div>';
									}
									?>
									<table id="datatables-buttons" class="table table-striped" style="width:100%">
										<thead>
											<tr>
												<th>Title</th>
												<th>Page Name</th>
												<th>View Content</th>
												<th>Edit</th>
												<th>Delete</th>
											</tr>
										</thead>
										<tbody>
											<?php
											if(isset($page_all)){
											   // print_r($page_all);
											  foreach($page_all as $pages){
											   ?>
											<tr>
											
												<td><?=$pages->title;?></td>
												<td><?=$pages->title;?></td>
												<td>
												  <a href="<?=base_url('admin/view_single_page/'.$pages->id); ?>"><button class="btn btn-info">View</button></a>
												</td>
												
												<td><a href="<?=base_url('admin/edit_pages/'.$pages->id); ?>"><button class="btn btn-info">View/Edit</button></a>
											</td>
											<td><a  class="btn btn-danger" href="javascript:void(0)" onclick="del('<?php echo $pages->id;?>','<?php echo $pages->title;?>')">Delete</a>
											</td>
											</tr>
											<?php } }?>
											
											
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>
			
			
			
			
			
<div class="modal" id="myModalDel">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title" id='titles'>Delete</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
	      <p>Do you want to delete <span id="title"></span></p>
      </div>
       <!--<a id='aaa'href="">dss</a>-->
      <!-- Modal footer -->
      <div class="modal-footer">
      	<button type="button" class="btn btn-success" data-dismiss="modal">No</button>
        <a id="delbtn" href="" class="btn btn-danger" >Yes</a>
      </div>

    </div>
  </div>
</div>
			

	<script>
		$(function() {
			// Datatables with Buttons
			var datatablesButtons = $("#datatables-buttons").DataTable({
				responsive: true,
				lengthChange: !1,
				buttons: ["copy", "print"]
			});
			datatablesButtons.buttons().container().appendTo("#datatables-buttons_wrapper .col-md-6:eq(0)");
		});
		$(document).ready(function() {
    $('a[rel=external]').click(function(){
        window.open(this.href);
        return false;
    });
    $('a[rel=external-new-window]').click(function(){
        window.open(this.href, "myWindowName", "width=800, height=600");
        return false;
    });
});


	function del(id,title){
			
			   $('#title').html(title);
			   var url='<?php echo site_url("admin/del_page/");?>'+id;
			   // alert(url);
         $('#delbtn').attr('href',url);
         $("#myModalDel").modal('show');
		}


	</script>