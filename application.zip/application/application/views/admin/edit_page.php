<script src="//cdn.ckeditor.com/4.10.0/full-all/ckeditor.js"></script>
<div class="container-fluid p-0">
		<h1 class="h3 mb-3"><?php if(isset($edit_page)){echo $edit_page->title;}?> Page</h1>
			<div class="row">
				<div class="col-md-10">
					<div class="card">
						<div class="card-body">
							<?php
							if($this->session->flashdata('details'))
							{
							  $det = $this->session->flashdata('details');	
							  echo '<div class=" alert alert-'.$det['type'].'" style="padding: 10px;">'.$det['msg'].'</div>';
							}
							?>
							<!-- <form method="post" enctype="multipart/form-data" action="<?php echo base_url('admin/create_category');?>"> -->
								<?php echo form_open_multipart('admin/edit_page_db');?>
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="inputEmail4">Page title</label>
										<input type="text" name="title" class="form-control" id="inputEmail4" placeholder="Page Title" value="<?php if(isset($edit_page)){echo $edit_page->title;}?>" required>
										<input type="hidden" name='id' value="<?php if(isset($edit_page)){echo $edit_page->id;}?>">
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col-md-12">
										<label for="inputAddress">Page Content</label>
										<textarea rows="4" name="editor1" class="form-control" placeholder="page content" ><?php if(isset($edit_page)){echo $edit_page->content;}?></textarea>
									</div>
								</div>

								
								<button type="submit" class="btn btn-primary">Submit</button>
								<a href="<?=base_url('admin/show_pages');?>" class="btn btn-danger">Cancel</a>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

								






<script>
CKEDITOR.replace( 'editor1', {
toolbar: [
{ name: 'document', groups: [ 'mode', 'document', 'doctools' ], items: [ 'Source', '-', 'Save', 'NewPage', 'Preview', 'Print', '-', 'Templates' ] },
{ name: 'clipboard', groups: [ 'clipboard', 'undo' ], items: [ 'Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo' ] },
{ name: 'editing', groups: [ 'find', 'selection', 'spellchecker' ], items: [ 'Find', 'Replace', '-', 'SelectAll', '-', 'Scayt' ] },
{ name: 'forms', items: [ 'Form', 'Checkbox', 'Radio', 'TextField', 'Textarea', 'Select', 'Button', 'ImageButton', 'HiddenField' ] },
'/',
{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ], items: [ 'Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'RemoveFormat' ] },
{ name: 'paragraph', groups: [ 'list', 'indent', 'blocks', 'align', 'bidi' ], items: [ 'NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote', 'CreateDiv', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'BidiLtr', 'BidiRtl', 'Language' ] },
{ name: 'links', items: [ 'Link', 'Unlink', 'Anchor' ] },
{ name: 'insert', items: [ 'Image', 'Flash', 'Table', 'HorizontalRule', 'Smiley', 'SpecialChar', 'PageBreak', 'Iframe' ] },
'/',
{ name: 'styles', items: [ 'Styles', 'Format', 'Font', 'FontSize' ] },
{ name: 'colors', items: [ 'TextColor', 'BGColor' ] },
{ name: 'tools', items: [ 'Maximize', 'ShowBlocks' ] },
{ name: 'others', items: [ '-' ] },
]
});
</script>