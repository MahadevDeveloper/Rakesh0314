<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Main_Model extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
	  
		
	}
    function get_setting_details()
	{
		 $this->db->select('*');
		$this->db->from('setting');
		$this->db->limit(1);
		$q =$this->db->get();
		
		if($q->num_rows()>0)
		{
			return $q->row();
		}
	}
	function get_edit_setting_details($id)
	{
		$q = $this->db->get_where('setting',['id'=>$id]);
		if($q->num_rows()>0)
		{
			return $q->row();
		}
	}
    function get_all_state_india($id)
	{
		$q = $this->db->get_where('states',['country_id'=>$id]);
		if($q->num_rows() > 0)
		{
			return $q->result();
		}
	}
	function get_all_city_india($id)
	{
		$q = $this->db->get_where('cities',['state_id'=>$id]);
		if($q->num_rows() > 0)
		{
			return $q->result();
		}
	}
	function edit_setting($id)
	{
		$email = $this->input->post('email');
		$contact = $this->input->post('contact');
		$address = $this->input->post('address');
		$state = $this->input->post('state');
		$city = $this->input->post('city');
		$pincode = $this->input->post('pincode');
		
		$company_name = $this->input->post('company_name');
		$whatsapp_no = $this->input->post('whatsapp_no');
		$fb = $this->input->post('fb');
		$twitter = $this->input->post('twitter');
		$instagram = $this->input->post('instagram');
		$youtube = $this->input->post('youtube');
		$google = $this->input->post('google');
		$linkedin = $this->input->post('linkedin');
		$pinterest = $this->input->post('pinterest');
		$whatsapp_link = $this->input->post('whatsapp_link');
		
		$privacyPolicy = $this->input->post('privacyPolicy');
		$termsCondition = $this->input->post('termsCondition');
		$contactUs_Page = $this->input->post('contactUs_Page');
		$aboutInfo = $this->input->post('aboutInfo');
		$rateus = $this->input->post('rateus');
		$fizzcardpackageurl = $this->input->post('fizzcardpackageurl');
		
		//$slug = preg_replace('/[^a-z0-9]+/i', '-', trim(strtolower($cat_name)));
		// $time =  Date('Y-m-d h:i:s');
		if(!empty($_FILES['image']['name']))
		{
			$image = time().$_FILES['image']['name'];
			move_uploaded_file($_FILES['image']['tmp_name'],'./assets/img/web/logo/'.$image);
			
			$upload_img_name='/assets/img/web/logo/'.$image;
		}
		else
		{
			$upload_img_name = $this->input->post('old_image');
		}
		$q = $this->db->where('id',$id)->update('setting',['address'=>$address,'city'=>$city,'state'=>$state,'pincode'=>$pincode,'contact_no'=>$contact,'email'=>$email,'logo'=>$upload_img_name,'company_name'=>$company_name,'whatsapp_no'=>$whatsapp_no,'fb'=>$fb,'twitter'=>$twitter,'instagram'=>$instagram,'youtube'=>$youtube,'google'=>$google,'linkedin'=>$linkedin,'pinterest'=>$pinterest,'whatsapp_link'=>$whatsapp_link,'privacyPolicy'=>$privacyPolicy,'termsCondition'=>$termsCondition,'contactUs_Page'=>$contactUs_Page,'aboutInfo'=>$aboutInfo,'rateus'=>$rateus ,'fizzcardpackageurl'=>$fizzcardpackageurl]);
		//echo $this->db->last_query();exit;	 	
		if($this->db->affected_rows()>0)
		{
			$output = $this->session->set_flashdata('details',array('msg'=>'Setting has been Updated','type'=>'success'));
			return $output;
		}
		else
		{
			//return $this->db->last_query();
			$output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
		}
	}
  function get_site_details1()
	{
	    $this->db->select('s.*,c.name as city_name,st.name as state_name');
	    $this->db ->from('setting s');
    	$this->db->join('cities c', 'c.id=s.city', 'left'); 
    	$this->db->join('states st', 'st.id=s.state', 'left');
    	$this->db->limit('1');
    	$q = $this->db->get();
	    if($q->num_rows()>0)
	    {
	        return $q->row();
	    }else{
	        return null;
	    }
	}
	
	function add_page_to_db($dat){
		
		$title=$dat['title'];
		$res=$this->db->select('title')->from('pages')->where('title',$title)->get();
		if($res->num_rows()>0){
			$output = $this->session->set_flashdata('details',array('msg'=> $title.' Page already exists.If want to change edit or delete , ','type'=>'danger'));
		}else{
				
		$this->db->insert('pages',$dat);
		if($this->db->affected_rows()>0){
			$output = $this->session->set_flashdata('details',array('msg'=>'Page Added Successfully','type'=>'success'));
		}else{
			$output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
		}
		return $output;
		}
		
		
		
	}
	
	function get_all_pages()
	{
		$q = $this->db->select('*')
				->from('pages')
				->get();
				
		if($q->num_rows()>0)
		{
			return $q->result();
		}else{
			return null;
		}
	}
	function get_page($id){
		
		$q = $this->db->select('*')
				->from('pages')
				->where('id',$id)
				->get();
				
		if($q->num_rows()>0)
		{
			return $q->row();
		}else{
			return null;
		}
		
		
	}
	function edit_page_to_db($id,$dat){
	    $this->db->set($dat)->where('id',$id)->update('pages');
		
		if($this->db->affected_rows()>0){
			$output = $this->session->set_flashdata('details',array('msg'=>'Page Updated Successfully','type'=>'success'));
		}else{
			$output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
		}
		
	}
	function del_page_from_db($id){
		
		$this->db->where('id',$id)->delete('pages');
		if($this->db->affected_rows()>0){
			$output = $this->session->set_flashdata('details',array('msg'=>'Page Deleted Successfully','type'=>'success'));
		}else{
			$output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
		}
		
	}
	
	
/***********************Fizzdigital***********************/
	
	function add_new_users()
	{
		#print_r($this->input->post());exit;
			$email = $this->input->post('email');
			$contact = $this->input->post('contact');
		    $this->db->where('email',$email);
		    $this->db->or_where('contact',$contact);
		    $q = $this->db->get('app_users');
		#echo $this->db->last_query();exit;
		#print_r($q);exit;
		if($q->num_rows() > 0){
			return $output = $this->session->set_flashdata('details',array('msg'=>'User already registerd ','type'=>'danger'));
		}else{
		$email = $this->input->post('email');
		$contact = $this->input->post('contact');
		$address = $this->input->post('address');
		$name = $this->input->post('name');
		$prefix = $this->input->post('prefix');
		
		//$userid = "FIZZ".time().rand(99,9999);   /***generating unique fizz id for user****/
		
		$company_name = $this->input->post('company_name');
		$designation = $this->input->post('designation');
		
		
		$upload_img_name='';
		if(!empty($_FILES['image']['name']))
		{
			$image = str_replace(" ","-",time().$_FILES['image']['name']);
			move_uploaded_file($_FILES['image']['tmp_name'],'./assets/img/profile/'.$image);
			
			$upload_img_name='/assets/img/profile/'.$image;
		}
		
		 $data_ins=array('prefix' => $prefix,
		                 'name' => $name,
						 'email' => $email,

						 'contact' =>$contact,
						 'address' => $address,
						 'company_name' =>$company_name,
						 'designation' => $designation,
						 'img'      => $upload_img_name
						 
						 );
				// 'userid' => $userid,
		
		 $this->db->insert('app_users',$data_ins);
		//	echo $this->db->last_query();exit; 	
			
		if($this->db->affected_rows()>0)
		{
			$output = $this->session->set_flashdata('details',array('msg'=>'User Added Successfully','type'=>'success'));
			return $output;
		}
		else
		{
			//return $this->db->last_query();
			return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
		}
		
	  }
		
	}
	
	
	
	
	function update_qrcode_user($id,$qr_name){
		$q = $this->db->where('id',$id)->update('app_users',['qrcode'=>$qr_name]);
		
	 if($this->db->affected_rows()>0)
		{
			$output = $this->session->set_flashdata('details',array('msg'=>'QRCode generated successfully','type'=>'success'));
			return $output;
		}
		else
		{
			$output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
		}
		
		
	}
	
	
		
	  function counting_req_user(){
		  return $this->db->query("select count(id) as no_of_users from user_registration")->result();
		 // echo $this->db->last_query();exit;
			  
	  } 
	  function counting_no_operator(){
		 return $this->db->query("select count(id) as no_of_op from operator ")->result();
		 // echo $this->db->last_query();exit;
			  
	  } 
	  function counting_qr_not_gen(){
		return $this->db->query("select count(id) as no_of_qr from qrcode where status ='1'")->result();
		 // echo $this->db->last_query();exit;
			  
	  }
	  function counting_pkg(){
		  return $this->db->query("select count(name) as pkg_count from packages")->result();
		 // echo $this->db->last_query();exit;
			  
	  }
	  
	  function counting_card(){
		  return $this->db->query("select count(card_name) as card_counting from card_type")->result();
	  }
	  
	  function add_new_pkg(){
		  $name=trim($this->input->post('name'));
		  $price=$this->input->post('price');
		  $expiry=$this->input->post('expiry');
		  $description=$this->input->post('description');
		   
		  $res=$this->db->where('name',$name)->get('packages');
		  if($res->num_rows() > 0){
			  $output = $this->session->set_flashdata('details',array('msg'=>'Package Already Exists','type'=>'danger'));
		  }else{
			  
			  $slug = preg_replace('/[^a-z0-9]+/i', '-', trim(strtolower($name)));
			  
			 $upload_img_name='';
			  if(!empty($_FILES['image']['name']))
			   {
				$image = str_replace(" ","-",time().$_FILES['image']['name']);
				move_uploaded_file($_FILES['image']['tmp_name'],'./assets/img/product_img/'.$image);
				
				$upload_img_name='/assets/img/product_img/'.$image;
			    }
	  
			  $dat = array('name'=> $name,
						   'slug' => $slug,
						   'price' => $price,
						   'expiry' => $expiry,
						   'description' => $description,
						   'img'      => $upload_img_name
						);
			  
			   $this->db->insert('packages',$dat);
			   
			   if($this->db->affected_rows() > 0){
				    $output = $this->session->set_flashdata('details',array('msg'=>'Package Added Successfully','type'=>'success'));
			   }else{
				     $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured,Please try after some time','type'=>'danger')); 
			   }
			   
		  }
		 
	  }
	  
	  function view_pkg(){
			$q = $this->db->select('*')->from('packages')->get();
				
			if($q->num_rows()>0)
			{
				return $q->result();
			}else{
				return null;
			}
		  
	  }
	  
	  function update_pkg($id,$data){
		  $this->db->set('status',$data)->where('id',$id)->update('packages');
			   
			   if($this->db->affected_rows() > 0){
				   if($data=='1'){
				    $output = $this->session->set_flashdata('details',array('msg'=>'Package Activated Successfully','type'=>'success'));
				   }
				   if($data=='0'){
				    $output = $this->session->set_flashdata('details',array('msg'=>'Package Inactivated Successfully','type'=>'success'));
				   }
			   }else{
				     $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured,Please try after some time','type'=>'danger')); 
			   }
	  }
	  
	  function get_edit_pkg($id){
		  $res=$this->db->where('id',$id)->get('packages');
		  if($res->num_rows() > 0){
			 return $res->row();
		  }else{
			 return null;  
		  }
	  }
	  
	  function edit_pkg_data($id){
		  
		   $name=trim($this->input->post('name'));
		  $price=$this->input->post('price');
		  $expiry=$this->input->post('expiry');
		  $description=$this->input->post('description');
		  	  
			 $upload_img_name='';
			  if(!empty($_FILES['image']['name']))
			   {
				$image = str_replace(" ","-",time().$_FILES['image']['name']);
				move_uploaded_file($_FILES['image']['tmp_name'],'./assets/img/product_img/'.$image);
				
				$upload_img_name='/assets/img/product_img/'.$image;
				
				$old_img=$this->input->post('old_image');
				unlink(FCPATH.$old_img);
				
			    }
				else{
					$upload_img_name=$this->input->post('old_image');
				}
			  $slug = preg_replace('/[^a-z0-9]+/i', '-', trim(strtolower($name)));
	  
			  $dat = array('name'=> $name,
							'slug' =>$slug,
						   'price' => $price,
						   'expiry' => $expiry,
						   'description' => $description,
						   'img'      => $upload_img_name
						);
			  
			   $this->db->set($dat)->where('id',$id)->update('packages');
			   
			   if($this->db->affected_rows() > 0){
				    $output = $this->session->set_flashdata('details',array('msg'=>'Package Updated Successfully','type'=>'success'));
			   }else{
				     $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured,Please try after some time','type'=>'danger')); 
			   }
				 
	  }
	  
	  function delete_pkg_data($id){
		  $this->db->where('id',$id)->delete('packages');
		   
		   if($this->db->affected_rows() > 0){
				    $output = $this->session->set_flashdata('details',array('msg'=>'Package Deleted Successfully','type'=>'success'));
			   }else{
				     $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured,Please try after some time','type'=>'danger')); 
			   }
	  }
	  
	  function add_new_card(){
		  $name=trim($this->input->post('card_name'));
		  $placeholder=$this->input->post('placeholder');
		
		   
		  $res=$this->db->where('card_name',$name)->get('card_type');
		  if($res->num_rows() > 0){
			  $output = $this->session->set_flashdata('details',array('msg'=>'Card Already Exists','type'=>'danger'));
		  }else{
			 
		     $upload_icon=''; $upload_img_card='';
			  if(!empty($_FILES['card_icon']['name']))
			   {  
		   
		        
				    $extension = pathinfo($_FILES["card_icon"]["name"], PATHINFO_EXTENSION);

					if($extension=='png'){ 
					  
						$image_icon = str_replace(" ","-",time().$_FILES['card_icon']['name']);
						move_uploaded_file($_FILES['card_icon']['tmp_name'],'./assets/img/photos/'.$image_icon);
					   	$upload_icon='/assets/img/photos/'.$image_icon;	
			
					
					  if(!empty($_FILES['card_image']['name']))
					   {
						$image = str_replace(" ","-",time().$_FILES['card_image']['name']);
						move_uploaded_file($_FILES['card_image']['tmp_name'],'./assets/img/photos/'.$image);
						
						$upload_img_card='/assets/img/photos/'.$image;
						}
				
						
				
					  
				  $dat = array('card_name'=> $name,
							   'placeholder' => $placeholder,
							   'card_icon' => $upload_icon,
							   'card_image'      => $upload_img_card
							);
				  
				   $this->db->insert('card_type',$dat);
				   
				   if($this->db->affected_rows() > 0){
						$output = $this->session->set_flashdata('details',array('msg'=>'Card Added Successfully','type'=>'success'));
				   }else{
						 $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured,Please try after some time','type'=>'danger')); 
				   }
			   
			 }else{
				 $output = $this->session->set_flashdata('details',array('msg'=>'Please Upload Png file for icon ','type'=>'danger'));
			 }
		   }else{
			    $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured,Please try after some time','type'=>'danger')); 
		   }
			   
		  }
	  }
	  
	  function view_all_card(){
		  $res=$this->db->get('card_type');
		  if($res->num_rows() > 0){ 
			 return $res->result();
		  }else{
			 return null; 
		  }
	  }
	  function get_edit_card($id){
		 $res=$this-> db->where('id',$id)->get('card_type');
		
		 if($res->num_rows() > 0){
			 return $res->row();
		 }
		 else{
			  return null;
		 }
	  }
	  
	  function update_card_data($id){
		   
		  $name=trim($this->input->post('card_name'));
		  $placeholder=trim($this->input->post('placeholder'));
		
		  		 
		     $upload_icon=''; $upload_img_card='';
			  if(!empty($_FILES['card_icon']['name']))
			   {   
		            $extension = pathinfo($_FILES["card_icon"]["name"], PATHINFO_EXTENSION);

					if($extension=='png'){ 
					  
						$image_icon = str_replace(" ","-",time().$_FILES['card_icon']['name']);
						move_uploaded_file($_FILES['card_icon']['tmp_name'],'./assets/img/photos/'.$image_icon);
					   	$upload_icon='/assets/img/photos/'.$image_icon;	
						
						$olds=$this->input->post('old_icon');;
						unlink(FCPATH.$olds);
					}
					
			   }else{
				     	$upload_icon=$this->input->post('old_icon');
			   }
		   
					
					  if(!empty($_FILES['card_image']['name']))
					   {
						$image = str_replace(" ","-",time().$_FILES['card_image']['name']);
						move_uploaded_file($_FILES['card_image']['tmp_name'],'./assets/img/photos/'.$image);
						 
						$upload_img_card='/assets/img/photos/'.$image;
						$old=$this->input->post('old_image');;
						unlink(FCPATH.$old);
						
						}else{
							$upload_img_card=$this->input->post('old_image');
						}
					
					  
				  $dat = array('card_name'=> $name,
							   'placeholder' => $placeholder,
							   'card_icon' => $upload_icon,
							   'card_image'      => $upload_img_card
							);
				  
				   $this->db->set($dat)->where('id',$id)->update('card_type');
				   
				   if($this->db->affected_rows() > 0){
						$output = $this->session->set_flashdata('details',array('msg'=>'Card Added Successfully','type'=>'success'));
				   }else{
						 $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured,Please try after some time','type'=>'danger')); 
				   }
			
	  }
	  
	  function delete_card_data($id){
		  
		  $this->db->where('id',$id)->delete('card_type');
		  
		  if($this->db->affected_rows() >0)
		  {
			  $output = $this->session->set_flashdata('details',array('msg'=>'Card Deleted Successfully','type'=>'success'));
		  }
		  else{
			  $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured,Please try after some time','type'=>'danger')); 
		  }
		  
	  }
	  
  function add_new_users_new()
	{
		     
              //additional email 
			  $data_email_add=$this->input->post('email_type');
			  $js_email_add_on = '';
			  if(isset($data_email_add)){
			  $e_type=$this->input->post('email_type');
			  $email_add=$this->input->post('email_additional');
			  $arrs_email =  array_combine($e_type,$email_add);
		      $js_email_add_on = json_encode($arrs_email);
			  }
			  
			  //additional contact 
			  $data_contact_add=$this->input->post('contact_type');
			  $js_contact_add_on = '';
			  if(isset($data_contact_add)){
			  $c_type=$this->input->post('contact_type');
			  $contact_add=$this->input->post('contact_additional');
			  $arrs_contact =  array_combine($c_type,$contact_add);
		      $js_contact_add_on = json_encode($arrs_contact);
			  }
			  
			  //additional address 
			  $data_address_add=$this->input->post('address_type');
			  $js_address_add_on = '';
			  if(isset($data_address_add)){
			  $a_type=$this->input->post('address_type');
			  $address_add=$this->input->post('address_additional');
			  $arrs_address =  array_combine($a_type,$address_add);
		      $js_address_add_on = json_encode($arrs_address);
			  }
			  
			   //additional social 
			  $data_social_add=$this->input->post('social_type');
			  $js_social_add_on = '';
			  if(isset($data_social_add)){
			  $so_type=$this->input->post('social_type');
			  $social_add=$this->input->post('social_additional');
			  $arrs_social =  array_combine($so_type,$social_add);
		      $js_social_add_on = json_encode($arrs_social);
			  }  
			   
			 $bio = '';
			 $d_bio=$this->input->post('bio');
			 if(isset($d_bio)){
			  $bio=$d_bio;
			 }
			  $service = '';
			  $d_service=$this->input->post('service');
			 if(isset($d_service)){
			  $service=$d_service;
			 }
			 
			
			
			
			
			$email = $this->input->post('email');
			$contact = $this->input->post('contact');
		    $this->db->where('email',$email);
		    $this->db->or_where('contact',$contact);
		    $q = $this->db->get('app_users');
		#echo $this->db->last_query();exit;
		#print_r($q);exit;
		if($q->num_rows() > 0){
			return $output = $this->session->set_flashdata('details',array('msg'=>'User already registerd ','type'=>'danger'));
		}else{
		$email = $this->input->post('email');
		$contact = $this->input->post('contact');
		$address = $this->input->post('address');
		$name = $this->input->post('name');
		$prefix = $this->input->post('prefix');
		
		$userid = "FIZZ".time().rand(99,9999);   /***generating unique fizz id for user****/
		
		$company_name = $this->input->post('company_name');
		$designation = $this->input->post('designation');
		
		
		$upload_img_name='';
		if(!empty($_FILES['image']['name']))
		{
			$image = str_replace(" ","-",time().$_FILES['image']['name']);
			move_uploaded_file($_FILES['image']['tmp_name'],'./assets/img/profile/'.$image);
			
			$upload_img_name='/assets/img/profile/'.$image;
		}
		
		 $data_ins=array('prefix' => $prefix,
		                 'name' => $name,
						 'email' => $email,
						 'userid' => $userid,
						 'contact' =>$contact,
						 'address' => $address,
						 'company_name' =>$company_name,
						 'designation' => $designation,
						 'img'      => $upload_img_name,
						 'additional_emails' => $js_email_add_on,
						 'additional_contacts' => $js_contact_add_on,
						 'additional_addresses' => $js_address_add_on,
						 'additional_socials' => $js_social_add_on,
						 'service' => $service,
						 'bio' => $bio
						 );
	# echo"<pre>"; print_r($data_ins);	exit;					 
	
		 $this->db->insert('app_users',$data_ins);
		//	echo $this->db->last_query();exit; 	
			
		if($this->db->affected_rows()>0)
		{
			$output = $this->session->set_flashdata('details',array('msg'=>'User Added Successfully','type'=>'success'));
			return $output;
		}
		else
		{
			//return $this->db->last_query();
			return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
		}
		
	  }
		
	}
	
	
	  
	 function up_new_users_new($id)
	  {
		
		
		
		//additional email 
			  $data_email_add=$this->input->post('email_type');
			  $js_email_add_on = '';
			  if(isset($data_email_add)){
			  $e_type=$this->input->post('email_type');
			  $email_add=$this->input->post('email_additional');
			  $arrs_email =  array_combine($e_type,$email_add);
		      $js_email_add_on = json_encode($arrs_email);
			  }
			  
			  //additional contact 
			  $data_contact_add=$this->input->post('contact_type');
			  $js_contact_add_on = '';
			  if(isset($data_contact_add)){
			  $c_type=$this->input->post('contact_type');
			  $contact_add=$this->input->post('contact_additional');
			  $arrs_contact =  array_combine($c_type,$contact_add);
		      $js_contact_add_on = json_encode($arrs_contact);
			  }
			  
			  //additional address 
			  $data_address_add=$this->input->post('address_type');
			  $js_address_add_on = '';
			  if(isset($data_address_add)){
			  $a_type=$this->input->post('address_type');
			  $address_add=$this->input->post('address_additional');
			  $arrs_address =  array_combine($a_type,$address_add);
		      $js_address_add_on = json_encode($arrs_address);
			  }
			  
			   //additional social 
			  $data_social_add=$this->input->post('social_type');
			  $js_social_add_on = '';
			  if(isset($data_social_add)){
			  $so_type=$this->input->post('social_type');
			  $social_add=$this->input->post('social_additional');
			  $arrs_social =  array_combine($so_type,$social_add);
		      $js_social_add_on = json_encode($arrs_social);
			  }  
			   
			 $bio = '';
			 $d_bio=$this->input->post('bio');
			 if(isset($d_bio)){
			  $bio=$d_bio;
			 }
			  $service = '';
			  $d_service=$this->input->post('service');
			 if(isset($d_service)){
			  $service=$d_service;
			 }
		
				
		
		$email = $this->input->post('email');
		$contact = $this->input->post('contact');
		$address = $this->input->post('address');
		$name = $this->input->post('name');
		$prefix = $this->input->post('prefix');
		
		
		$company_name = $this->input->post('company_name');
		$designation = $this->input->post('designation');
		
		
		if(!empty($_FILES['image']['name']))
		{
			$image = str_replace(" ","-",time().$_FILES['image']['name']);
			move_uploaded_file($_FILES['image']['tmp_name'],'./assets/img/profile/'.$image);
			
			$upload_img_name='/assets/img/profile/'.$image;
			
			$old=$this->input->post('old_image');
			unlink(FCPATH.$old);
		}
		else
		{
			$upload_img_name = $this->input->post('old_image');
		}
		
		 $data_ins=array('prefix' => $prefix,
		                 'name' => $name,
						 'address' => $address,
						 'company_name' =>$company_name,
						 'designation' => $designation,
						 'img'      => $upload_img_name,
						 'additional_emails' => $js_email_add_on,
						 'additional_contacts'  => $js_contact_add_on,
						 'additional_addresses'  => $js_address_add_on,
						 'additional_socials' =>  $js_social_add_on,
						 'bio' => $bio ,
						 'service' =>  $service,
						 
						 );
	       # echo"<pre>";print_r($data_ins);//echo $id;exit;
		 
	    	$this->db->set($data_ins)->where('id',$id)->update('app_users');
			#echo $this->db->last_query();exit;
			
		if($this->db->affected_rows()>0)
		{
			$output = $this->session->set_flashdata('details',array('msg'=>'User Updated Successfully','type'=>'success'));
			return $output;
		}
		else
		{
			//return $this->db->last_query();
			return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
		}
		
	  } 
	
	function get_all_unasigned_qrcode(){
		  $tb=$this->db->where('status','0')->get('qrcode');
		if($tb->num_rows()>0){
			return $tb->result();
		}else
		{
			return null;
		}
	}
	
	function get_all_asigned_qrcode(){
		  $this->db->select("qr.id,qr.uid,qr.qrcode,u.name,u.email,u.contact");
		  $this->db->from('qrcode qr');
		  $this->db->join('app_users u','qr.user_id=u.id');
		  $this->db->where('status','1');
		  $tb=$this->db->get();
		if($tb->num_rows()>0){
			return $tb->result();
		}else
		{
			return null;
		}
	}
	
	
	
	
	function get_particular_qrcode_detail($id){
		 $tb=$this->db->where('id',$id)->get('qrcode');
		if($tb->num_rows()>0){
			return $tb->row();
		}else
		{
			return null;
		}
	}
	
	function get_user_id_detail($user_id){
		//$dt = $this->db->where('qrcode_id','is_null')->get('user_data')
		
		$sql = "SELECT u.id,u.email,u.name,u.contact,ct.id as c_id,ct.card_name,ud.id as user_data_id FROM `user_data` ud join app_users u on ud.`user_id`= u.`id` join card_type ct on ud.card_id = ct.`id` where user_id=$user_id and ud.`qrcode_id` is null ";
		
		$res=$this->db->query($sql);
		if($res->num_rows() > 0){
			return $res->result();
		}else{
			return null;
		}
		
	}
	function update_user_data_and_qrcode($id,$qr_id,$user_id){
		// update user_data
		$where=array('id' =>$id);
		$this->db->set('qrcode_id',$qr_id)->where($where)->update('user_data');
		
		$this->db->set(array('user_id'=>$user_id,'status' => 1))->where('uid',$qr_id)->update('qrcode');
		
		if($this->db->affected_rows() > 0)
		{
			$output = $this->session->set_flashdata('details',array('msg'=>'Card Assigned Successfully','type'=>'success'));
			return $output;
		}else{
			return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
	    }
		
		//update qr_code
	}
	
	function get_ready_card_user_detail(){
			
		$sql = "SELECT u.id,u.email,u.name,u.contact,ct.id as c_id,ct.card_name,ct.card_icon,ct.card_image,qr.id,qr.uid,qr.qrcode ,ud.share_with ,ud.status, ud.social_media_profile_name , ud.additional_websites , ud.additional_emails ,ud.additional_contacts ,ud.additional_addresses,ud.additional_socials,ud.service,ud.bio ,ud.bu_name,ud.bu_company_name,ud.bu_designation,ud.bu_image FROM `user_data` ud join app_users u on ud.`user_id`= u.`id` join card_type ct on ud.card_id = ct.`id` join qrcode qr on ud.qrcode_id = qr.uid where ud.`qrcode_id` is not Null ";
		
		$res=$this->db->query($sql);
		if($res->num_rows() > 0){
			return $res->result();
		}else{
			return null;
		}
	}
	
	function get_users_detail_for_card(){
		$res=$this->db->get('app_users');
		if($res->num_rows() > 0){
			return $res->result();
		}else{
			return null;
		}
	}
	
	function get_card_detail(){
	  $res= $this->db->get('card_type');
	  if($res->num_rows() > 0){
		 return $res->result();
	  }else{
			return null;  
	  }
	}
	
	function user_card_detail($id){
	  $res= $this->db->where('user_id',$id)->get('user_data');
	  if($res->num_rows() > 0){
		 return $res->result();
	  }else{
			return null;  
	  }
	}
	
	function insert_card_for_user(){
		       $userid=$this->uri->segment(3);
		   #  print_r($_REQUEST);exit;
			 $cardid = $this->input->post('card_id');
			 
			 
			 
			 //business personal infornmation
			   $bu_name=Null;
			   $bu_company_name=Null;
			   $bu_designation=Null;
			   $bu_image=Null;
			   
			   $data_bu_name= $this->input->post('bu_name');
			   if(isset($data_bu_name)){
				   $bu_name=$this->input->post('bu_name');
			   }
			   
			   $data_bu_company_name= $this->input->post('bu_company_name');
			   if(isset($data_bu_company_name)){
				   $bu_company_name=$this->input->post('bu_company_name');
			   }
			   
			   $data_bu_designation= $this->input->post('bu_designation');
			   if(isset($data_bu_designation)){
				   $bu_designation=$this->input->post('bu_designation');
			   }
			   
			   if(!empty($_FILES['bu_image']['name']))
			   {
			     $image = str_replace(" ","-",time().$_FILES['bu_image']['name']);
			     move_uploaded_file($_FILES['bu_image']['tmp_name'],'./assets/img/profile/'.$image);
			
			     $bu_image='/assets/img/profile/'.$image;
			
				}
			   
			 
			 
			  //additional Website 
			  $data_web_add=$this->input->post('web_type');
			  $js_web_add_on = Null;
			  if(isset($data_web_add)){
			  $we_type=$this->input->post('web_type');
			  $web_add=$this->input->post('web_additional');
			  $arrs_web =  array_combine($we_type,$web_add);
		      $js_web_add_on = json_encode($arrs_web);
			  } 
			 
			 //additional email 
			  $data_email_add=$this->input->post('email_type');
			  $js_email_add_on = Null;
			  if(isset($data_email_add)){
			  $e_type=$this->input->post('email_type');
			  $email_add=$this->input->post('email_additional');
			  $arrs_email =  array_combine($e_type,$email_add);
		      $js_email_add_on = json_encode($arrs_email);
			  }
			  
			  //additional contact 
			  $data_contact_add=$this->input->post('contact_type');
			  $js_contact_add_on = Null;
			  if(isset($data_contact_add)){
			  $c_type=$this->input->post('contact_type');
			  $contact_add=$this->input->post('contact_additional');
			  $arrs_contact =  array_combine($c_type,$contact_add);
		      $js_contact_add_on = json_encode($arrs_contact);
			  }
			  
			  //additional address 
			  $data_address_add=$this->input->post('address_type');
			  $js_address_add_on = Null;
			  if(isset($data_address_add)){
			  $a_type=$this->input->post('address_type');
			  $address_add=$this->input->post('address_additional');
			  $arrs_address =  array_combine($a_type,$address_add);
		      $js_address_add_on = json_encode($arrs_address);
			  }
			  
			   //additional social 
			  $data_social_add=$this->input->post('social_type');
			  $js_social_add_on = Null;
			  if(isset($data_social_add)){
			  $so_type=$this->input->post('social_type');
			  $social_add=$this->input->post('social_additional');
			  $arrs_social =  array_combine($so_type,$social_add);
		      $js_social_add_on = json_encode($arrs_social);
			  }  
			   
			 $bio = Null;
			 $d_bio=$this->input->post('bio');
			 if(isset($d_bio)){
			  $bio=$d_bio;
			 }
			  $service = Null;
			  $d_service=$this->input->post('service');
			 if(isset($d_service)){
			  $service=$d_service;
			 }
		    $social_media_profile_name=Null;
			$d_social=$this->input->post('social_media_profile_name');
			 if(isset($d_social)){
			    $social_media_profile_name=$d_social;
			 }	
		
		
		
		 $data_ins=array('user_id' => $userid,
		                 'card_id' => $cardid,
						 'social_media_profile_name' => $social_media_profile_name,
						  'bu_name ' => $bu_name,
						  'bu_company_name ' => $bu_company_name,
						  'bu_designation ' => $bu_designation,
						  'bu_image ' => $bu_image,
						 'additional_websites ' => $js_web_add_on,
						 'additional_emails' => $js_email_add_on,
						 'additional_contacts'  => $js_contact_add_on,
						 'additional_addresses'  => $js_address_add_on,
						 'additional_socials' =>  $js_social_add_on,
						 'bio' => $bio ,
						 'service' =>  $service
						 
						 );
	       # echo"<pre>";print_r($data_ins);//echo $id;exit;
		 
	    	$this->db->insert('user_data',$data_ins);
			#echo $this->db->last_query();exit;
			
		if($this->db->affected_rows()>0)
		{
			$output = $this->session->set_flashdata('details',array('msg'=>'User Card Added Successfully','type'=>'success'));
			return $output;
		}
		else
		{
			//return $this->db->last_query();
			return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
		}
	}
	
	
	function get_user_id_detail_for_card(){
		//$dt = $this->db->where('qrcode_id','is_null')->get('user_data')
		
		$sql = "SELECT DISTINCT (u.id),u.email,u.name,u.contact FROM `user_data` ud join app_users u on ud.`user_id`= u.`id` where ud.`qrcode_id` is null ";
		
		$res=$this->db->query($sql);
		if($res->num_rows() > 0){
			return $res->result();
		}else{
			return null;
		}
		
	}
	
	function check_pass(){
		 $pass= $this->input->post('password');
    	 $n_pass= $this->input->post('new_password');
	     $c_pass= $this->input->post('c_password');
		
		$email=$_SESSION['email'];
	
		if($n_pass==$c_pass){
		  
		  $res=$this->db->query("select password from users where email = '$email'");
		 
			if($res->num_rows() > 0){
				$result = $res->row();
				$password_hashing = password_hash($n_pass,PASSWORD_BCRYPT);
				   
				  if(password_verify($pass,$result->password)){ 
                     $this->db->set('password',$password_hashing)->where('email',$email)->update('users');
                   # echo $this->db->last_query();exit;
                      if($this->db->affected_rows() > 0){ 
						  return $output = $this->session->set_flashdata('details',array('msg'=>'Password Updated Successfully','type'=>'success'));	
					  }else{ 
						   return $output = $this->session->set_flashdata('details',array('msg'=>'Password Updated Unsuccessfull','type'=>'danger')); 
					  }					 
				   }
				   else{ 
						return $output = $this->session->set_flashdata('details',array('msg'=>'Existing password  does not matched ','type'=>'danger'));	
			     }
			}
			else{ 
				return $output = $this->session->set_flashdata('details',array('msg'=>'Wrong Existing password ','type'=>'danger'));	
			}
			
		  
		}else{ 
			return $output = $this->session->set_flashdata('details',array('msg'=>'New password and Confirm password does not matched ','type'=>'danger'));	
		}
	
	}
	
	function get_user_id_detail_of_all_card(){
		//$dt = $this->db->where('qrcode_id','is_null')->get('user_data')
		
		$sql = "SELECT DISTINCT (u.id),u.email,u.name,u.contact FROM `user_data` ud join app_users u on ud.`user_id`= u.`id`  ";
		
		$res=$this->db->query($sql);
		if($res->num_rows() > 0){
			return $res->result();
		}else{
			return null;
		}
		
	}
	
	
		function get_user_detail_of_user_data($user_id){
		//$dt = $this->db->where('qrcode_id','is_null')->get('user_data')
		
		$sql = "SELECT u.id,u.email,u.name,u.contact,ct.id as c_id,ct.card_name,ud.id as user_data_id ,ud.social_media_profile_name,ud.bu_company_name FROM `user_data` ud join app_users u on ud.`user_id`= u.`id` join card_type ct on ud.card_id = ct.`id` where ud.user_id=$user_id  ";
		
		$res=$this->db->query($sql);
		if($res->num_rows() > 0){
			return $res->result();
		}else{
			return null;
		}
		
	}
	
	function delete_user_card_data($id){
		$this->db->where('id',$id)->delete('user_data');
		if($this->db->affected_rows() > 0){
			return $output = $this->session->set_flashdata('del_details',array('msg'=>'Card Deleted Successfully ','type'=>'Success'));	
		}else{
			return $output = $this->session->set_flashdata('del_details',array('msg'=>' Delete Card Unsuccessful ','type'=>'danger'));	
		}
		
	}
	
	function get_user_card_data_details($record_id){
	     $this->db->select('ud.id,ud.card_id,ud.social_media_profile_name,ud.bu_name,ud.bu_company_name,ud.bu_designation,ud.bu_image,ud.additional_websites,ud.additional_emails,ud.additional_contacts,ud.additional_addresses,ud.additional_socials,ud.service,ud.bio,ct.id as card_id_no ,ct.card_name,user.name,user.email,user.contact');
		 $this->db->from('user_data ud');
		 $this->db->join('card_type ct', 'ud.card_id=ct.id');
         $this->db->join('app_users user', 'ud.user_id=user.id');
         $this->db->where('ud.id',$record_id);   
			$query = $this->db->get(); 
			if($query->num_rows() > 0)
			{
				return $query->row();
			}
			else
			{
				return false;
			}
	}
	
	function update_user_card_data_details(){
		       $record_id=$this->uri->segment(3);
		    # print_r($record_id);exit;
		
			 
			 
			 
			 //business personal infornmation
			   $bu_name=Null;
			   $bu_company_name=Null;
			   $bu_designation=Null;
			   $bu_image=Null;
			   
			   $data_bu_name= $this->input->post('bu_name');
			   if(isset($data_bu_name)){
				   $bu_name=$this->input->post('bu_name');
			   }
			   
			   $data_bu_company_name= $this->input->post('bu_company_name');
			   if(isset($data_bu_company_name)){
				   $bu_company_name=$this->input->post('bu_company_name');
			   }
			   
			   $data_bu_designation= $this->input->post('bu_designation');
			   if(isset($data_bu_designation)){
				   $bu_designation=$this->input->post('bu_designation');
			   }
			   

				
					if(!empty($_FILES['bu_image']['name']))
					{
						$image = str_replace(" ","-",time().$_FILES['bu_image']['name']);
						move_uploaded_file($_FILES['bu_image']['tmp_name'],'./assets/img/profile/'.$image);
						
						 $bu_image='/assets/img/profile/'.$image;
						
						$old=$this->input->post('old_bu_image');
						unlink(FCPATH.$old);
					}
					else
					{
						$bu_image = $this->input->post('old_bu_image');
					}
				
				
			   
			 
			 
			  //additional Website 
			  $data_web_add=$this->input->post('web_type');
			  $js_web_add_on = Null;
			  if(isset($data_web_add)){
			  $we_type=$this->input->post('web_type');
			  $web_add=$this->input->post('web_additional');
			  $arrs_web =  array_combine($we_type,$web_add);
		      $js_web_add_on = json_encode($arrs_web);
			  } 
			 
			 //additional email 
			  $data_email_add=$this->input->post('email_type');
			  $js_email_add_on = Null;
			  if(isset($data_email_add)){
			  $e_type=$this->input->post('email_type');
			  $email_add=$this->input->post('email_additional');
			  $arrs_email =  array_combine($e_type,$email_add);
		      $js_email_add_on = json_encode($arrs_email);
			  }
			  
			  //additional contact 
			  $data_contact_add=$this->input->post('contact_type');
			  $js_contact_add_on = Null;
			  if(isset($data_contact_add)){
			  $c_type=$this->input->post('contact_type');
			  $contact_add=$this->input->post('contact_additional');
			  $arrs_contact =  array_combine($c_type,$contact_add);
		      $js_contact_add_on = json_encode($arrs_contact);
			  }
			  
			  //additional address 
			  $data_address_add=$this->input->post('address_type');
			  $js_address_add_on = Null;
			  if(isset($data_address_add)){
			  $a_type=$this->input->post('address_type');
			  $address_add=$this->input->post('address_additional');
			  $arrs_address =  array_combine($a_type,$address_add);
		      $js_address_add_on = json_encode($arrs_address);
			  }
			  
			   //additional social 
			  $data_social_add=$this->input->post('social_type');
			  $js_social_add_on = Null;
			  if(isset($data_social_add)){
			  $so_type=$this->input->post('social_type');
			  $social_add=$this->input->post('social_additional');
			  $arrs_social =  array_combine($so_type,$social_add);
		      $js_social_add_on = json_encode($arrs_social);
			  }  
			   
			 $bio = Null;
			 $d_bio=$this->input->post('bio');
			 if(isset($d_bio)){
			  $bio=$d_bio;
			 }
			  $service = Null;
			  $d_service=$this->input->post('service');
			 if(isset($d_service)){
			  $service=$d_service;
			 }
		    $social_media_profile_name=Null;
			$d_social=$this->input->post('social_media_profile_name');
			 if(isset($d_social)){
			    $social_media_profile_name=$d_social;
			 }	
		
		
		
		 $data_ins=array(
						 'social_media_profile_name' => $social_media_profile_name,
						  'bu_name ' => $bu_name,
						  'bu_company_name ' => $bu_company_name,
						  'bu_designation ' => $bu_designation,
						  'bu_image ' => $bu_image,
						 'additional_websites ' => $js_web_add_on,
						 'additional_emails' => $js_email_add_on,
						 'additional_contacts'  => $js_contact_add_on,
						 'additional_addresses'  => $js_address_add_on,
						 'additional_socials' =>  $js_social_add_on,
						 'bio' => $bio ,
						 'service' =>  $service
						 
						 );
						 
						 
		$this->db->set($data_ins)->where('id',$record_id)->update('user_data');	

        if($this->db->affected_rows()>0)
		{
			$output = $this->session->set_flashdata('details',array('msg'=>'User Card Updated Successfully','type'=>'success'));
			return $output;
		}
		else
		{
			//return $this->db->last_query();
			return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
		} 
		
	}
	
	function get_all_user_from_shared(){
		$this->db->select('distinct(sh.user_id),u.name,u.email,u.contact');
		$this->db->from('shared sh');
		$this->db->join('app_users u','u.id=sh.user_id');
		$res=$this->db->get();
		
		if($res->num_rows() >0 ){
			return $res->result();
		}else{
			return null;
		}
		
	}
	
	function get_user_from_app_users(){
		$id=$this->uri->segment(3);
		$this->db->select('u.name,u.email,u.contact');
		$this->db->where('id',$id);
		$this->db->from('app_users u');
		$res=$this->db->get();
		
		if($res->num_rows() >0 ){
			return $res->row();
		}else{
			return null;
		}
	}
	
	function get_shared_cards_for_user(){
		$user_id=$this->uri->segment(3);
		$this->db->select('distinct(sh.shared_user_id),u.name,u.email,u.contact');
		$this->db->from('shared sh');
		//$this->db->join('user_data ud','ud.user_id=sh.shared_user_id');
		//$this->db->join('card_type ct','ct.id=ud.card_id');
		$this->db->join('app_users u','u.id=sh.shared_user_id');
		$this->db->where('sh.user_id',$user_id);
		$res=$this->db->get();
		#echo $this->db->last_query();exit;
		if($res->num_rows() >0 ){
			return $res->result();
		}else{
			return null;
		}
		
	}
	
	
	function get_all_shared_cards(){
		$shared_id=$this->uri->segment(3);
		$user_id=$this->uri->segment(4);
		
		$this->db->select('sh.shared_qr_id,ud.social_media_profile_name,ud.bu_name,ud.bu_company_name,ud.bu_designation,ct.card_name,ct.card_icon,ct.card_image,qr.qrcode,u.name,u.email,u.contact');
		$this->db->from('shared sh');
		$this->db->join('user_data ud','ud.qrcode_id=sh.shared_qr_id');
		$this->db->join('card_type ct','ct.id=ud.card_id');
		$this->db->join('app_users u','u.id=sh.shared_user_id');
		$this->db->join('qrcode qr','qr.uid=ud.qrcode_id');
		$this->db->where('sh.user_id',$user_id);
		$this->db->where('sh.shared_user_id',$shared_id);
		$res=$this->db->get();
		if($res->num_rows() >0 ){
			return $res->result();
		}else{
			return null;
		}
		//echo"<pre>";print_r($res);exit;
	}
	
/************************samaj_sewa*********************************/	
	
	function add_new_reg_users(){
		#echo"<pre>";print_r($this->input->post());exit;
		
			
			$name = $this->input->post('name');
			$fname = $this->input->post('fname');
			$age = $this->input->post('age');
			$gender = $this->input->post('gender');
			$email = $this->input->post('email');
			$perma_contact_no = $this->input->post('per_contact');
			$contact_no = $this->input->post('contact');
			$address = $this->input->post('address');
			$city = $this->input->post('city');
			$state = $this->input->post('state');
			$country = $this->input->post('country');
			$pincode = $this->input->post('pincode');
			$qualification = $this->input->post('qualification');
			$occupation = $this->input->post('occupation');
			$password = $this->input->post('password');
			
		    $this->db->where('email',$email);
		    $this->db->or_where('contact_no',$contact_no);
		    $this->db->or_where('perma_contact_no',$perma_contact_no);
		    $q = $this->db->get('user_registration');
		#echo $this->db->last_query();exit;
		#print_r($q);exit;
		if($q->num_rows() > 0){
			return $output = $this->session->set_flashdata('details',array('msg'=>'User already registerd ','type'=>'danger'));
		}else{
	
		
		$upload_img_name='';
		if(!empty($_FILES['image']['name']))
		{
			$image = str_replace(" ","-",time().$_FILES['image']['name']);
			move_uploaded_file($_FILES['image']['tmp_name'],'./assets/img/profile/'.$image);
			
			$upload_img_name='/assets/img/profile/'.$image;
		}
		
		
		
		 $data_ins=array(
		                 'name' => $name,
						 'fname' => $fname,
						 'age' => $age,
						 'gender' => $gender,
						 'email' => $email,
						 'perma_contact_no' => $perma_contact_no,
						 'contact_no' =>$contact_no,
						 'address' => $address,
						 'city' =>$city,
						 'state' => $state,
						 'country'=> $country,
						 'pincode' => $pincode,
						 'qualification' => $qualification,
						 'occupation' => $occupation,
						 'profile_img' => $upload_img_name,
						 'password' => $password
						 );
	    # echo"<pre>"; print_r($data_ins);	exit;					 
	
		 $this->db->insert('user_registration',$data_ins);
		//	echo $this->db->last_query();exit; 	
		  
		  
		if($this->db->affected_rows()>0)
		{
			$ins_id=$this->db->insert_id();
			$memberid = 1000+$ins_id;   /***generating Member id for user****/
			$this->db->set("member_id",$memberid)->where('id',$ins_id)->update('user_registration');
			
			  if($this->db->affected_rows()>0){
			     $output = $this->session->set_flashdata('details',array('msg'=>'User Registered Successfully','type'=>'success'));
		         return $output;
				}
			  else{
					$this->db->where('id',$ins_id)->delete('user_registration');
					return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
				}
		}
		else
		{
			//return $this->db->last_query();
			return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
		}
		
	  }
		
	}
	
	function show_all_user(){
		$q = $this->db->select('*')
				->from('user_registration')
				->get();
				
		if($q->num_rows()>0)
		{
			return $q->result();
		}else{
			return null;
		}
	}
	
	function get_user_info($id){
		$q = $this->db->get_where('user_registration',['id'=>$id]);
				
		if($q->num_rows()>0)
		{
			return $q->row();
		}else{
			return null;
		}
	}
	
	function up_new_users($id)
	{
		#echo"<pre>";print_r($_REQUEST);exit;
		$name = $this->input->post('name');
		$fname = $this->input->post('fname');
		$age = $this->input->post('age');
		$gender = $this->input->post('gender');
		$perma_contact_no = $this->input->post('per_contact');
		$contact_no = $this->input->post('contact');
		$address = $this->input->post('address');
		$city = $this->input->post('city');
		$state = $this->input->post('state');
		$country = $this->input->post('country');
		$pincode = $this->input->post('pincode');
		$qualification = $this->input->post('qualification');
		$occupation = $this->input->post('occupation');
		$password = $this->input->post('password');
				
		
		if(!empty($_FILES['image']['name']))
		{
			$image = str_replace(" ","-",time().$_FILES['image']['name']);
			move_uploaded_file($_FILES['image']['tmp_name'],'./assets/img/profile/'.$image);
			
			$upload_img_name='/assets/img/profile/'.$image;
			
			$old=$this->input->post('old_image');
			unlink(FCPATH.$old);
		}
		else
		{
			$upload_img_name = $this->input->post('old_image');
		}
		
		 $data_ins=array( 'name' => $name,
						 'fname' => $fname,
						 'age' => $age,
						 'gender' => $gender,
						 'perma_contact_no' => $perma_contact_no,
						 'contact_no' =>$contact_no,
						 'address' => $address,
						 'city' =>$city,
						 'state' => $state,
						 'country'=> $country,
						 'pincode' => $pincode,
						 'qualification' => $qualification,
						 'occupation' => $occupation,
						 'profile_img' => $upload_img_name,
						 'password' => $password
						 );
						 
	     #echo"<pre>";print_r($data_ins);//echo $id;exit;
		 
		  $this->db->set($data_ins)->where('id',$id)->update('user_registration');
			#echo $this->db->last_query();exit;
			
		if($this->db->affected_rows()>0)
		{
			$output = $this->session->set_flashdata('details',array('msg'=>'User Updated Successfully','type'=>'success'));
			return $output;
		}
		else
		{
			//return $this->db->last_query();
			return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
		}
		
	  }
	
	function show_all_user_not_operator(){ 
		$q = $this->db->select('*')->where('operator_id IS NULL')->from('user_registration')->get();
		
		if($q->num_rows()>0)
		{
			return $q->result();
		}else{
			return null;
		}
		
	}
	
		function show_all_user_operator()
		{ 
		     $this->db->select('ur.*,op.status as op_status')->where('operator_id IS not NULL')->from('user_registration ur');
		     $this->db->join('operator op','op.member_id  = ur.member_id');
			 $q = $this->db->get();
		
		if($q->num_rows()>0)
		{
			return $q->result();
		}else{
			return null;
		}
		
	  }
	  function add_as_operator(){
		 $member_id=$this->uri->segment(3);
         $id=$this->uri->segment(4);
		
           $res=$this->db->where('member_id',$member_id)->get('operator');		
		   
		   if($res->num_rows() >0){
			 return $output = $this->session->set_flashdata('details',array('msg'=>'User Is Already Operator ','type'=>'danger'));  
		   }
		   else{
			   
			   if($_SESSION['usertype']=='Admin'){
				   $by_operator_member_id='1000';
				   $by_operator_member_ref_code='sewa'.$by_operator_member_id;
			   }else{
				   $user_email=$_SESSION['email'];
				   $this->db->select('op.member_id,op.member_ref_code');
				   $this->db->from('operator op');
				   $this->db->join('users us','us.member_id=op.member_id');
				   $res= $this->db->where('us.email',$user_email);
				   if($res->num_rows()>0){
					  $result = $res->row();
					  $by_operator_member_id=$result->member_id;
					  $by_operator_member_ref_code=$result->member_ref_code;
				   }
				   else{
					 return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));  
				   }
			   }
			   
			   $ins=array(
			               "member_id"=>$member_id,
						   "member_ref_code"=>'sewa'.$member_id,
						   "by_operator_member_id"=>$by_operator_member_id,
						   "by_operator_member_ref_code"=>$by_operator_member_ref_code
						  );
			   
			   
			   $this->db->insert('operator',$ins);
			   if($this->db->affected_rows()>0){
				   
				   $ins_id=$this->db->insert_id();
				   
				    $this->db->set('operator_id',$ins_id)->where(array('member_id'=>$member_id,'id'=>$id))->update('user_registration');
					if($this->db->affected_rows()>0){
				   
					return $output = $this->session->set_flashdata('details',array('msg'=>'User Added As  Operator Successfully','type'=>'success'));
					}else{
						$this->db->where('id',$ins_id)->delete('operator');  
						
						return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
					}
				}else{
					return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
				}
		   }
	
	  }
	  
	  function update_operator_status(){
		  $member_id=$this->uri->segment(3);
           $status=$this->uri->segment(4); 
		   
		      $res=$this->db->set('status',$status)->where('member_id',$member_id)->update('operator');	if($this->db->affected_rows()>0){
				  if($status==1){
				  return $output = $this->session->set_flashdata('details',array('msg'=>'Operator Activated  Successfully','type'=>'success'));
				  }else{
					return $output = $this->session->set_flashdata('details',array('msg'=>'Operator In-Activated  Successfully','type'=>'success'));  
				  }
			  }else{
				  return $output = $this->session->set_flashdata('details',array('msg'=>'Some Error Occured','type'=>'danger'));
			  }
		   
	  }
	  
	  function add_members(){
		   $res=$this->db->where('membered is null')->get('user_registration');
		   #echo $this->db->last_query();exit;
		    if($res->num_rows()>0){
				return $res->result();
			}else{
				return null;
			}
	  }
	  
	  function add_user_as_members(){
		 $member_id=$this->uri->segment(3);
         $id=$this->uri->segment(4);
		
           $res=$this->db->where('user_member_id',$member_id)->get('operator_members');		
		   
		   if($res->num_rows() >0){
			 return $output = $this->session->set_flashdata('details',array('msg'=>'User Is Already Member ','type'=>'danger'));  
		   }
		   else{
			   
			   if($_SESSION['usertype']=='Admin'){
				   $operator_member_id='1000';
				   $operator_ref_code='sewa'.$by_operator_member_id;
			   }else{
				   $user_email=$_SESSION['email'];
				   $this->db->select('op.member_id,op.member_ref_code');
				   $this->db->from('operator op');
				   $this->db->join('users us','us.member_id=op.member_id');
				   $res= $this->db->where('us.email',$user_email);
				   if($res->num_rows()>0){
					  $result = $res->row();
					  $operator_member_id=$result->member_id;
					  $operator_ref_code=$result->member_ref_code;
				   }
				   else{
					 return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));  
				   }
			   }
			   
			   $ins=array(
			               "operator_member_id"=>$operator_member_id,
						   "user_member_id"=>$member_id,
						   "operator_refal_code"=>$operator_ref_code,
						 
						  );
			   
			   
			   $this->db->insert('operator_members',$ins);
			   if($this->db->affected_rows()>0){
				   
				   $ins_id=$this->db->insert_id();
				   
				    $this->db->set('membered',$ins_id)->where(array('member_id'=>$member_id,'id'=>$id))->update('user_registration');
					if($this->db->affected_rows()>0){
				   
					return $output = $this->session->set_flashdata('details',array('msg'=>'User Added As  Member Successfully','type'=>'success'));
					}else{
						$this->db->where('id',$ins_id)->delete('operator_members');  
						
						return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
					}
				}else{
					return $output = $this->session->set_flashdata('details',array('msg'=>'Some error occured please try again','type'=>'danger'));
				}
		   }
	
	  }
	  
	  
}
