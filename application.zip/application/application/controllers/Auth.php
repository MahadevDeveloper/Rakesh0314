<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function __construct()
	{
	    parent::__construct();
	    // Your own constructor code
		$this->load->model(array('auth_model'=>'auth'));	    
	}
	
	public function index()
	{
		$this->load->view('welcome_message');
	}

	public function admin_login()
	{	#print_r($_REQUEST);
	    $data['sett'] = $this->auth->get_site_details1();
		if($this->session->userdata('logged_in')==TRUE)
	    {
	    	$this->redirect_to();
	    }
	    else
	    {
	    	if($this->input->post())
			{
				$this->form_validation->set_rules('email','Email / Mobile number','htmlspecialchars|trim|required');
				$this->form_validation->set_rules('password','Password','htmlspecialchars|trim|required');
				if($this->form_validation->run()==false)
				{
					$this->session->set_flashdata('item','<div class="alert alert-danger p-3">'.validation_errors().'</div>');
					$this->load->view('admin/login');	
				}
				else
				{
					$email = $this->input->post('email');
				    $password = $this->input->post('password');
					$result = $this->auth->validate_login($email);
				    $result->password ;

					if(isset($result) && !empty($result))
					{
						if(password_verify($password , $result->password ))
						{
							
							if($result->status=='active' || $result->status==NULL)
							{
								
								$logged_data = array('userid'=>$result->id,
													'username'=>$result->name,
													'usertype'=>$result->role,
													'profilepic'=>$result->profile_pic,
													'status'=>$result->status,
													'email'=>$result->email,
													'logged_in'=>TRUE
												);
							
								$this->session->set_userdata($logged_data);
								
								if($result->role == 'Admin'){
									$this->redirect_to();
								}elseif($result->role == 'Vendor'){
									$this->redirect_to('vendor/profile');
								}else{
									$this->redirect_to('delivery_boy/profile');
								}
								
							}
							else if($result->status=='inactive')
							{
								$this->session->set_flashdata('item','<div class="alert alert-danger p-2">This Account Is Inactive Contact Admin </div>');
								$this->load->view('admin/login',$data);
							}

						}	
						else
						{
							$this->session->set_flashdata('item','<div class="alert alert-danger p-2">Wrong Password</div>');
							$this->load->view('admin/login',$data);
						}
					}
					else
					{
						$this->session->set_flashdata('item','<div class="alert alert-danger p-2">Invalid Credintials</div>');
						$this->load->view('admin/login',$data);
					}
				}
							
			}
			else
			{
				$this->load->view('admin/login',$data);
			}
	    }
	}

	function logout()
	{
		$this->session->sess_destroy();
		redirect('admin_login','refresh');
	}
	function redirect_to()
	{
		$user_type =strtolower(str_ireplace(' ', '', $this->session->userdata('usertype'))) ;
		redirect($user_type,'refresh');
	}

}
