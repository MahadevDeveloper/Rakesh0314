<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	
	public function test()
	{
	       // $data['get_data'] ;
	           $ress = $this->db->where('status','1')->order_by('id','DESC')->get('add_game');
	            if($ress->num_rows() > 0){
                            $data_g=$ress->result_array();
                           //echo"<pre>"; print_r($data_g);
                           foreach($data_g as $kk){
                             $rests = $this->db->where('game_id',$kk['id'])->order_by('date','DESC')->limit(1,0)->get('add_game_data');  
                             if($rests->num_rows() > 0){
                                  $rest = $rests->row_array();
                                $rest['gamename']=$kk['game_name'];
                                 $rest['starttime']=$kk['start_time'];
                                  $rest['endtime']=$kk['end_time'];
                                    $rest['run_week']=$kk['run_in_week'];
       
                                $data['get_data'][] =$rest;
                             }
                           }
	            }
	        //   echo"<pre>"; print_r($data['get_data']);
	            
	    $data['get_page_data'] = $this->db->select('gussing.*, add_game.game_name as gamename')
	    ->join('add_game', 'add_game.id = gussing.game_id')->order_by('id', 'desc')->get_where('gussing', array('gussing.status'=> '1'))->result_array();

		$this->load->view('test',$data);
	}
	
	
	public function index()
	{
	       // $data['get_data'] ;
	           $ress = $this->db->where('status','1')->order_by('position','ASC')->get('add_game');
	            if($ress->num_rows() > 0){
                            $data_g=$ress->result_array();
                         #  echo"<pre>"; print_r($data_g);
                           foreach($data_g as $kk){
                             $rests = $this->db->where('game_id',$kk['id'])->order_by('date','DESC')->limit(1,0)->get('add_game_data');  
                             if($rests->num_rows() > 0){
                                  $rest = $rests->row_array();
                                $rest['gamename']=$kk['game_name'];
                                 $rest['starttime']=$kk['start_time'];
                                  $rest['endtime']=$kk['end_time'];
                                    $rest['run_week']=$kk['run_in_week'];
       
                                $data['get_data'][] =$rest;
                             }
                           }
	            }
	        //   echo"<pre>"; print_r($data['get_data']);
	            
	    $data['get_page_data'] = $this->db->select('gussing.*, add_game.game_name as gamename')
	    ->join('add_game', 'add_game.id = gussing.game_id')->order_by('id', 'ASC')->get_where('gussing', array('gussing.status'=> '1'))->result_array();

		$this->load->view('web',$data);
	}
	
	public function matka($id=""){
	    $data['check'] = $this->db->get_where('add_game', array('id'=> $id))->row_array();
	    $data['list'] = $this->db->order_by('date ASC')->get_where('add_game_data', array('game_id'=> $data['check']['id']))->result_array();
	    $data['status'] = $this->db->get_where('add_game_page_data', array('game_id'=> $data['check']['id'], 'typechart'=> 'jodi'))->row_array();
	
	    $this->load->view('description', $data);
	}
	
	public function panel_chart($id="") {
        $data['check'] = $this->db->get_where('add_game', array('id'=> $id))->row_array();
	    $data['list'] = $this->db->order_by('date ASC')->get_where('add_game_data', array('game_id'=> $data['check']['id']))->result_array();
	    $data['status'] = $this->db->get_where('add_game_page_data', array('game_id'=> $data['check']['id'], 'typechart'=> 'panel'))->row_array();
	
	    $this->load->view('panel_chart', $data);
	}
	public function not_found(){
	    $this->load->view('errors/html/error_404');
	}
	
}
