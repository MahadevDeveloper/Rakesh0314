<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller {
	public function __construct()
	{
	    parent::__construct();
	    // Your own constructor code

	    if($this->session->userdata('usertype')!=='Admin')
	    {
	    	redirect('logout','refresh');
	    }
	    $this->load->model('Main_model');
	}
	function index($page = 'admin/dashboard',$data = null)
	{
	  /*	
	    $data['user_count'] = $this->Main_model->counting_req_user(); 
        $data['no_opr_count'] = $this->Main_model->counting_no_operator(); 
        $data['qr_not_gen_count'] = $this->Main_model->counting_qr_not_gen(); 
        $data['pkg_count'] = $this->Main_model->counting_pkg(); 
        $data['card_count'] = $this->Main_model->counting_card(); */
		$data['sett'] = $this->Main_model->get_site_details1();
		$this->load->view('admin/header',$data);
		$this->load->view($page,$data);
		// echo "<pre>";
		// print_r($data);
		$this->load->view('admin/footer',$data);	
	}
	function setting($data=null)
	{
		$page = 'admin/setting';
		$data['sett'] = $this->Main_model->get_setting_details();
		$this->index($page,$data);
	}
	function edit_setting($id)
	{
		$data['state'] = $this->Main_model->get_all_state_india(101);
		$page = 'admin/edit_setting';
		$data['cat'] = $this->Main_model->get_edit_setting_details($id);
		$data['city'] = $this->Main_model->get_all_city_india($data['cat']->state);

		if(isset($_POST['submit']))
        {
          $data = $this->Main_model->edit_setting($id);
          redirect('admin/edit_setting/'.$id);
          // print_r($data);
        }
        else
        {
        	//$page = 'admin/edit_category';
			$this->index($page,$data);
        } 
		//$this->index($page,$data);
	}
	
	function add_page($data=null)
	{
		$page = 'admin/add_pages';
		$this->index($page,$data);
	}

function add_page_db(){
	 $dat['title']=trim($this->input->post('title'));
	 $dat['content']=$this->input->post('editor1');
	
	$this->Main_model->add_page_to_db($dat); 
	redirect('admin/add_page');
	
	
}

function show_pages($data=null){
	   
	    $data['page_all']=$this->Main_model->get_all_pages();
	
		$page = 'admin/view_all_pages';
		$this->index($page,$data);
}	
function edit_pages($id){
	$data['edit_page']=$this->Main_model->get_page($id);
	$page = 'admin/edit_page';
	$this->index($page,$data);
}
function view_single_page($id){
	$data['edit_page']=$this->Main_model->get_page($id);
	$page = 'admin/view_single_page';
	$this->index($page,$data);
}

function edit_page_db(){
	$id=($this->input->post('id'));
	$dat['title']=trim($this->input->post('title'));
	 $dat['content']=$this->input->post('editor1');
	
	$this->Main_model->edit_page_to_db($id,$dat);
	redirect('admin/show_pages');
}
function del_page($id){
   	$this->Main_model->del_page_from_db($id);
	redirect('admin/show_pages');
}
	
	
/*************Matka**********************/

function gussing($id=""){
    
    if($this->input->post() && empty($id)){
        $insdata = $this->input->post();
        $this->db->insert('gussing',$insdata);
    }elseif($this->input->post() && !empty($id)){
        $insdata = $this->input->post();
        $this->db->where('id',$id);
        $this->db->update('gussing',$insdata);
    }
    if(!empty($id)){
    $data['gussing'] = $this->db->get_where('gussing', array('id'=>$id))->row_array();
      
    $page = 'admin/gussing';
	$this->index($page,$data);
    }else{
   	$page = 'admin/gussing';
	$this->index($page);
    }
}

public function view_gussing(){
    $data['gussing'] = $this->db->get('gussing')->result();
     $page = 'admin/view_gussing';
	$this->index($page,$data);
}

function add_game($id=""){
    
    if($this->input->post() && empty($id)){
        
        $res = $this->db->get_where('add_game', array('game_name' => $this->input->post('game_name')))->row_array();
        
        if(!$res){
        
        $insdata = $this->input->post();
        $insdata['status'] = 1;
        $this->db->insert('add_game',$insdata);
        
        }else{
            $this->session->set_flashdata('error','<p style="color: red; font-weight: 700">This Game Already Exist</p>');
            redirect('admin/add_game');
        }
        
    }elseif($this->input->post() && !empty($id)){
        $insdata = $this->input->post();
        $insdata['status'] = 1;
        $this->db->where('id',$id);
        $this->db->update('add_game',$insdata);
    }
    if(!empty($id)){
    $data['game'] = $this->db->get_where('add_game', array('id'=>$id))->row_array();
      
    $page = 'admin/add_game';
	$this->index($page,$data);
    }else{
   	$page = 'admin/add_game';
	$this->index($page);
    }
}

public function view_all_game(){
    $data['all_game'] = $this->db->get('add_game')->result();
     $page = 'admin/view_all_game';
	$this->index($page,$data);
}

public function add_daily_entry($id=false){
    
     if($this->input->post() && empty($id)){
         
        $date =$this->input->post('date');
        $idd =$this->input->post('game_id');
        
        $res = $this->db->get_where('add_game_data', array('game_id' => $idd, 'date'=> $date ))->row_array();
        var_dump($res);
        if(!$res) {
         
        $ins = $this->input->post();
        
        $this->db->insert('add_game_data',$ins);
        
        }else{
            $this->session->set_flashdata('error','<p style="color: red; font-weight: 700">This data Already Exist</p>');
            redirect('admin/add_daily_entry');
        }
        
    }elseif($this->input->post() && !empty($id)){
        $ins = $this->input->post();

        $this->db->where('id',$id);
        $this->db->update('add_game_data',$ins);
        
    }
    if(!empty($id)){
    $data['add_game_data'] = $this->db->get_where('add_game_data', array('id'=>$id))->row_array();
      
    $page = 'admin/add_daily_entry';
	$this->index($page,$data);
    }else{
   	$page = 'admin/add_daily_entry';
	$this->index($page);
    }
    
   
}

  public function view_daily_entry(){
    
    $data['game_data'] = $this->db->get('add_game_data')->result();
    //  print_r($data['add_game_data']);exit;
     $page = 'admin/view_daily_entry';
	$this->index($page,$data);
}

public function add_game_description($id=""){

        if($this->input->post() && empty($id)){
        $ins = $this->input->post();
        
        $this->db->insert('add_game_page_data',$ins);
    }elseif($this->input->post() && !empty($id)){
        $ins = $this->input->post();

        $this->db->where('id',$id);
        $this->db->update('add_game_page_data',$ins);
        
    }
    if(!empty($id)){
    $data['add_game_page_data'] = $this->db->get_where('add_game_page_data', array('id'=>$id))->row_array();
      
    $page = 'admin/add_game_description';
	$this->index($page,$data);
    }else{
    $page = 'admin/add_game_description';
	$this->index($page);
    }

}

public function view_game_page_data(){
    
    $data['view_game_page_data'] = $this->db->get('add_game_page_data')->result();
    $page = 'admin/view_game_page_data';
	$this->index($page,$data);
}

public function add_description($id=""){

        if($this->input->post() && empty($id)){
        $ins = $this->input->post();
        
        $this->db->insert('description_data',$ins);
    }elseif($this->input->post() && !empty($id)){
        $ins = $this->input->post();

        $this->db->where('id',$id);
        $this->db->update('description_data',$ins);
        
    }
    if(!empty($id)){
    $data['add_description'] = $this->db->get_where('description_data', array('id'=>$id))->row_array();
      
    $page = 'admin/add_description';
	$this->index($page,$data);
    }else{
    $page = 'admin/add_description';
	$this->index($page);
    }

}

public function view_description(){
    
    $data['view_description'] = $this->db->get('description_data')->result();
    $page = 'admin/view_description';
	$this->index($page,$data);
}

    public function checkstatus($id="", $status=""){
        
        $this->load->model('auth_model');
        $this->auth_model->status($id, $status);
        redirect('admin/view_description');
    }
    
    public function check_guss_status($id="", $status=""){
        
        $this->load->model('auth_model');
        $this->auth_model->guss_status($id, $status);
        redirect('admin/view_gussing');
    }

function add_new_user(){
	
	$data = $this->Main_model->add_new_users();
	$page = 'admin/add_user';
	$this->index($page,$data);
}



function gen_qr($id){
		
	     
		$dat=$this->Main_model->get_user_info($id);
		//print_r($dat);exit;
		if(isset($dat))
		{
			$qrtext="Email :".$dat->email.","."Contact :".$dat->contact.","."Userid :".$dat->userid;
			if($dat->qrcode!=''){
			unlink(FCPATH.$dat->qrcode);
			}
			
			$filename="QR".chr(rand(65,90)).time().chr(rand(65,90)).'.png';
			$path='/assets/img/qr/';
		
			$params['data'] = $qrtext;
			$params['level'] = 'H';
			$params['size'] = 5;
			$params['savename'] = FCPATH.$path.$filename;    //file save path
			$this->ciqrcode->generate($params);
             
			$qr_name=$path.$filename;
			$this->Main_model->update_qrcode_user($id,$qr_name); 
		}
		else
		{
			$this->session->set_flashdata('details',array('msg'=>'No data available','type'=>'danger'));
		}
      redirect('admin/show_user');	
}



function add_package(){
	$page = 'admin/add_package';
	$this->index($page,$data);
}
function add_new_packge(){
	
	$this->Main_model->add_new_pkg();
	redirect('admin/add_package');
}
function view_package(){
	
	$data['pkg']=$this->Main_model->view_pkg();
	$page = 'admin/view_package';
	$this->index($page,$data);
}
function update_status_pkg(){
	 $id=$this->uri->segment(3);
	 $data=$this->uri->segment(4);
	 $this->Main_model->update_pkg($id,$data);
	 redirect('admin/view_package');	
}

function edit_pkg(){
	$id=$this->uri->segment(3);
	$data['edit_pkg']=$this->Main_model->get_edit_pkg($id);
	$page = 'admin/edit_package';
	$this->index($page,$data);
	
}
function edit_package_data(){
	$id=$this->uri->segment(3);
	$this->Main_model->edit_pkg_data($id);
	redirect('admin/view_package');	
	
}
function delete_pkg(){
	$id=$this->uri->segment(3);
	$this->Main_model->delete_pkg_data($id);
	redirect('admin/view_package');	
	
}
function add_card(){
	$page = 'admin/add_card_type';
	$this->index($page,$data);
}
function add_card_data(){
	$this->Main_model->add_new_card();
	redirect('admin/add_card');
	
}
function view_cards(){

	$data['card']=$this->Main_model->view_all_card();
	$page = 'admin/view_card';
	$this->index($page,$data);
}

function edit_card(){
	$id=$this->uri->segment(3);
	$data['card_type']=$this->Main_model->get_edit_card($id);
	$page = 'admin/edit_card_type';
	$this->index($page,$data);
}
function edit_card_data(){
	$id=$this->uri->segment(3);
	$this->Main_model->update_card_data($id);
	redirect('admin/view_cards');	
}

function delete_card(){
	$id=$this->uri->segment(3);
	$this->Main_model->delete_card_data($id);
	redirect('admin/view_cards');	
}

function create_bulk_qrcode(){
	$page = 'admin/create_bulk_qrcode';
	$this->index($page,$data);
}

function generate_bulk_qr_code(){
	
	$num = $this->input->post('num');
	
		if(isset($_REQUEST['num']))
		{
		  for($i=0;$i<$num;$i++){	
			$unique_id="FIZZ".chr(rand(65,90)).chr(rand(65,90)).time().rand(99,990).chr(rand(65,90));
			
			$qrtext="Userid :".$unique_id;
						
			$filename=$unique_id.'.png';
			$path='/assets/img/qr/';
		
			$params['data'] = $qrtext;
			$params['level'] = 'H';
			$params['size'] = 5;
			$params['savename'] = FCPATH.$path.$filename;    //file save path
			$this->ciqrcode->generate($params);
             
			$qr_name=$path.$filename;
			
			$data_ins = array('uid'=>$unique_id,
								'qrcode' => $qr_name
								);
			 $this->db->insert('qrcode',$data_ins);
		  } 
		}
		else
		{
			$this->session->set_flashdata('details',array('msg'=>'No data available','type'=>'danger'));
		}
      redirect('admin/view_qrcode');	
	
	
}

function view_qrcode(){
	
	$data['qr']=$this->Main_model->get_all_unasigned_qrcode();
	$page = 'admin/view_bulk_qrcode';
	$this->index($page,$data);
	
}
function view_assigned_qrcode(){
	
	$data['qr']=$this->Main_model->get_all_asigned_qrcode();
	$page = 'admin/view_assigned_qrcode';
	$this->index($page,$data);
	
}

function asign(){
	$user_id=$this->uri->segment('3');
	$id=$this->uri->segment('4');
	$data['qr']=$this->Main_model->get_particular_qrcode_detail($id);
	$data['user_and_card']=$this->Main_model->get_user_id_detail($user_id);
    $data['user_id']=$user_id;
	$page = 'admin/asign_qr_user';
	$this->index($page,$data);
	
}
function assign_qr_code_to_card(){
	 $id=$this->uri->segment('3');
	 $qr_id=$this->uri->segment('4');
	 $user_id=$this->uri->segment('5');
	 $this->Main_model->update_user_data_and_qrcode($id,$qr_id,$user_id);
	 redirect('admin/view_qrcode');	
	
}

function view_ready_cards(){
	$data['users_and_cards']=$this->Main_model->get_ready_card_user_detail();
	$page = 'admin/view_read_cards';
	$this->index($page,$data);
	
}

function create_user_card(){
	$data['users']=$this->Main_model->get_users_detail_for_card();
	$page = 'admin/all_users_for_card';
	$this->index($page,$data);
	
}

function assign_card_user(){
	$id=$this->uri->segment(3);
	$data['uid']=$id;
	$data['cards']=$this->Main_model->get_card_detail();
	$data['user_card_details']=$this->Main_model->user_card_detail($id);
	//echo"<pre>";print_r($data);exit;
	$page = 'admin/add_card_to_user';
	$this->index($page,$data);
}
function add_particular_card_to_user(){
	// $userid=$this->uri->segment(3);
	 $this->Main_model->insert_card_for_user();
	 redirect('admin/create_user_card');
}

function get_user_details(){
	$id=$this->uri->segment('3');
	$data['qr']=$this->Main_model->get_particular_qrcode_detail($id);
    $data['users']=$this->Main_model->get_user_id_detail_for_card();
	$data['qid']=$id;
	$page = 'admin/users_from_user_data';
	$this->index($page,$data);
}

function update_password(){
	$page = 'admin/password_update';
	$this->index($page);
}

function update_pass(){
	
	$this->Main_model->check_pass();

	redirect('admin/update_password');
}


	
function get_card_user_details(){
    $data['users']=$this->Main_model->get_user_id_detail_of_all_card();
	#print_r($data);exit;
	$page = 'admin/view_all_card_user_from_user_data';
	$this->index($page,$data);
}

function get_all_cards_of_user($dat=null){
	 $user_id=$this->uri->segment('3');
	
	if($user_id==null){
		$user_id=$dat;
	}
     if($user_id!= null){
	$data['user_and_card']=$this->Main_model->get_user_detail_of_user_data($user_id);

	$page = 'admin/get_all_cards_of_single_user_for_edit';
	$this->index($page,$data);
	 }else{
		 $page = 'admin/dashboard';
	$this->index($page,$data);
	 }
	
}



function delete_card_details(){
	$record_id=$this->uri->segment('3');
	$user_id=$this->uri->segment('4');
	$this->Main_model->delete_user_card_data($record_id);
	redirect("admin/get_all_cards_of_user/$user_id");
}

function edit_user_card_details(){
	$record_id=$this->uri->segment('3');
	$data['user_id_for']=$this->uri->segment('4');
	$data['card_details']=$this->Main_model->get_user_card_data_details($record_id);
	$page = 'admin/edit_user_card_data';
	$this->index($page,$data);
	#echo"<pre>";print_r($data);exit;
}

function update_user_card_details(){
	$user_id=$this->uri->segment('4');
	 $this->Main_model->update_user_card_data_details();
	redirect("admin/get_all_cards_of_user/$user_id");
}

function export_to_xls(){
	$data['qr']=$this->Main_model->get_all_unasigned_qrcode();
	$page = 'admin/qr_export_to_xls';
	$this->index($page,$data);
}

function shared_cards(){
	$data['users']=$this->Main_model->get_all_user_from_shared();
	$page = 'admin/shared_card';
	$this->index($page,$data);
	
}

function get_all_shared_cards(){
	$user_id=$this->uri->segment(3);
	$data['user_id']=$user_id;
	$data['user']=$this->Main_model->get_user_from_app_users();
	$data['shared_card']=$this->Main_model->get_shared_cards_for_user();
	#echo"<pre>";print_r($data);exit;
	$page = 'admin/all_user_shared_card';
	$this->index($page,$data);
	
	}

function show_all_cards(){
	$shared_id=$this->uri->segment(3);
	$user_id=$this->uri->segment(4);
	$data['user_id']=$user_id;
	$data['user']=$this->Main_model->get_user_from_app_users();
	$data['shared_card']=$this->Main_model->get_all_shared_cards();
	$page = 'admin/all_shared_cards';
	$this->index($page,$data);
}	
	
/************************samaj_sewa*********************************/	

function reg_user(){
	$page="admin/reg_user";
	$this->index($page,$data);
	
}
function reg_new_user(){
	#echo"<pre>";print_r($_REQUEST);exit;
	$data = $this->Main_model->add_new_reg_users();
	$page = 'admin/reg_user';
	$this->index($page,$data);
}
function show_user(){
	
	$data['all_user'] = $this->Main_model->show_all_user();
	$page = 'admin/all_user';
	$this->index($page,$data);
}

function edit_new_user($id){
	     $data['s_user']=$this->Main_model->get_user_info($id);
	     // print_r($data);
		$page = 'admin/edit_new_user';
	    $this->index($page,$data);
	
}
function update_new_user($id){
	$this->Main_model->up_new_users($id);
	redirect('admin/show_user');	
}	

function add_operator(){
	    $data['s_data']=$this->Main_model->show_all_user_not_operator();
	   
		$page = 'admin/add_oprator';
	    $this->index($page,$data);
}
 
function view_operator(){
	    $data['s_data']=$this->Main_model->show_all_user_operator();
	   
		$page = 'admin/view_operator';
	    $this->index($page,$data);
} 

function add_as_operator(){
	 $data['s_data']=$this->Main_model->add_as_operator();
	
	redirect('admin/add_operator');	
}

function active_inactivate_operator(){
	$this->Main_model->update_operator_status();
	redirect('admin/view_operator');
}
 
function add_member(){
	$data['s_data']=$this->Main_model->add_members();
	$page = 'admin/add_member'; 
    $this->index($page,$data);
}
function add_user_as_member(){
	$this->Main_model->add_user_as_members();
	redirect('admin/add_member');
} 
 
 public function delete_game($id){
     $this->db->where('id',$id);
     $this->db->delete('add_game');
     redirect('admin/view_all_game');
 }
 
 public function delete_daily_entry($id){
     $this->db->where('id',$id);
     $this->db->delete('add_game_data');
     redirect('admin/view_daily_entry');
 }
 
 public function delete_game_page_data($id){
     $this->db->where('id',$id);
     $this->db->delete('add_game_page_data');
     redirect('admin/view_game_page_data');
 }
 
 public function delete_view_description($id){
     $this->db->where('id',$id);
     $this->db->delete('description_data');
     redirect('admin/view_description');
 }
 
  public function delete_gussing($id){
     $this->db->where('id',$id);
     $this->db->delete('gussing');
     redirect('admin/view_gussing');
 }
 
 public function add_passing_record($id=""){

        if($this->input->post() && empty($id)){
        $ins = $this->input->post();
        
        $this->db->insert('passing_record',$ins);
    }elseif($this->input->post() && !empty($id)){
        $ins = $this->input->post();

        $this->db->where('id',$id);
        $this->db->update('passing_record',$ins);
        
    }
    if(!empty($id)){
    $data['passing_record'] = $this->db->get_where('passing_record', array('id'=>$id))->row_array();
      
    $page = 'admin/add_passing_record';
	$this->index($page,$data);
    }else{
    $page = 'admin/add_passing_record';
	$this->index($page);
    }

}

public function view_passing_record(){
    
    $data['view_passing_record'] = $this->db->get('passing_record')->result();
    $page = 'admin/view_passing_record';
	$this->index($page,$data);
}

public function add_leak_game($id=""){

        if($this->input->post() && empty($id)){
        $ins = $this->input->post();
        
        $this->db->insert('leak_game',$ins);
    }elseif($this->input->post() && !empty($id)){
        $ins = $this->input->post();

        $this->db->where('id',$id);
        $this->db->update('leak_game',$ins);
        
    }
    if(!empty($id)){
    $data['leak_game'] = $this->db->get_where('leak_game', array('id'=>$id))->row_array();
      
    $page = 'admin/add_leak_game';
	$this->index($page,$data);
    }else{
    $page = 'admin/add_leak_game';
	$this->index($page);
    }

}


public function view_news(){
    
    $data['news'] = $this->db->get('tbl_news')->result();
    $page = 'admin/view_news';
	$this->index($page,$data);
}


public function add_news($id=""){

        if($this->input->post() && empty($id)){
        $ins = $this->input->post();
        
        $this->db->insert('tbl_news',$ins);
    }elseif($this->input->post() && !empty($id)){
        $ins = $this->input->post();

        $this->db->where('id',$id);
        $this->db->update('tbl_news',$ins);
        
    }
    if(!empty($id)){
    $data['news'] = $this->db->get_where('tbl_news', array('id'=>$id))->row_array();
      
    $page = 'admin/add_news';
	$this->index($page,$data);
    }else{
    $page = 'admin/add_news';
	$this->index($page);
    }

}


public function view_leak_game(){
    
    $data['leak_game'] = $this->db->get('leak_game')->result();
    $page = 'admin/view_leak_game';
	$this->index($page,$data);
}
 
 public function add_membership_charges($id=""){

        if($this->input->post() && empty($id)){
        $ins = $this->input->post();
        
        $this->db->insert('membership_charges',$ins);
    }elseif($this->input->post() && !empty($id)){
        $ins = $this->input->post();

        $this->db->where('id',$id);
        $this->db->update('membership_charges',$ins);
        
    }
    if(!empty($id)){
    $data['membership_charges'] = $this->db->get_where('membership_charges', array('id'=>$id))->row_array();
      
    $page = 'admin/add_membership_charges';
	$this->index($page,$data);
    }else{
    $page = 'admin/add_membership_charges';
	$this->index($page);
    }

}

public function view_membership_charges(){
    
    $data['membership_charges'] = $this->db->get('membership_charges')->result();
    $page = 'admin/view_membership_charges';
	$this->index($page,$data);
}

function update_daily_entry(){
   
    $page = 'admin/update_daily_entry';
	$this->index($page);
}

function get_data_for_update(){
   $id= $this->input->post('id');
   $date=date('Y-m-d');
  
  
  $ind=array('game_id'=>$id,'date'=>$date);
  $da=$this->db->select('game_number,color')->from('add_game_data')->where($ind)->get(); 
  if($da->num_rows() > 0){
     $data=$da->row();
     echo json_encode(array('status'=>true,'gm'=>$data->game_number, 'rm'=>$data->color));
     
  }else{
      echo json_encode(array('status'=>false));
  }
}

function update_daily_entry_up(){
    $data['game_id']=$this->input->post('game_id');
     $data['date']=$this->input->post('date');
      $gn=$this->input->post('game_number');
      if(isset($_REQUEST['color'])){
      $color=$this->input->post('color');
      }else{
          $color='black';
      }
      
      $ins_dat=array('game_number'=>$gn,'color'=>$color);
      
       $this->db->set($ins_dat)->where($data)->update('add_game_data');
      
     if($this->db->affected_rows() > 0){
         $this->session->set_flashdata('success','Updated Successfully');
     }else{
         $this->session->set_flashdata('error','Updated Unsuccessful');
     }
      $page = 'admin/update_daily_entry';
	$this->index($page);
     
}

public function test(){
	$this->load->view('admin/test');
}

function test_game(){
   $id= $this->input->post('id');
  $da=$this->db->select('status')->get_where('description_data', array('game_id'=>$id)); 
  if($da->num_rows() > 0){
     $data=$da->row(); 
     echo json_encode(array('status'=>true,'gm'=>$data->status));
     
  }else{
      echo json_encode(array('status'=>false));
  }
}

	public function todayluky(){
		echo "df";
	}
 
}


	