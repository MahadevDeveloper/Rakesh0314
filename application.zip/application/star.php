<?php    

  $conn=mysqli_connect('localhost','matka','93kg;grcGuPn','matka') or die('Db Connection error');
  $sql="select id from add_game where status =1";
  $res= mysqli_query($conn,$sql);
  
  if(mysqli_num_rows($res)>0){
        while($row=mysqli_fetch_array($res)){
            $ids[]= $row['id'];   
        }
     //   print_r($ids);
        
        $cnt=count($ids);
       
      date_default_timezone_set("Asia/kolkata");
      $dates=date('Y-m-d');
      // $added_on=date('Y-m-d h:i:s');
      for($i=0;$i<$cnt;$i++){

            $ids[$i];       
            $sql1="insert into add_game_data (game_id,date,game_number,color) values('$ids[$i]','$dates','***-**-***','black')";
            mysqli_query($conn,$sql1);
            
	}
    mysqli_close($conn);

}
?>